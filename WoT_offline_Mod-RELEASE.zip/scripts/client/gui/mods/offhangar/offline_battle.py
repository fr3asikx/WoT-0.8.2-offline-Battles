# -*- coding: utf-8 -*-
import time
import utils
import cPickle
from debug_utils import LOG_DEBUG, LOG_CURRENT_EXCEPTION

_g_destr_authority = None

def _get_destr_authority():
	"""offhangar.destructibles_authority, with the same execfile fallback
	the package bootstrap uses (the module ships without a .pyc)."""
	global _g_destr_authority
	if _g_destr_authority is not None:
		return _g_destr_authority
	try:
		from gui.mods.offhangar import destructibles_authority as _da
		_g_destr_authority = _da
		return _da
	except Exception:
		pass
	import sys, os, types
	full_name = 'gui.mods.offhangar.destructibles_authority'
	if full_name in sys.modules:
		_g_destr_authority = sys.modules[full_name]
		return _g_destr_authority
	candidates = []
	try:
		candidates.append(os.path.dirname(os.path.abspath(__file__)))
	except Exception:
		pass
	candidates.append(os.path.join('res_mods', '0.8.2', 'scripts', 'client', 'gui', 'mods', 'offhangar'))
	for _dir in candidates:
		py_path = os.path.join(_dir, 'destructibles_authority.py')
		if os.path.exists(py_path):
			mod = types.ModuleType(full_name)
			mod.__file__ = py_path
			sys.modules[full_name] = mod
			try:
				execfile(py_path, mod.__dict__)
			except Exception:
				del sys.modules[full_name]
				raise
			_g_destr_authority = mod
			return mod
	raise ImportError('destructibles_authority not found')

g_offline_models = []
g_offline_enemies = []
def _add_model(m):
	global g_offline_models
	g_offline_models.append(m)
	import BigWorld
	BigWorld.addModel(m)


def _offh_del_model(m):
	# BigWorld.delModel can set its C error as PENDING while returning normally;
	# this client only RAISES it at the next list-iteration's exhaustion (the
	# FOR_ITER opcode checks PyErr and finds it). len('') does NOT trip it. So
	# absorb it HERE with our own 1-item loop: the loop's exhaustion FOR_ITER
	# raises the pending error INSIDE this try, where the bare except eats it -
	# it can never surface in the CALLER's cleanup loop (which logged
	# "CRITICAL ERROR IN K KEY: ... Not added as a global model" and skipped
	# the list clear, leaking the battle's models into the next battle).
	import BigWorld
	try:
		BigWorld.delModel(m)
		for _ in [0]:
			pass
	except:
		pass


def _offh_proc_mem_mb():
	# DEBUG-ONLY memory probe (returns immediately unless debug_logging is on,
	# so it NEVER runs in the live/share build). ctypes is not functional in
	# this client (_ctypes.pyd missing) and tasklist gives only the working
	# set; wmic also exposes VirtualSize - the 32-bit ADDRESS-SPACE figure that
	# hits the ~2 GB fragmentation wall and OOM-crashes map/model loads (that
	# is the real limit; working set/RSS understates it). Returns
	# (rss_mb, virtual_mb, commit_mb) or (-1, -1, -1).
	try:
		from gui.mods.offhangar.logging import _DBG as _mp_dbg
		if not _mp_dbg[0]:
			return (-1, -1, -1)
	except Exception:
		return (-1, -1, -1)
	try:
		import os
		_pid = os.getpid()
		# /value -> one KEY=VALUE per line. VirtualSize/WorkingSetSize are bytes,
		# PageFileUsage (commit/private) is KB.
		_out = os.popen('wmic process where ProcessId=%d get VirtualSize,PageFileUsage,WorkingSetSize /value' % _pid).read()
		_v = {}
		for _ln in _out.splitlines():
			if '=' in _ln:
				_k, _, _val = _ln.partition('=')
				_val = _val.strip()
				if _val.isdigit():
					_v[_k.strip()] = int(_val)
		if _v:
			return (_v.get('WorkingSetSize', 0) // (1024 * 1024),
			        _v.get('VirtualSize', 0) // (1024 * 1024),
			        _v.get('PageFileUsage', 0) // 1024)
	except Exception:
		pass
	return (-1, -1, -1)


def _offh_gc_census_line(tag):
	"""DEBUG-ONLY per-battle object census. Forces a gc.collect first (so we
	count only SURVIVING = truly-retained objects, i.e. the leak), then walks
	gc.get_objects() and logs the top types by count PLUS the top GROWERS vs
	the previous battle's census. Also logs bw_entities + gc.garbage so we can
	tell a Python leak (total/grower type climbs) from a C++ residual
	(python total flat but commit still climbs = map textures / appearances,
	NOT freeable from Python). Returns immediately unless debug_logging is on,
	so it never runs in the live/share build."""
	try:
		from gui.mods.offhangar.logging import _DBG as _c_dbg, LOG_DEBUG as _c_log
		if not _c_dbg[0]:
			return
	except Exception:
		return
	try:
		import gc as _gc
		try:
			_gc.collect()
			_gc.collect(2)
		except Exception:
			pass
		_objs = _gc.get_objects()
		_total = len(_objs)
		_counts = {}
		for _o in _objs:
			try:
				_tn = type(_o).__name__
			except Exception:
				_tn = '?'
			_counts[_tn] = _counts.get(_tn, 0) + 1
		_objs = None
		# per-tag prev so quit->quit and start->start diff cleanly (interleaved
		# quit/start sweeps would otherwise make the grower delta meaningless).
		_prevkey = '_g_offh_prev_census_%s' % tag
		_prev = globals().get(_prevkey) or {}
		_top = sorted(_counts.items(), key=lambda _kv: _kv[1], reverse=True)[:12]
		_grow = []
		if _prev:
			for _k, _v in _counts.items():
				_d = _v - _prev.get(_k, 0)
				if _d:
					_grow.append((_k, _d))
			_grow.sort(key=lambda _kv: _kv[1], reverse=True)
			_grow = _grow[:12]
		globals()[_prevkey] = _counts
		try:
			_ng = len(_gc.garbage)
		except Exception:
			_ng = -1
		_ent = -1
		try:
			import BigWorld as _bw
			_ent = len(getattr(_bw, 'entities', []) or [])
		except Exception:
			pass
		_c_log('OfflineBattle.sweep(%s) census: total=%d garbage=%d bw_entities=%d | top=%s' % (tag, _total, _ng, _ent, _top))
		if _grow:
			_c_log('OfflineBattle.sweep(%s) census GROWERS(vs prev battle): %s' % (tag, _grow))
	except Exception:
		pass


def _offh_bspace():
	"""The space the battle MAP is in and the camera renders. In dedicated
	(full_space_release) mode this is a FRESH space, different from the
	read-only player.spaceID; in reuse mode it equals player.spaceID. Every
	battle collision / physics / destructible query must use THIS, else it
	hits the wrong (empty) space (tank falls through / no terrain)."""
	try:
		_s = globals().get('g_offh_battle_space', 0) or 0
		if _s:
			return _s
	except Exception:
		pass
	try:
		import BigWorld
		return BigWorld.player().spaceID
	except Exception:
		return 0


def _offh_set_render_space(sid):
	"""Make the engine RENDER space `sid` by pointing the camera at it. The
	HSPACE diagnostic proved rendering follows camera.spaceID /
	BigWorld.cameraSpaceID (the hangar renders its own space this way), NOT the
	read-only _offh_bspace(). Tries both; guarded."""
	import BigWorld
	try:
		if hasattr(BigWorld, 'cameraSpaceID'):
			BigWorld.cameraSpaceID(sid)
	except Exception:
		pass
	try:
		_c = BigWorld.camera()
		if _c is not None:
			_c.spaceID = sid
	except Exception:
		pass


def _offh_safe_purge():
	"""WG-style resource wipe in the loading-screen 'no man's land'. Called
	BETWEEN g_hangarSpace.destroy() and init() on battle exit: the battle is
	torn down and the hangar is DESTROYED (not re-inited yet), so NOTHING
	references the map/tank resources -> ResMgr.purge is safe here. Doing it
	while the hangar/tanks were still LIVE (e.g. at battle start) froze the
	engine. Draw is forced off first (as WG does). Gated by resmgr_purge; the
	START line is flushed to disk so a freeze is pinpointed in the log."""
	try:
		from _constants import CONFIG_OPTIONS as _CFG_PG
		_do_purge = bool(_CFG_PG.get('resmgr_purge', False))
		_do_reload = bool(_CFG_PG.get('reload_textures', False))
		_do_deepgc = bool(_CFG_PG.get('deep_gc', False))
	except Exception:
		_do_purge = False
		_do_reload = False
		_do_deepgc = False
	if not (_do_purge or _do_reload or _do_deepgc):
		return
	import BigWorld
	try:
		BigWorld.worldDrawEnabled(False)
	except Exception:
		pass
	try:
		from gui.mods.offhangar.logging import LOG_DEBUG as _pl
	except Exception:
		_pl = lambda *a: None
	# reloadTextures: reloads the GRAPHICS texture cache from LOCAL disk files.
	# ResMgr.purge is the wrong tool (map textures live in Moo, not DataSections)
	# and global purge freezes on the offline reload. reloadTextures is a local
	# graphics op - should free the dead map-texture residual without hanging.
	if _do_reload:
		try:
			if hasattr(BigWorld, 'reloadTextures'):
				_pl('OfflineBattle.reloadTextures START (if this is the LAST log line, it FROZE - set reload_textures:false)')
				try: BigWorld.flushPythonLog()
				except Exception: pass
				BigWorld.reloadTextures()
				_pl('OfflineBattle.reloadTextures done')
		except Exception:
			pass
	if _do_purge:
		try:
			import ResMgr as _rmg
			if hasattr(_rmg, 'purge'):
				_pl('OfflineBattle.safe_purge START (if this is the LAST log line, purge FROZE - set resmgr_purge:false)')
				try: BigWorld.flushPythonLog()
				except Exception: pass
				try:
					if hasattr(BigWorld, 'clearAllSpaces'):
						BigWorld.clearAllSpaces()
				except Exception:
					pass
				_pl('OfflineBattle.safe_purge clearAllSpaces done, now purging')
				try: BigWorld.flushPythonLog()
				except Exception: pass
				try:
					_rmg.purge()
				except TypeError:
					try: _rmg.purge('', True)
					except Exception: pass
				_pl('OfflineBattle.safe_purge done')
		except Exception:
			pass
		pass
	# deep_gc: bypass the broken C++ ResMgr entirely - clearAllSpaces (works)
	# + aggressive Python GC to drop loose model/mock/closure refs that pin
	# C++ objects. Won't touch the Moo texture cache (not Python), but trims
	# the Python overhang between matches. Safe (no freeze).
	if _do_deepgc:
		try:
			if hasattr(BigWorld, 'clearAllSpaces'):
				BigWorld.clearAllSpaces()
		except Exception:
			pass
		try:
			import sys as _sys
			if hasattr(_sys, 'exc_clear'):
				_sys.exc_clear()
		except Exception:
			pass
		try:
			_pl('OfflineBattle.deep_gc START')
		except Exception:
			pass
	try:
		import gc as _gp
		_gp.collect()
		try: _gp.collect(2)
		except Exception: _gp.collect()
	except Exception:
		pass
	# Re-enable drawing so the re-inited hangar renders (the ESC path does not
	# turn it back on itself).
	try:
		BigWorld.worldDrawEnabled(True)
	except Exception:
		pass


def _offh_dump_purge_apis():
	"""DEBUG-ONLY: dump the real docs/signatures of the resource + TEXTURE APIs
	so we can find the RIGHT texture-cache flush (ResMgr.purge is the wrong tool:
	map textures live in the graphics/Moo cache, not ResMgr DataSections, and
	global purge freezes on the offline reload). Grep the log for 'PURGEAPI:'."""
	try:
		from gui.mods.offhangar.logging import _DBG as _d
		if not _d[0]:
			return
	except Exception:
		return
	import BigWorld
	def _L(*a):
		try:
			from gui.mods.offhangar.logging import LOG_DEBUG as _ld
			_ld('PURGEAPI:', *a)
		except Exception:
			pass
	try:
		import ResMgr
		_L('ResMgr attrs', [n for n in dir(ResMgr) if not n.startswith('__')])
		_L('ResMgr.purge doc', repr(getattr(getattr(ResMgr, 'purge', None), '__doc__', None)))
	except Exception as e:
		_L('ResMgr err', e)
	# Every BigWorld attr whose name hints at texture/memory/cache/reload, with docs.
	try:
		_kw = ('texture', 'reload', 'cache', 'memory', 'flush', 'purge', 'release', 'stream', 'mip')
		for _n in dir(BigWorld):
			if any(k in _n.lower() for k in _kw):
				try:
					_f = getattr(BigWorld, _n, None)
					_L('BW.' + _n, repr(getattr(_f, '__doc__', None))[:220])
				except Exception:
					pass
	except Exception as e:
		_L('BW dir err', e)
	try:
		import Moo
		_L('Moo attrs', [n for n in dir(Moo) if not n.startswith('__')])
	except Exception:
		_L('Moo: not importable')


try:
	import BigWorld as _bw_pa
	_bw_pa.callback(14.0, _offh_dump_purge_apis)
except Exception:
	pass


def _offh_dump_hangar_render(_state=[0]):
	"""DEBUG-ONLY: reveal HOW ClientHangarSpace renders its space (the proven
	'render an arbitrary space' pattern) so we can replicate it for battle maps
	without touching read-only _offh_bspace(). Retries every 5s until in the
	hangar, then dumps once: g_hangarSpace, its inner space object, its spaceID
	vs _offh_bspace(), every BigWorld space/render/camera API, and the camera.
	Grep the log for 'HSPACE:'."""
	try:
		from gui.mods.offhangar.logging import _DBG as _d
		if not _d[0]:
			return
	except Exception:
		return
	import BigWorld
	def _L(*a):
		try:
			from gui.mods.offhangar.logging import LOG_DEBUG as _ld
			_ld('HSPACE:', *a)
		except Exception:
			pass
	# In the hangar the ClientHangarSpace inner space object exists. (player.arena
	# is NOT usable to detect hangar - the offline account returns an arena STUB
	# always, never None. That bug made this never fire.) Retry until the hangar
	# space is up.
	try:
		_pl = BigWorld.player()
	except Exception:
		_pl = None
	_hangar_up = False
	try:
		from gui.Scaleform.utils.HangarSpace import g_hangarSpace as _hs0
		_hangar_up = _hs0 is not None and getattr(_hs0, '_HangarSpace__space', None) is not None
	except Exception:
		_hangar_up = False
	if (_pl is None or not _hangar_up) and _state[0] < 20:
		_state[0] += 1
		try: BigWorld.callback(5.0, _offh_dump_hangar_render)
		except Exception: pass
		return
	# In hangar (or gave up waiting after ~100s) -> dump anyway for data.
	_L('hangar_detected', _hangar_up, 'retries', _state[0])
	_L('=== IN HANGAR - dumping render/space mechanism ===')
	try:
		_L('player', _pl.__class__.__name__, '_offh_bspace()', getattr(_pl, 'spaceID', None))
	except Exception as e:
		_L('player err', e)
	try:
		from gui.Scaleform.utils.HangarSpace import g_hangarSpace as _hs
		_L('g_hangarSpace type', _hs.__class__.__name__ if _hs else None)
		try:
			for _k, _v in _hs.__dict__.items():
				_L('  hs.'+str(_k), '=', repr(_v)[:140])
		except Exception as e:
			_L('hs dict err', e)
		_sp = getattr(_hs, '_HangarSpace__space', None)
		for _cand_attr in ('_HangarSpace__space', 'space', '_HangarSpace__spaceInited'):
			try: _L('  hs.'+_cand_attr, repr(getattr(_hs, _cand_attr, 'NONE'))[:140])
			except Exception: pass
		if _sp is not None:
			_L('inner space type', _sp.__class__.__name__)
			try:
				_L('  space dir', [n for n in dir(_sp) if not n.startswith('__')])
			except Exception: pass
			try:
				for _k, _v in _sp.__dict__.items():
					_L('  space.'+str(_k), '=', repr(_v)[:140])
			except Exception as e:
				_L('space dict err', e)
	except Exception as e:
		_L('g_hangarSpace err', e)
	try:
		_kw = ('space', 'world', 'render', 'active', 'camera', 'draw', 'scene', 'geometry')
		_L('BW space/render APIs', [n for n in dir(BigWorld) if any(k in n.lower() for k in _kw)])
	except Exception as e:
		_L('BW dir err', e)
	try:
		_cam = BigWorld.camera()
		_L('camera type', _cam.__class__.__name__ if _cam else None)
		if _cam is not None:
			_L('  camera space-ish attrs', [n for n in dir(_cam) if 'space' in n.lower()])
			for _a2 in ('spaceID', 'space'):
				try: _L('  camera.'+_a2, getattr(_cam, _a2, 'NONE'))
				except Exception: pass
	except Exception as e:
		_L('camera err', e)
	_L('=== dump done ===')


try:
	import BigWorld as _bw_hs_sched
	_bw_hs_sched.callback(8.0, _offh_dump_hangar_render)
except Exception:
	pass


def _offh_bot_pool(cand, tier, max_unique=None):
	"""Return a SMALL, STABLE set of bot vehicle descriptors for this tier,
	cached across battles in g_offh_bot_pool. Bots otherwise pick ~30 fresh
	RANDOM tanks every battle; the process-wide vehicle texture cache never
	frees, so unlimited variety made the hangar baseline RAM climb battle by
	battle until the next map load OOM-crashed the 32-bit client (native
	0xC0000005 read@0x14). Reusing a fixed pool loads those textures ONCE.
	Variety is tunable via config 'bot_variety' (0 = old unlimited)."""
	if not cand:
		return cand
	if max_unique is None:
		try:
			from _constants import CONFIG_OPTIONS as _CFG_BV
			max_unique = int(_CFG_BV.get('bot_variety', 8))
		except Exception:
			max_unique = 8
	if max_unique <= 0:
		return cand
	pool = globals().setdefault('g_offh_bot_pool', {})
	key = int(tier)
	if key not in pool:
		import random as _r
		n = min(max_unique, len(cand))
		try:
			pool[key] = _r.sample(cand, n)
		except Exception:
			pool[key] = [_r.choice(cand) for _x in range(n)]
	return pool[key]


def _offh_battle_sweep(tag='exit'):
	# Full post-battle cleanup. Without it every battle leaves wrecks,
	# global models, FMOD events and the mapped battle space behind;
	# after a few battles the 32-bit client dies out-of-memory while
	# loading a map or the hangar (malloc NULL -> native write@0).
	# v2: staged + ALWAYS logs one line, failures log stage+traceback.
	import BigWorld
	global g_offline_models, g_offline_enemies
	try:
		import gui.mods.offhangar.logging as _swlog
	except Exception:
		_swlog = None
	_stage = 'init'
	_n_models = 0
	_n_mocks = 0
	_fail = None
	_mem_before = _offh_proc_mem_mb()
	try:
		_n_models = len(g_offline_models or [])
		_mvd = globals().get('G_MOCK_VEHICLES', {}) or {}
		_n_mocks = len(_mvd)
		_stage = 'mocks'
		for _m in list(_mvd.values()):
			try:
				# Detach the engine-exhaust Pixie systems (native particles):
				# unreleased they leak past the battle into the hangar.
				try: _stop_engine_exhaust(_m)
				except Exception: pass
				for _sa in ('_snd_engine', '_snd_tracks'):
					try:
						_s = getattr(_m, _sa, None)
						if _s is not None:
							_s.stop()
						setattr(_m, _sa, None)
					except Exception:
						pass
				try:
					if getattr(_m, 'bw_entity', None) is not None:
						_m.bw_entity.model = None
						_m.bw_entity = None
				except Exception:
					pass
				try:
					# entity-owned chassis: ent.model=None above already released it;
					# delModel on it always raised (pending!) 'Not added as a global
					# model' - the very bomb this sweep kept tripping over.
					_m._chassis_model = None
				except Exception:
					pass
			except Exception:
				pass
		_stage = 'mockdict'
		globals()['G_MOCK_VEHICLES'] = {}
		globals()['g_offh_exhaust_owners'] = []
		_stage = 'models'
		try:
			# Clear the list BEFORE the loop: BigWorld.delModel leaves a PENDING
			# C error that this build only raises at the loop's EXHAUSTION (the
			# final FOR_ITER checks PyErr and finds it). If the clear sits AFTER
			# the loop it gets skipped, and the battle's models - including the
			# player's WRECK - leak into the next battle.
			_gm_list = list(g_offline_models or [])
			g_offline_models = []
			for _gm in _gm_list:
				_offh_del_model(_gm)
		except:
			pass
		_stage = 'enemies'
		try:
			g_offline_enemies = []
		except Exception:
			pass
		_stage = 'sounds'
		_es = globals().get('g_offh_engine_state')
		if _es is not None:
			for _k in ('snd1', 'snd2'):
				try:
					if _es.get(_k) is not None:
						_es[_k].stop()
					_es[_k] = None
				except Exception:
					pass
		_stage = 'projectile'
		try:
			_pm = globals().get('g_projectile_mover')
			if _pm is not None:
				try:
					_pm.destroy()
				except Exception:
					pass
				globals()['g_projectile_mover'] = None
		except Exception:
			pass
		_stage = 'destr'
		try:
			import AreaDestructibles
			# Stop the falling-body animator FIRST: a tree mid-fall at battle exit
			# leaves g_destructiblesAnimator's __updateCallback scheduled; it then
			# fires in the HANGAR against the released battle space ->
			# __launchFallEffect -> getDestructibleDesc(self.__spaceID=dead, ...) ->
			# native "argument 1 must be set to an int". clear() -> __stopUpdate()
			# cancels the BigWorld.callback. Manager.clear() alone did NOT (the
			# callback lives on the animator, a SEPARATE global) - that was the
			# "trees stop falling after a certain number of battles" report.
			_an = getattr(AreaDestructibles, 'g_destructiblesAnimator', None)
			if _an is not None and hasattr(_an, 'clear'):
				_an.clear()
			if getattr(AreaDestructibles, 'g_destructiblesManager', None) is not None:
				AreaDestructibles.g_destructiblesManager.clear()
		except Exception:
			pass
		_stage = 'effects'
		try:
			_pl = BigWorld.player()
			if _pl is not None and getattr(_pl, 'terrainEffects', None) is not None:
				try:
					_pl.terrainEffects.destroy()
				except Exception:
					pass
				try:
					_pl.terrainEffects = None
				except Exception:
					pass
		except Exception:
			pass
		_stage = 'muzzle'
		try:
			_pl = BigWorld.player()
			if _pl is not None:
				# Drop the battle descriptor so the hangar's vehicleTypeDescriptor
				# override falls back to its stub instead of the last battle's tank
				# (set at spawn for the native penetration marker).
				try: _pl._offhangar_td = None
				except Exception: pass
				# The muzzle EffectsListPlayer lives on the persistent account:
				# unreleased it survives into the hangar and battle 2 would
				# replay battle 1's gun effects.
				_mzp = getattr(_pl, '_offhangar_muzzle_player', None)
				if _mzp is not None:
					try:
						_mzp.stop()
					except Exception:
						pass
					_pl._offhangar_muzzle_player = None
				try:
					_smap = getattr(_pl, '_offhangar_sticker_map', None)
					if _smap:
						_smap.clear()
				except Exception:
					pass
			# Always-update models are pinned by the ENGINE (strong native ref
			# + per-frame animation): without delAlwaysUpdateModel one gun
			# model per battle stays animated forever, hangar included.
			for _aum in list(globals().get('g_offh_always_update_models', []) or []):
				try:
					BigWorld.delAlwaysUpdateModel(_aum)
				except Exception:
					pass
			globals()['g_offh_always_update_models'] = []
		except Exception:
			pass
		_stage = 'snipercam'
		try:
			# Restore the original __cameraUpdate: the per-battle patch closure
			# pins mock_veh/loaded_models (a full tank model set) through the
			# hangar; battle start re-patches with fresh refs anyway.
			import AvatarInputHandler.cameras as _swcams
			_swo = getattr(_swcams.SniperCamera, '_orig_cam_update', None)
			if _swo is not None:
				_swcams.SniperCamera._SniperCamera__cameraUpdate = _swo
		except Exception:
			pass
		_stage = 'decals'
		try:
			# shell holes / track marks accumulate in native decal buffers
			if hasattr(BigWorld, 'wg_clearDecals'):
				BigWorld.wg_clearDecals()
		except Exception:
			pass
		# ANTI-FRAGMENTATION: with reuse_map_space on (default) KEEP the battle
		# map mapped between battles - the next same-map battle reuses it instead
		# of freeing + re-allocating ~700 MB, which fragmented the 32-bit address
		# space into an OOM crash. Dynamics are cleared by the 'models' +
		# 'entcache' stages regardless; the mapping is dropped lazily at battle
		# start only when a DIFFERENT map loads. reuse_map_space=false restores
		# the old per-battle unmap (frees memory, but fragments).
		_stage = 'space'
		try:
			from _constants import CONFIG_OPTIONS as _CFG_RM2
			_reuse_sp = bool(_CFG_RM2.get('reuse_map_space', True))
			_full_rel = bool(_CFG_RM2.get('full_space_release', False))
		except Exception:
			_reuse_sp = True
			_full_rel = False
		try:
			if _full_rel:
				# Full teardown: unmap + clearSpace + RELEASESPACE (frees the
				# chunk/terrain RAM; clearSpace only clears contents) + forced gc.
				_sid = globals().get('g_offh_battle_space', 0) or 0
				if _sid:
					# Stop the per-frame render pin so the tick stops forcing the
					# camera onto this space. Do NOT move the camera here (setting
					# it to the empty account space crashed on hangar load); the
					# hangar restore points the camera at its own space, and the
					# space is released only LATER (deferred callback) once it is
					# fully orphaned.
					globals()['g_offh_full_release'] = False
					_mh = globals().get('g_offh_battle_mapping')
					if _mh is not None:
						try:
							BigWorld.delSpaceGeometryMapping(_sid, _mh)
							len('')
						except:
							pass
					try:
						BigWorld.clearSpace(_sid)
					except:
						pass
					globals()['g_offh_battle_mapping'] = None
					globals()['g_offh_mapped_handle'] = None
					globals()['g_offh_mapped_name'] = None
					globals()['g_offh_mapped_space'] = 0
					globals()['g_offh_battle_space'] = 0
					# Defer releaseSpace to AFTER entcache destroys this space's
					# OfflineEntity bots + AreaDestructibles: releaseSpace on a
					# space that still holds entities does NOT fully free its
					# chunk/terrain RAM (measured: freed 0 in-sweep, baseline
					# still crept +700 MB/battle).
					globals()['g_offh_pending_release'] = _sid
			elif not _reuse_sp:
				_sid = globals().get('g_offh_battle_space', 0) or 0
				if _sid:
					# clearSpace alone never returns the chunk/terrain resources
					# (+600 MB); the mapping must be deleted explicitly.
					_mh = globals().get('g_offh_battle_mapping')
					if _mh is not None:
						try:
							BigWorld.delSpaceGeometryMapping(_sid, _mh)
							len('')
						except:
							pass
						globals()['g_offh_battle_mapping'] = None
						globals()['g_offh_mapped_handle'] = None
						globals()['g_offh_mapped_name'] = None
						globals()['g_offh_mapped_space'] = 0
					BigWorld.clearSpace(_sid)
					globals()['g_offh_battle_space'] = 0
		except Exception:
			pass
		# NOTE: ResMgr.purge(mapPath) was tried here and MEASURED freeing ~0 MB
		# across battles - it only drops DataSection descriptors (KB), not the
		# loaded chunk textures/geometry (MB) that the async chunk ejection from
		# clearSpace above owns. Removed as dead weight. The residual per-battle
		# baseline climb (405->654->766 MB) is the process-wide vehicle texture
		# cache (~30 RANDOM tanks/battle, each cached and never released); a
		# GLOBAL ResMgr.purge would free it but froze the engine on the next
		# tank load, so it stays. Bot spawn is capped (max_total_bots) so a
		# single battle cannot pile enough tanks to OOM on its own.
		# clearSpace PARKS leaving entities in an engine-side cache instead
		# of destroying them: 30 OfflineEntity + the AreaDestructibles chunk
		# entities pile up there EVERY battle, pinning their resources.
		_stage = 'entcache'
		try:
			# OfflineEntity bots + AreaDestructibles live in BigWorld.entities,
			# NOT cachedEntities() (empty offline: logged "destroyed 0" EVERY
			# battle = the leak, bw_entities climbed 2->270 and never freed).
			# Iterate the real dict (the wrapper delegates .items() to it and
			# excludes injected mocks); the class filter below keeps hangar/
			# account ghosts safe.
			_ce = getattr(BigWorld, 'cachedEntities', None)
			if callable(_ce):
				_ce = _ce()
			if not _ce:
				_ce = getattr(BigWorld, 'entities', None)
			_pid = 0
			try:
				_pid = getattr(BigWorld.player(), 'id', 0) or 0
			except:
				pass
			_cids = []
			try:
				# only OUR battle entity types - never touch hangar/account ghosts
				for _k2, _v2 in list(_ce.items()):
					try:
						if _v2.__class__.__name__ in ('OfflineEntity', 'AreaDestructibles'):
							_cids.append(_k2)
					except:
						pass
			except:
				pass
			_ndest = 0
			for _cid in _cids:
				if not _cid or _cid == _pid:
					continue
				try:
					BigWorld.destroyEntity(_cid)
					len('')
					_ndest += 1
				except:
					pass
			if _swlog is not None:
				try:
					_swlog.LOG_DEBUG('sweep: destroyed %d/%d battle entities (OfflineEntity+AreaDestructibles)' % (_ndest, len(_cids)))
				except:
					pass
		except:
			pass
		# Deferred full_space_release: entcache just destroyed this space's
		# OfflineEntity bots + AreaDestructibles, so it is now EMPTY and
		# releaseSpace can actually return its chunk/terrain RAM (it no-oped
		# earlier when entities were still parked in it).
		# Deferred full_space_release: the emptied battle space is released at
		# the START of the NEXT battle (stable context, space fully orphaned);
		# releasing in-sweep crashed on hangar load and a transition callback
		# never fired. g_offh_pending_release (set in the space stage) holds it.
		_stage = 'release'
		_stage = 'dastate'
		try:
			import gui.mods.offhangar.destructibles_authority as _dam
			# reset() keeps the dict SHAPE (spaceID/chunks/entities keys);
			# _state.clear() removed them and every destructible call the
			# next battle then KeyError'd, killing all destruction.
			_reset = getattr(_dam, 'reset', None)
			if callable(_reset):
				_reset()
			else:
				_dst = getattr(_dam, '_state', None)
				if isinstance(_dst, dict):
					_dst['spaceID'] = None
					_dst['chunks'] = {}
					_dst['entities'] = set()
		except:
			pass
		# ResMgr.purge is UNSAFE here: DataSections are PROCESS-wide shared
		# (items.vehicles g_cache holds refs for the whole session); purging
		# them under its feet froze the engine on the next tank load.
		_stage = 'resmgr_skipped'
		# The dead battle scopes are reference CYCLES (closure<->cell<->
		# function); collect twice to drain cascades that the first pass
		# only unpins.
		_stage = 'gc'
		try:
			import gc as _gc
			_gc.collect()
			_gc.collect()
		except:
			pass
		# Engine memory report into the log (debug only): if anything still
		# holds megabytes after this sweep, the next log names it.
		_stage = 'memstats'
		try:
			if _swlog is not None and getattr(_swlog, '_DBG', [False])[0]:
				BigWorld.outputMemoryStats()
		except:
			pass
		if not globals().get('g_offh_apis_logged'):
			globals()['g_offh_apis_logged'] = True
			try:
				import ResMgr as _rmx
				_kw = ('flush', 'purge', 'cache', 'clear', 'release', 'texture', 'memory', 'reuse')
				_names = [_n for _n in dir(BigWorld) if any((_k in _n.lower()) for _k in _kw)]
				if _swlog is not None:
					_swlog.LOG_DEBUG('BW-APIs: %s' % (_names,))
					_swlog.LOG_DEBUG('ResMgr-APIs: %s' % (dir(_rmx),))
			except:
				pass
		_stage = 'done'
	except:
		# bare: BigWorld/FMOD can raise old-style exceptions that do NOT
		# inherit from Exception - 'except Exception' misses them.
		try:
			import traceback as _swtb
			_fail = _swtb.format_exc()
		except Exception:
			_fail = 'trace unavailable'
	_mem_after = _offh_proc_mem_mb()
	if _swlog is not None:
		try:
			if _fail is not None:
				_swlog.LOG_DEBUG('OfflineBattle.sweep(%s) FAILED at stage %s: %s' % (tag, _stage, _fail))
			_swlog.LOG_DEBUG('OfflineBattle.sweep(%s): freed models=%d mocks=%d stage=%s | rss %d->%d virt %d->%d commit %d->%d MB (freed rss %d virt %d) [virt = 32-bit ~2GB wall]' % (
				tag, _n_models, _n_mocks, _stage,
				_mem_before[0], _mem_after[0], _mem_before[1], _mem_after[1], _mem_before[2], _mem_after[2],
				_mem_before[0] - _mem_after[0], _mem_before[1] - _mem_after[1]))
		except Exception:
			pass
		try:
			_offh_gc_census_line(tag)
		except Exception:
			pass

import BigWorld
try:
	from projectilemover import ProjectileMover
	def _safe_calc(self, r0, v0, gravity, isOwnShoot, tracerCameraPos):
		import BigWorld
		end = r0 + v0.scale(2000.0 / v0.length)
		res = BigWorld.wg_collideSegment(_offh_bspace(), r0, end, 128)
		hitPoint = res[0] if res else end
		return (hitPoint, (hitPoint - r0).length / v0.length)
	ProjectileMover._ProjectileMover__calcTrajectory = _safe_calc
	g_projectile_mover = ProjectileMover()
except Exception as e:
	LOG_DEBUG('Could not init ProjectileMover:', e)
	g_projectile_mover = None

# Decal crash guard. Some effect lists reference decal groups/textures this
# 0.8.2 client never registers ('slow' group, 'explosion' texture). Native
# wg_addDecal RAISES on the unknown group, aborting EffectsList.attachTo
# halfway - the half-built effect state then kills the client with a native
# access violation (crash logs: "addDecal - invalid <groupName>" immediately
# before EXCEPTION_ACCESS_VIOLATION). Unknown textures resolve to index -1.
# Skip such decals silently; every other effect in the list still plays.
try:
	from helpers import EffectsList as _EL0
	from helpers import DecalMap as _DM0
	if not getattr(_EL0._DecalEffectDesc, '_offh_safe_create', False):
		_orig_decal_create = _EL0._DecalEffectDesc.create
		def _offh_safe_decal_create(self, model, list, args, _orig=_orig_decal_create):
			try:
				_texmap = getattr(_DM0.g_instance, '_DecalMap__texMap', None)
				if _texmap is not None and self._texName not in _texmap:
					return  # unknown texture: skip without LOG_ERROR spam
				return _orig(self, model, list, args)
			except Exception:
				return  # unknown decal group: native addDecal rejected it
		_EL0._DecalEffectDesc.create = _offh_safe_decal_create
		_EL0._DecalEffectDesc._offh_safe_create = True
	# Same protection for particle systems: a Pixie can embed a DECAL
	# RENDERER bound to a decal group ('slow' scorch marks). Attaching one
	# validates the group natively and RAISES when it is not registered on
	# this client (crash logs: _PixieEffectDesc.create -> _findTargetNode ->
	# 'addDecal - invalid <groupName>'), aborting attachTo halfway. Skip
	# just that pixie; the rest of the effect list still plays.
	if not getattr(_EL0._PixieEffectDesc, '_offh_safe_create', False):
		_orig_pixie_create = _EL0._PixieEffectDesc.create
		def _offh_safe_pixie_create(self, model, list, args, _orig=_orig_pixie_create):
			try:
				return _orig(self, model, list, args)
			except Exception:
				return
		_EL0._PixieEffectDesc.create = _offh_safe_pixie_create
		_EL0._PixieEffectDesc._offh_safe_create = True
except Exception:
	LOG_DEBUG('Decal guard install failed')


# shotResult -> shotEffects group, exactly as Vehicle.showDamageFromShot maps
# it: 0 ricochet, 1 non-penetration, 2/3 penetration, 4 critical.
_HIT_EFFECT_GROUPS = ('armorRicochet', 'armorResisted', 'armorHit', 'armorHit', 'armorCriticalHit')


def _terrain_hit_material(spaceID, hit_point, dir_vec):
	"""Effect-material name at a terrain/wall impact - one of
	'ground'/'stone'/'wood'/'metal'/'snow'/'sand' - mirroring
	Vehicle.showDamageFromShot: read the surface matKind with
	wg_getMatInfoNearPoint and map it via VehicleAppearance
	.calcEffectMaterialIndex. Falls back to 'ground' (water is handled
	inside ProjectileMover.explode itself). calcEffectMaterialIndex returns
	-1 for untagged terrain offline - the player is an account, not a
	PlayerAvatar, so its arena-default branch is skipped - hence the clamp."""
	try:
		import BigWorld
		from material_kinds import EFFECT_MATERIALS
		seg_start = hit_point - dir_vec.scale(0.5)
		seg_end = hit_point + dir_vec.scale(0.5)
		matInfo = BigWorld.wg_getMatInfoNearPoint(spaceID, seg_start, seg_end, hit_point, lambda *a: False)
		matKind = matInfo[4] if (matInfo is not None and len(matInfo) > 4) else 0
		from VehicleAppearance import VehicleAppearance as _VA
		effIdx = _VA.calcEffectMaterialIndex(matKind)
		if effIdx is None or effIdx < 0 or effIdx >= len(EFFECT_MATERIALS):
			return 'ground'
		return EFFECT_MATERIALS[effIdx]
	except Exception:
		return 'ground'


def _stop_engine_exhaust(mock):
	"""Detach + drop the engine-exhaust pixies from a tank (death / cleanup)."""
	try:
		pixies = getattr(mock, '_offhangar_exhaust', None)
		if not pixies:
			return
		for node, pixie in pixies:
			try:
				if node is not None:
					node.detach(pixie)
			except Exception:
				pass
		mock._offhangar_exhaust = None
	except Exception:
		pass


def _sync_engine_exhaust(mock, hull_model, td, speed=0.0):
	"""Engine-exhaust smoke for ANY tank (player or bot), reusing the stock
	Pixie exhaust from hull['exhaust'] (VehicleAppearance.__createExhaust):
	one particle system per exhaust node, attached to the hull, with the
	emission rate driven off speed (idle vs moving) like __changeExhaust.
	Created once per tank and cached on mock._offhangar_exhaust. Owners are
	tracked in g_offh_exhaust_owners so the battle sweep detaches every one
	(else the native Pixie systems leak past the battle)."""
	try:
		import Pixie
		if mock is None or hull_model is None or td is None:
			return
		if getattr(mock, 'health', 1) <= 0:
			_stop_engine_exhaust(mock)
			return
		hull = getattr(td, 'hull', None)
		exhaust = hull.get('exhaust') if isinstance(hull, dict) else None
		if not exhaust:
			return
		nodes = exhaust.get('nodes') or ()
		rates = exhaust.get('rates') or ()
		if not nodes or not rates:
			return
		pixies = getattr(mock, '_offhangar_exhaust', None)
		if pixies is None:
			# Resolve the pixie by engine tag, exactly like the stock appearance.
			engine = getattr(td, 'engine', None)
			etags = (engine.get('tags') if isinstance(engine, dict) else getattr(engine, 'tags', None)) or ()
			pixie_name = None
			for tag in etags:
				pixie_name = exhaust.get('pixie/' + tag, pixie_name)
			if not pixie_name:
				return
			pixies = []
			for i in xrange(len(nodes)):
				try:
					pixie = Pixie.create(pixie_name)
					pixie.drawOrder = 50 + i
					node = hull_model.node(nodes[i])
					node.attach(pixie)
					pixies.append((node, pixie))
				except Exception:
					pass
			mock._offhangar_exhaust = pixies
			# Tracked so the battle sweep can detach every tank's pixies.
			globals().setdefault('g_offh_exhaust_owners', []).append(mock)
		# Emission rate: idle when stopped, higher when moving; clamp to table.
		idx = 1 if abs(speed) < 0.5 else 2
		last = len(rates) - 1
		if idx > last:
			idx = last
		if idx < 0:
			idx = 0
		rate = rates[idx]
		for node, pixie in pixies:
			try:
				for si in xrange(pixie.nSystems()):
					pixie.system(si).action(1).rate = rate
			except Exception:
				pass
	except Exception:
		LOG_CURRENT_EXCEPTION()


def _play_vehicle_hit_effect(shell, hit_pos, hit_dir, shot_result, is_player_target=False, target_mock=None):
	"""Play the armor hit / bounce / ricochet effect at a mock vehicle hit
	point. Mock tanks are not real collision geometry, so the ProjectileMover
	(which only collides against static geometry) never shows an impact on
	them. Replay the same shotEffects group the real Vehicle uses, in world
	space via player.terrainEffects (the same channel destructibles use).

	The fullscreen shockwave/flashbang default to ON in EffectsListPlayer, so
	they are only enabled when the PLAYER's own tank is hit - otherwise every
	bot-on-bot / player-on-bot hit would red-flash the whole screen."""
	try:
		import BigWorld, Math
		from items import vehicles
		player = BigWorld.player()
		te = getattr(player, 'terrainEffects', None)
		if te is None or shell is None or hit_pos is None:
			return
		idx = shell.get('effectsIndex') if isinstance(shell, dict) else getattr(shell, 'effectsIndex', None)
		if idx is None:
			return
		effectsDescr = vehicles.g_cache.shotEffects[idx]
		key = _HIT_EFFECT_GROUPS[max(0, min(int(shot_result), len(_HIT_EFFECT_GROUPS) - 1))]
		stages, effects, _ = effectsDescr[key]
		d = Math.Vector3(hit_dir)
		try:
			d.normalise()
		except Exception:
			d = Math.Vector3(0.0, 1.0, 0.0)
		te.addNew(hit_pos, effects, stages, None, dir=d, start=hit_pos - d, end=hit_pos + d,
		          showShockWave=is_player_target, showFlashBang=is_player_target)
		# Rock the target hull like Vehicle.showDamageFromShot does
		try:
			fashion = getattr(target_mock, '_swinging', None)
			if fashion is None and is_player_target:
				fashion = getattr(player, '_offhangar_swinging', None)
			_trigger_shot_impulse(fashion, d, effectsDescr['targetImpulse'])
		except Exception:
			pass
	except Exception:
		LOG_CURRENT_EXCEPTION()


_DS_NAMES_LOGGED = [False]


def _pick_damage_sticker(shot_result=2):
	"""Return a damage-sticker descr chosen by shot outcome: a penetration
	hole for pens (result >= 2), a scratch/ricochet mark otherwise. Selection
	is deterministic (not random) so a pen never shows a scuff and vice versa.
	Logs the available sticker names once for tuning."""
	try:
		from items import vehicles
		ds = vehicles.g_cache.damageStickers
		descrs = ds.get('descrs') if isinstance(ds, dict) else None
		if not descrs:
			return None
		ids = ds.get('ids', {}) if isinstance(ds, dict) else {}
		if not _DS_NAMES_LOGGED[0]:
			_DS_NAMES_LOGGED[0] = True
			LOG_DEBUG('DecalDBG: damage sticker names:', list(ids.keys()))
		pen = int(shot_result) >= 2
		pen_kw = ('pierc', 'penetr', 'hole', 'through', 'shot')
		nonpen_kw = ('scratch', 'ricochet', 'splash', 'nopen', 'no_pen', 'scuff', 'blast')
		want = pen_kw if pen else nonpen_kw
		# exact name match first, then substring
		for name, sid in ids.iteritems():
			low = str(name).lower()
			if any(k in low for k in want):
				return descrs[sid]
		# deterministic fallback: highest-priority sticker, else the first
		try:
			return sorted(descrs, key=lambda d: -int(d.get('priority', 0)))[0]
		except Exception:
			return descrs[0]
	except Exception:
		return None


def _comp_name_from_hits(td, all_hits):
	"""Map the first hit component descriptor to its name (hull/turret/gun/
	chassis) so the decal lands on the right component model."""
	try:
		for _h in (all_hits or []):
			_hc = _h[3] if len(_h) > 3 else None
			if _hc is None:
				continue
			if _hc is getattr(td, 'turret', None):
				return 'turret'
			if _hc is getattr(td, 'gun', None):
				return 'gun'
			if _hc is getattr(td, 'chassis', None):
				return 'chassis'
			if _hc is getattr(td, 'hull', None):
				return 'hull'
	except Exception:
		pass
	return 'hull'


def _setup_gun_recoil(gun_model, td):
	"""Create a WGGunRecoil fashion on the gun model (node 'G'), configured
	from the gun's recoil descriptor. Returns the recoil object to trigger
	per shot, or None."""
	try:
		import BigWorld
		if gun_model is None or td is None:
			return None
		gun = getattr(td, 'gun', None)
		rd = gun.get('recoil') if isinstance(gun, dict) else getattr(gun, 'recoil', None)
		if not rd:
			return None
		recoil = BigWorld.WGGunRecoil('G')
		try:
			recoil.setLod(rd['lodDist'])
		except Exception:
			pass
		recoil.setDuration(rd['backoffTime'], rd['returnTime'])
		recoil.setDepth(rd['amplitude'])
		gun_model.wg_gunRecoil = recoil
		return recoil
	except Exception:
		LOG_CURRENT_EXCEPTION()
		return None


def _trigger_gun_recoil(recoil):
	"""Play the barrel recoil animation for one shot."""
	try:
		if recoil is not None:
			recoil.recoil()
	except Exception:
		pass


def _setup_swinging(chassis_model, td):
	"""DISABLED: attaching this minimal WGVehicleFashion to a mock chassis
	crashes the engine natively on battle start (EXCEPTION_ACCESS_VIOLATION,
	near-null read) - the C++ fashion update expects the track/wheel/filter
	setup VehicleAppearance always provides. Re-enabling needs the full
	setup (setTracks with the chassis track materials, wheel groups, and a
	movementInfo provider). Kept as a stub so the _trigger_shot_impulse
	call sites stay wired; they no-op on a None fashion.

	Original intent: pitch/roll swinging + shot impulse on root node 'V',
	configured from the hull's swinging descriptor like
	VehicleAppearance._setupVehicleFashion. The
	full fashion also animates tracks/wheels, but that needs the vehicle
	filter's movementInfo which mock vehicles lack - so track/wheel/trace
	LODs are set to 0 (disabled) and only the swinging is active."""
	return None
	try:
		import BigWorld
		if chassis_model is None or td is None:
			return None
		swingingCfg = td.hull['swinging']
		fashion = BigWorld.WGVehicleFashion()
		try:
			fashion.maxMovement = td.physics['speedLimits'][0]
		except Exception:
			pass
		# same pitch modifiers VehicleAppearance applies
		_mods = (0.9, 1.88, 0.3, 4.0, 1.0, 1.0)
		pp = tuple(p * m for (p, m) in zip(swingingCfg['pitchParams'], _mods))
		fashion.setPitchSwinging('V', *pp)
		fashion.setRollSwinging('V', *swingingCfg['rollParams'])
		fashion.setShotSwinging('V', swingingCfg['sensitivityToImpulse'])
		fashion.setLods(0.0, 0.0, 0.0, swingingCfg['lodDist'])
		chassis_model.wg_fashion = fashion
		return fashion
	except Exception:
		LOG_CURRENT_EXCEPTION()
		return None


def _trigger_shot_impulse(fashion, d, impulse):
	"""Rock the hull: on firing (backward along the barrel, gun[impulse])
	and on getting hit (hit direction, shotEffects targetImpulse)."""
	try:
		if fashion is not None and d is not None and impulse:
			fashion.receiveShotImpulse(d, impulse)
	except Exception:
		pass


def _play_death_effect(td, position, is_player=False, ammo_rack=False):
	"""Vehicle destruction effect like VehicleAppearance.__playEffect:
	'explosion' for ammo-rack kills, 'destruction' otherwise, played in
	world space via terrainEffects (the wreck model swap detaches the live
	hull model, so attaching to it would cut the effect short). Fullscreen
	shockwave/flashbang only for the player's own tank, like the game."""
	try:
		import random, BigWorld, Math
		player = BigWorld.player()
		te = getattr(player, 'terrainEffects', None)
		if te is None or td is None or position is None:
			return
		kind = 'explosion' if ammo_rack else 'destruction'
		effs = td.type.effects.get(kind) or td.type.effects.get('destruction')
		if not effs:
			return
		stages, effects, _unused = random.choice(effs)
		pos = Math.Vector3(position)
		te.addNew(pos, effects, stages, None,
		          start=pos + Math.Vector3(0.0, -1.0, 0.0),
		          end=pos + Math.Vector3(0.0, 1.0, 0.0),
		          showShockWave=is_player, showFlashBang=is_player)
	except Exception:
		LOG_CURRENT_EXCEPTION()


def _start_fire_effect(mock, hull_model, td):
	"""Burning-tank flames, mirroring the Fire extra: attach the 'fire'
	stage of a random 'flaming' effects list to the hull model."""
	try:
		import random
		if mock is None or hull_model is None or td is None:
			return
		effs = td.type.effects.get('flaming')
		if not effs:
			return
		stages, effects, _unused = random.choice(effs)
		if len(stages) != 2 or stages[0][0] != 'fire' or stages[1][0] != 'noEmission':
			return
		data = {}
		effects.attachTo(hull_model, data, 'fire')
		mock._fire_fx = {'effects': effects, 'data': data, 'hull': hull_model, 'noEmissionTime': stages[1][1]}
	except Exception:
		LOG_CURRENT_EXCEPTION()


def _stop_fire_effect(mock, died=False):
	"""Stop the flames: on extinguish let the smoke (noEmission stage) fade
	out like the Fire extra does; on death cut everything immediately."""
	try:
		import BigWorld
		fx = getattr(mock, '_fire_fx', None)
		if not fx:
			return
		mock._fire_fx = None
		effects, data, hull = fx['effects'], fx['data'], fx['hull']
		if died:
			effects.detachAllFrom(data)
			return
		effects.detachFrom(data, 'fire')
		effects.attachTo(hull, data, 'noEmission')
		BigWorld.callback(fx['noEmissionTime'], lambda: effects.detachAllFrom(data))
	except Exception:
		pass


def _sync_burn_and_death(mock, hull_model, td):
	"""Per-tick visual sync for ANY tank (player or bot), regardless of what
	killed or ignited it (shells, fire, ammo rack): flames while burning, a
	one-shot destruction/ammo-rack explosion on death."""
	try:
		import BigWorld
		if mock is None:
			return
		alive = getattr(mock, 'health', 1) > 0
		burning = bool(getattr(mock, 'is_on_fire', False)) and alive
		if burning and getattr(mock, '_fire_fx', None) is None:
			_start_fire_effect(mock, hull_model, td)
		elif not burning and getattr(mock, '_fire_fx', None) is not None:
			_stop_fire_effect(mock, died=not alive)
		if not alive and not getattr(mock, '_death_fx_played', False):
			mock._death_fx_played = True
			# Dead engines are silent: the real game stops the engine and
			# movement sounds when the vehicle is destroyed.
			for _sname in ('_snd_engine', '_snd_tracks'):
				_snd = getattr(mock, _sname, None)
				if _snd is not None:
					try:
						_snd.stop()
					except Exception:
						pass
					setattr(mock, _sname, None)
			try:
				is_pl = getattr(BigWorld.player(), 'playerVehicleID', -2) == getattr(mock, 'id', -1)
			except Exception:
				is_pl = False
			_play_death_effect(td, getattr(mock, 'position', None), is_player=is_pl,
			                   ammo_rack=bool(getattr(mock, '_ammo_rack_death', False)))
	except Exception:
		pass


def _offh_set_battle_gui_mode(visible):
	"""Single owner of the battle pause-menu input state (cursor visibility +
	AvatarInputHandler input gate). Driven from BOTH the ESC key hook and the
	patched Battle.cursorVisibility flash callback, so every way of opening/
	closing the menu leaves the two consistent (idempotent, not a toggle)."""
	try:
		import BigWorld, GUI
		p = BigWorld.player()
		if p is None:
			return
		p._offhangar_gui_visible = bool(visible)
		aih = getattr(p, 'inputHandler', None)
		if visible:
			BigWorld.setCursor(GUI.mcursor())
			GUI.mcursor().visible = True
			if aih is not None:
				aih._AvatarInputHandler__isStarted = False
		else:
			if aih is not None:
				aih._AvatarInputHandler__isStarted = True
			GUI.mcursor().visible = False
			BigWorld.setCursor(getattr(GUI, 'ccursor', GUI.mcursor)())
	except Exception:
		pass


def _fallback_gun_sound(td, model):
	"""Generic caliber-bucket shot sound. Used ONLY when the gun's own
	effects list could not play: the effects carry the real per-gun sound
	(EffectsList 'sound' element), exactly like the live game, so forcing
	a bucket sound on top doubles it with a generic (often wrong) one."""
	try:
		if model is None:
			return
		caliber = 75
		try:
			gun = getattr(td, 'gun', None)
			if isinstance(gun, dict) and 'shots' in gun:
				caliber = gun['shots'][0]['shell']['caliber']
		except Exception:
			pass
		if caliber > 120:
			sound_event = '/tanks/guns/gun_huge/gun_huge_152mm'
		elif caliber > 100:
			sound_event = '/tanks/guns/gun_large/gun_large_115-152mm'
		elif caliber > 75:
			sound_event = '/tanks/guns/gun_main/gun_main_85-107mm'
		elif caliber > 45:
			sound_event = '/tanks/guns/gun_medium/gun_medium_50-75mm'
		else:
			sound_event = '/tanks/guns/gun_small/gun_small_20-45mm'
		model.playSound(sound_event)
	except Exception:
		pass


_INPUT_DBG = {'total': 0, 'pre_eaten': 0, 'aih': 0, 'started': '?', 'detach': '?', 'installed': False}


def _install_input_chain_debug():
	"""Temporary diagnostic for the intermittent camera aimlock: counts where
	mouse events die in the chain game.handleMouseEvent ->
	AvatarInputHandler.handleMouseEvent -> control mode, and logs a state
	snapshot every 2s while in battle. Remove once the lock is understood."""
	if _INPUT_DBG['installed']:
		return
	# Debug-only: with logging off (player build) do NOT wrap the mouse-event
	# chain nor start the 2s dump loop - pure overhead for players.
	try:
		from gui.mods.offhangar.logging import _DBG as _in_dbg
		if not _in_dbg[0]:
			return
	except Exception:
		return
	_INPUT_DBG['installed'] = True
	try:
		import game, BigWorld
		import AvatarInputHandler as _AIH_mod

		_orig_game_hme = game.handleMouseEvent
		def _dbg_game_hme(event):
			_INPUT_DBG['total'] += 1
			before = _INPUT_DBG['aih']
			result = _orig_game_hme(event)
			if _INPUT_DBG['aih'] == before:
				_INPUT_DBG['pre_eaten'] += 1
			return result
		game.handleMouseEvent = _dbg_game_hme

		_orig_aih_hme = _AIH_mod.AvatarInputHandler.handleMouseEvent
		def _dbg_aih_hme(self, dx, dy, dz):
			_INPUT_DBG['aih'] += 1
			_INPUT_DBG['started'] = getattr(self, '_AvatarInputHandler__isStarted', '?')
			_INPUT_DBG['detach'] = getattr(self, '_AvatarInputHandler__detachCount', '?')
			return _orig_aih_hme(self, dx, dy, dz)
		_AIH_mod.AvatarInputHandler.handleMouseEvent = _dbg_aih_hme

		def _dump():
			try:
				BigWorld.callback(2.0, _dump)
				p = BigWorld.player()
				if p is None or getattr(p, 'arena', None) is None:
					return
				if not _INPUT_DBG['total']:
					return
				try:
					ih = getattr(p, 'inputHandler', None)
					ctrl = getattr(ih, 'ctrl', None) if ih is not None else None
					ctrl_name = ctrl.__class__.__name__ if ctrl is not None else 'None'
					enabled = '?'
					if ctrl is not None:
						for k, v in ctrl.__dict__.items():
							if k.endswith('__isEnabled'):
								enabled = v
								break
				except Exception:
					ctrl_name, enabled = '?', '?'
				try:
					cam = BigWorld.camera()
					cam_name = cam.__class__.__name__ if cam is not None else 'None'
				except Exception:
					cam_name = '?'
				try:
					import GUI
					cursor_on = GUI.mcursor().visible
				except Exception:
					cursor_on = '?'
				LOG_DEBUG('InputDBG: mouse=%s eaten_before_aih=%s reached_aih=%s isStarted=%s detach=%s ctrl=%s enabled=%s cam=%s mcursor=%s period=%s' % (
					_INPUT_DBG['total'], _INPUT_DBG['pre_eaten'], _INPUT_DBG['aih'],
					_INPUT_DBG['started'], _INPUT_DBG['detach'], ctrl_name, enabled,
					cam_name, cursor_on, getattr(getattr(p, 'arena', None), 'period', '?')))
				_INPUT_DBG['total'] = 0
				_INPUT_DBG['pre_eaten'] = 0
				_INPUT_DBG['aih'] = 0
			except Exception:
				pass
		BigWorld.callback(2.0, _dump)
		LOG_DEBUG('InputDBG: input chain diagnostics installed')
	except Exception:
		LOG_CURRENT_EXCEPTION()


def _play_ground_wave(gun_model, td):
	"""Dust kicked up off the ground under the barrel when firing, mirroring
	vehicle_extras.ShowShooting.__doGroundWaveEffect."""
	try:
		import BigWorld, Math
		if gun_model is None or td is None:
			return
		gun = getattr(td, 'gun', None)
		gwv = gun.get('groundWave') if isinstance(gun, dict) else getattr(gun, 'groundWave', None)
		if not gwv:
			return
		player = BigWorld.player()
		if player is None:
			return
		node = gun_model.node('HP_gunFire')
		gunPos = Math.Matrix(node).translation
		testRes = BigWorld.wg_collideSegment(_offh_bspace(), gunPos + Math.Vector3(0, 0.5, 0), gunPos - Math.Vector3(0, 4.0, 0), 128)
		if testRes is None:
			return
		position = testRes[0]
		stages, effects = gwv[0], gwv[1]
		player.terrainEffects.addNew(position, effects, stages, None, dir=testRes[1], start=position + Math.Vector3(0, 0.5, 0), end=position - Math.Vector3(0, 0.5, 0))
	except Exception:
		pass


def _play_muzzle_flash(owner, gun_model, td, is_player=False):
	"""Play the gun muzzle flash (+ ground dust) for one shot, uniformly for
	the player and bots. Reuses a single EffectsListPlayer per gun, stopped
	before replay, exactly like vehicle_extras.ShowShooting."""
	try:
		import BigWorld
		if gun_model is None or td is None or owner is None:
			return
		gun = getattr(td, 'gun', None)
		ge = gun.get('effects') if isinstance(gun, dict) else getattr(gun, 'effects', None)
		if not isinstance(ge, (tuple, list)) or len(ge) < 2:
			return
		stages, effects = ge[0], ge[1]
		# Keep the gun model animating every frame so recoil + flash play out
		# even when the camera is still (matches the game's isPlayer path).
		if is_player and not getattr(gun_model, '_offhangar_always_update', False):
			try:
				BigWorld.addAlwaysUpdateModel(gun_model)
				gun_model._offhangar_always_update = True
				# engine holds a strong ref + animates it every frame:
				# tracked so the battle sweep can delAlwaysUpdateModel it
				globals().setdefault('g_offh_always_update_models', []).append(gun_model)
			except Exception:
				pass
		from helpers import EffectsList
		mzp = getattr(owner, '_offhangar_muzzle_player', None)
		if mzp is None:
			mzp = EffectsList.EffectsListPlayer(effects, stages)
			owner._offhangar_muzzle_player = mzp
		else:
			try:
				mzp.stop()
			except Exception:
				pass
		mzp.play(gun_model)
		_play_ground_wave(gun_model, td)
		return True
	except Exception:
		pass


def _target_sticker_map(target_mock):
	"""Resolve the per-component VehicleStickers map for ANY hit target,
	uniformly for bots and the player, so decals work the same everywhere."""
	m = getattr(target_mock, '_sticker_map', None)
	if m:
		return m
	# The player's own tank keeps its sticker map on the player object.
	try:
		import BigWorld
		p = BigWorld.player()
		if p is not None and getattr(p, 'playerVehicleID', -2) == getattr(target_mock, 'id', -1):
			return getattr(p, '_offhangar_sticker_map', None)
	except Exception:
		pass
	return None


def _add_impact_decal(sticker_map, comp_name, world_hit_pos, world_dir, shot_result=2):
	"""Add a persistent shell-hole decal to a mock tank at the hit point.
	sticker_map maps component name -> (VehicleStickers, componentModel).
	The sticker projects along the shot segment onto the component surface,
	so the segment must be expressed in that model's LOCAL space."""
	try:
		import Math, math
		if not sticker_map:
			return
		entry = sticker_map.get(comp_name) or sticker_map.get('hull')
		if not entry:
			return
		stickers = entry[0]
		model = entry[1]
		node = entry[2] if len(entry) > 2 else None
		if stickers is None or model is None:
			return
		descr = _pick_damage_sticker(shot_result)
		if descr is None:
			return
		# Component models are attached to nodes and report a local (identity)
		# matrix; the node carries the real world transform. Use it to map the
		# world hit point into the model's local space the decal expects.
		w2m = Math.Matrix(node) if node is not None else Math.Matrix(model.matrix)
		w2m.invert()
		d = Math.Vector3(world_dir)
		try:
			d.normalise()
		except Exception:
			d = Math.Vector3(0.0, -1.0, 0.0)
		# segStart just outside the surface, segEnd just inside, so the
		# projector places the decal on the outer skin at the hit point.
		local_start = w2m.applyPoint(world_hit_pos - d.scale(0.4))
		local_end = w2m.applyPoint(world_hit_pos + d.scale(0.4))
		import random
		ang = random.random() * math.pi * 2.0
		up = Math.Vector3(math.sin(ang), math.cos(ang), 0.0)
		sz = descr.get('modelSizes', (0.3, 0.3))
		sizes = Math.Vector2(sz[0], sz[1])
		stickers.addDamageSticker(descr['texName'], descr.get('bumpTexName', ''), local_start, local_end, sizes, up)
	except Exception:
		LOG_CURRENT_EXCEPTION()

from gui.mods.offhangar.logging import LOG_DEBUG
from gui.mods.offhangar.offline_battle_stack import build_offline_battle_context

_BATTLE_BOOT_DEBOUNCE_SEC = 1.5
OFFLINE_BATTLE_ENABLED = True



def _resolve_real_arena_type(map_id, map_name, gameplay_name):
	"""
	Try to resolve a real ArenaType object from the client's cache.
	This provides minimap + other per-map metadata needed by battle GUI.
	"""
	try:
		try:
			import ArenaType as ArenaTypeModule
		except ImportError:
			# 0.8.2 ships it as `common/arenatype.pyc`
			try:
				from common import arenatype as ArenaTypeModule
			except ImportError:
				import arenatype as ArenaTypeModule
		cache = getattr(ArenaTypeModule, 'g_cache', None)
		# Lazy init on some builds: cache can start as None.
		for init_name in ('init', '_init', 'initialize'):
			init_fn = getattr(ArenaTypeModule, init_name, None)
			if callable(init_fn):
				try:
					init_fn()
					cache = getattr(ArenaTypeModule, 'g_cache', None)
				except Exception:
					LOG_CURRENT_EXCEPTION()
			if cache is not None:
				break

		if cache is None:
			LOG_DEBUG('OfflineBattle.arenaType.cacheMissing', map_name, 'module', getattr(ArenaTypeModule, '__name__', '?'))
			return None

		# Some builds provide module-level getters instead of direct cache access.
		for fn_name in ('getArenaType', 'getByGeometryName', 'getByName', 'getArenaTypeByName'):
			fn = getattr(ArenaTypeModule, fn_name, None)
			if callable(fn):
				for key in (map_name, map_id):
					try:
						at = fn(key)
						if at is not None:
							try:
								at.geometryName = map_name
								at.gameplayName = gameplay_name
							except Exception:
								pass
							return at
					except Exception:
						continue

		def _try_get(key):
			for getter in (
				lambda: cache.get(key),
				lambda: cache[key],
				lambda: cache.getArenaType(key) if hasattr(cache, 'getArenaType') else None,
				lambda: cache.getByID(key) if hasattr(cache, 'getByID') else None,
				lambda: cache.getById(key) if hasattr(cache, 'getById') else None,
			):
				try:
					at = getter()
					if at is not None:
						return at
				except Exception:
					continue
			return None

		# g_cache can be a mapping-like object; try the common access patterns.
		at = _try_get(map_name)
		# If stack provided short name like "himmelsdorf", try to match "04_himmelsdorf".
		if at is None and map_name and '_' not in map_name:
			try:
				keys = cache.keys() if hasattr(cache, 'keys') else []
				for k in keys:
					try:
						if isinstance(k, basestring) and (k == map_name or k.endswith('_' + map_name)):
							at = _try_get(k)
							if at is not None:
								map_name = k
								break
					except Exception:
						continue
			except Exception:
				LOG_CURRENT_EXCEPTION()
		if at is not None:
			try:
				at.geometryName = map_name
				at.gameplayName = gameplay_name
			except Exception:
				pass
			return at

		# 0.8.2: g_cache can be a dict keyed by arenaTypeID (int), with geometryName stored on values.
		try:
			if isinstance(cache, dict):
				for k, v in cache.iteritems():
					try:
						geom = getattr(v, 'geometryName', None) or ''
						if not isinstance(geom, basestring):
							continue
						geom_base = geom.split('/')[-1]
						if geom_base == map_name or map_name.endswith(geom_base) or geom_base.endswith(map_name):
							try:
								v.gameplayName = gameplay_name
							except Exception:
								pass
							return v
					except Exception:
						continue
		except Exception:
			LOG_CURRENT_EXCEPTION()

		# Diagnostics: log cache shape so we can implement the correct lookup for 0.8.2.
		try:
			cache_type = type(cache).__name__
			attrs = [a for a in dir(cache) if 'get' in a.lower() or 'arena' in a.lower() or 'type' in a.lower()]
			if isinstance(cache, dict):
				keys = cache.keys()
				key_types = {}
				for kk in keys[:50]:
					kt = type(kk).__name__
					key_types[kt] = key_types.get(kt, 0) + 1
				# also sample a few geometry names to confirm value shape
				sample_geom = []
				for vv in cache.values()[:10]:
					try:
						g = getattr(vv, 'geometryName', None)
						if g:
							sample_geom.append(g)
					except Exception:
						continue
				LOG_DEBUG(
					'OfflineBattle.arenaType.cacheNoHit',
					map_name, 'mapID', map_id,
					'cacheType', cache_type,
					'keyTypes', key_types,
					'sampleGeom', sample_geom[:5],
					'attrs', attrs[:20]
				)
			else:
				LOG_DEBUG('OfflineBattle.arenaType.cacheNoHit', map_name, 'mapID', map_id, 'cacheType', cache_type, 'attrs', attrs[:25])
		except Exception:
			LOG_CURRENT_EXCEPTION()
	except Exception:
		LOG_CURRENT_EXCEPTION()
	return None


def _queue_type_randoms():
	try:
		from constants import QUEUE_TYPE
		return QUEUE_TYPE.RANDOMS
	except Exception:
		# Very old builds: keep a sane default; onEnqueued may still accept an int.
		return 1


def _resolve_vehicle_inv_id(player, int1):
	if int1:
		return int1
	try:
		from CurrentVehicle import g_currentVehicle
		if g_currentVehicle is not None:
			item = getattr(g_currentVehicle, 'item', None)
			if item is not None:
				vid = getattr(item, 'invID', None)
				if vid:
					return vid
	except ImportError:
		pass
	except Exception:
		LOG_CURRENT_EXCEPTION()
	inv = getattr(player, 'inventory', None)
	if inv is None:
		return 0
	for methodName in (
		'getCurrVehicleInvID',
		'getCurrentVehInvID',
		'getVehicleInvID',
		'getCurrentInvID',
	):
		fn = getattr(inv, methodName, None)
		if callable(fn):
			try:
				v = fn()
				if v:
					return v
			except Exception:
				LOG_CURRENT_EXCEPTION()
	for methodName in ('getCurrentVehicle', 'getCurrVehicle'):
		fn = getattr(inv, methodName, None)
		if callable(fn):
			try:
				veh = fn()
				if veh is not None:
					vid = getattr(veh, 'invID', None)
					if vid:
						return vid
			except Exception:
				LOG_CURRENT_EXCEPTION()
	return 0


def _enable_offline_battle_transition(player):
	# Hangar hardening hooks in mod_offhangar must relax while loading an arena.
	player._offhangar_allow_world_clear = True
	# Allow become-non-player only after avatar spawn attempt.
	player._offline_allow_become_non_player = False


def _try_spawn_battle_avatar_stub(player, cmdName):
	import BigWorld
	if player is None or not getattr(player, 'isOffline', False):
		return
	try:
		# Belt: whatever exit path the last battle took, purge its
		# leftovers (wrecks, models, FMOD events, old map) first.
		try:
			_offh_battle_sweep('start')
		except:
			try:
				import traceback as _swtb2
				LOG_DEBUG('Sweep(start) FAILED:', _swtb2.format_exc())
			except Exception:
				pass
		# The sweep destroys the projectile mover on battle exit (it owns
		# the shell models) - recreate it per battle or tracers are gone
		# from the second battle on. The __calcTrajectory patch lives on
		# the class, so a fresh instance keeps it.
		try:
			if globals().get('g_projectile_mover') is None:
				from projectilemover import ProjectileMover as _OffhPM
				globals()['g_projectile_mover'] = _OffhPM()
		except:
			pass
		# Map name from the (matchmaker-rolled) arena.
		map_name = player.arena.arenaType.geometryName
		if not map_name.startswith('spaces/'):
			map_name = 'spaces/' + map_name

		try:
			from _constants import CONFIG_OPTIONS as _CFG_SP
			_full_release = bool(_CFG_SP.get('full_space_release', False))
			_reuse_space = bool(_CFG_SP.get('reuse_map_space', True))
		except Exception:
			_full_release = False
			_reuse_space = True
		globals()['g_offh_full_release'] = _full_release

		if _full_release:
			# Dedicated FRESH space per battle. Rendering follows camera.spaceID
			# (the diagnostic proved it; the hangar renders its own space that
			# way), so we point the render camera at this space. The PREVIOUS
			# battle's space is releaseSpace'd HERE (start = stable context, it's
			# fully orphaned) rather than in the exit sweep, which crashed on the
			# hangar load -> map RAM truly returned -> variety WITHOUT fragmentation.
			_prev = globals().get('g_offh_pending_release', 0) or 0
			if _prev:
				globals()['g_offh_pending_release'] = 0
				try:
					if hasattr(BigWorld, 'releaseSpace'):
						BigWorld.releaseSpace(_prev)
						len('')
				except Exception:
					pass
				try:
					import gc as _gcp
					_gcp.collect(); _gcp.collect()
				except Exception:
					pass
				LOG_DEBUG('OfflineBattle.released prev space', _prev)
			space_id = BigWorld.createSpace()
			_offh_mh = BigWorld.addSpaceGeometryMapping(space_id, None, map_name)
			globals()['g_offh_mapped_handle'] = _offh_mh
			globals()['g_offh_mapped_space'] = space_id
			globals()['g_offh_mapped_name'] = map_name
			_offh_set_render_space(space_id)
			LOG_DEBUG('OfflineBattle.dedicated space', space_id, 'camera render ->', space_id, map_name)
		else:
			space_id = getattr(player, 'spaceID', 0)
			if space_id == 0:
				space_id = BigWorld.createSpace()
			# ANTI-FRAGMENTATION: reuse the already-mapped space when the map is
			# UNCHANGED (reuse_map_space); else unmap old + map new.
			_mapped_name = globals().get('g_offh_mapped_name')
			_mapped_space = globals().get('g_offh_mapped_space', 0) or 0
			_mapped_handle = globals().get('g_offh_mapped_handle')
			if _reuse_space and _mapped_handle is not None and _mapped_space == space_id and _mapped_name == map_name:
				_offh_mh = _mapped_handle
				LOG_DEBUG('OfflineBattle.mappedGeometry REUSED (no realloc)', map_name, 'space', space_id)
			else:
				if _mapped_handle is not None and _mapped_space:
					try: BigWorld.delSpaceGeometryMapping(_mapped_space, _mapped_handle)
					except Exception: pass
				try: BigWorld.clearSpace(space_id)
				except Exception: pass
				_offh_mh = BigWorld.addSpaceGeometryMapping(space_id, None, map_name)
				globals()['g_offh_mapped_handle'] = _offh_mh
				globals()['g_offh_mapped_space'] = space_id
				globals()['g_offh_mapped_name'] = map_name
				LOG_DEBUG('OfflineBattle.mappedGeometry', map_name, 'space', space_id)
		globals()['g_offh_battle_space'] = space_id
		globals()['g_offh_battle_mapping'] = _offh_mh
		globals()['g_offh_battle_mapname'] = map_name
		# The spaceID is reused between battles, so the per-space reset
		# heuristics in the destructibles ledger / tree registry never fire
		# on their own: reset explicitly or the dedup sets grow forever and
		# suppress destruction of fresh objects in later battles.
		try:
			_get_destr_authority().reset()
		except Exception:
			pass
		for _k in ('g_offh_tree_state', 'g_offh_destr_ordered', 'g_offh_destr_chunks', 'g_offh_destr_seen', 'g_offh_ram_cd'):
			globals().pop(_k, None)
		# Start the destructibles manager BEFORE the chunks stream in, so it
		# receives onChunkLoad for every chunk (fences/houses become breakable)
		try:
			import AreaDestructibles
			if getattr(AreaDestructibles, 'g_destructiblesManager', None) is not None:
				AreaDestructibles.g_destructiblesManager.startSpace(space_id)
				LOG_DEBUG('OfflineBattle: destructibles manager started for space', space_id)
		except Exception:
			LOG_CURRENT_EXCEPTION()
	except Exception:
		LOG_CURRENT_EXCEPTION()

	try:
		LOG_DEBUG('OfflineBattle.starting camera manually in space', space_id)
		import AvatarInputHandler
		import Math, ResMgr
		global g_offline_aih

		# Determine spawn position from arena XML
		spawn_pos = Math.Vector3(0, 100.0, 0)
		spawn_dir = Math.Vector3(0, 0, 3.1415926535)
		try:
			at = player.arena.arenaType
			if True:
				xml_path = 'scripts/arena_defs/%s.xml' % at.geometryName.split('/')[-1]
				section = ResMgr.openSection(xml_path)
				LOG_DEBUG('OfflineBattle.XML_LOAD:', xml_path, section is not None)
				if section is not None:
					import debug_utils
					debug_utils.LOG_DEBUG('DUMP ARENA DEFS:', section.keys(), section['gameplayTypes/ctf'].keys() if section.has_key('gameplayTypes/ctf') else 'no_ctf')
					if section.has_key('gameplayTypes/ctf'):
						ctf = section['gameplayTypes/ctf']
						for t in ['team1', 'team2']:
							if ctf.has_key('teamSpawnPoints/%s' % t):
								debug_utils.LOG_DEBUG('SPAWN POINTS %s:' % t, ctf['teamSpawnPoints/%s' % t].keys())
								for k, v in ctf['teamSpawnPoints/%s' % t].items():
									debug_utils.LOG_DEBUG(' - ', k, type(v), v.asVector2)
					gp = section['gameplayTypes/ctf']
					if section is not None:
						try:
							with open('C:\\Games\\World_of_Tanks_0.08.02.00.00_EU_0543_SD\\arena_dump_root.txt', 'w') as f_out:
								f_out.write('ROOT keys: ' + str(section.keys()) + '\n')
								for k, v in section.items():
									if k in ['teamSpawnPoints', 'teamBasePositions'] or 'team' in k:
										f_out.write(' - ' + k + ' : ' + str(type(v)) + '\n')
										if hasattr(v, 'keys'):
											f_out.write('    keys: ' + str(v.keys()) + '\n')
						except Exception as e:
							pass
					if gp is not None:
						try:
							with open('C:\\Games\\World_of_Tanks_0.08.02.00.00_EU_0543_SD\\arena_dump_gp.txt', 'w') as f_out:
								f_out.write('ctf keys: ' + str(gp.keys()) + '\n')
								for k, v in gp.items():
									f_out.write(' - ' + k + ' : ' + str(type(v)) + '\n')
									if hasattr(v, 'keys'):
										f_out.write('    keys: ' + str(v.keys()) + '\n')
										for k2, v2 in v.items():
											f_out.write('    - ' + k2 + ' : ' + str(type(v2)) + '\n')
											if hasattr(v2, 'keys'):
												f_out.write('       keys: ' + str(v2.keys()) + '\n')
												for k3, v3 in v2.items():
													f_out.write('       - ' + k3 + ' asVec2:' + str(getattr(v3, 'asVector2', 'none')) + ' asStr:' + str(getattr(v3, 'asString', 'none')) + '\n')
						except Exception as e:
							import debug_utils
							debug_utils.LOG_DEBUG('DUMP ERROR:', e)
						
						global g_offline_bases
						g_offline_bases = {1: [], 2: []}
						import debug_utils
						try:
							bp_node_all = gp['teamBasePositions']
							if bp_node_all is not None:
								debug_utils.LOG_DEBUG('teamBasePositions EXISTS! keys:', bp_node_all.keys())
								for k, v in bp_node_all.items():
									debug_utils.LOG_DEBUG(' - child:', k, v.keys())
						except Exception as e:
							debug_utils.LOG_DEBUG('teamBasePositions error:', e)

						
						for t_id in (1, 2):
							bp_node = gp['teamBasePositions/team%d' % t_id]
							if bp_node is not None:
								items = bp_node.items()
								if items:
									for k, v in items:
										import debug_utils
										debug_utils.LOG_DEBUG('Base node child', t_id, k)
										if v is not None and hasattr(v, 'asVector2'):
											g_offline_bases[t_id].append(Math.Vector3(v.asVector2.x, 0.0, v.asVector2.y))
										elif v is not None and hasattr(v, 'asVector3'):
											g_offline_bases[t_id].append(Math.Vector3(v.asVector3.x, 0.0, v.asVector3.z))
								else:
									import gui.mods.offhangar.logging as __offlog
									__offlog.LOG_DEBUG('LOUD: Base node DIRECT', t_id)
									if hasattr(bp_node, 'asVector2'):
										g_offline_bases[t_id].append(Math.Vector3(bp_node.asVector2.x, 0.0, bp_node.asVector2.y))
									elif hasattr(bp_node, 'asVector3'):
										g_offline_bases[t_id].append(Math.Vector3(bp_node.asVector3.x, 0.0, bp_node.asVector3.z))
									elif hasattr(bp_node, 'asString'):
										try:
											parts = bp_node.asString.split()
											g_offline_bases[t_id].append(Math.Vector3(float(parts[0]), 0.0, float(parts[1])))
										except Exception as e:
											pass
							import gui.mods.offhangar.logging as __offlog
							__offlog.LOG_DEBUG('LOUD: g_offline_bases is now:', g_offline_bases)
						
						import debug_utils
						debug_utils.LOG_DEBUG('Parsed bases:', g_offline_bases)
						
						# Collect the original spawn points of BOTH teams (for the 15v15 auto-spawn)
						global g_offline_spawns
						g_offline_spawns = {1: [], 2: []}
						for _sp_t in (1, 2):
							try:
								_sp_node = gp['teamSpawnPoints/team%d' % _sp_t]
								if _sp_node is not None:
									for _sp_k, _sp_v in _sp_node.items():
										_sp_v2 = getattr(_sp_v, 'asVector2', None)
										if _sp_v2 is None:
											try:
												_sp_parts = _sp_v.asString.split()
												_sp_v2 = Math.Vector2(float(_sp_parts[0]), float(_sp_parts[1]))
											except Exception:
												_sp_v2 = None
										if _sp_v2 is not None:
											g_offline_spawns[_sp_t].append((float(_sp_v2.x), float(_sp_v2.y)))
							except Exception:
								pass
						LOG_DEBUG('OfflineBattle.spawnPoints:', g_offline_spawns)
						
						sp = gp['teamSpawnPoints/team1']
						bp = gp['teamBasePositions/team1']
						
						# Validate ALL spawn candidates with a roof/ledge check instead of
						# blindly taking the first one. Real spawn points first (like the
						# original game), base flag positions as fallback.
						_found_spawn = False
						import BigWorld
						
						def _read_vec2(val):
							v2 = getattr(val, 'asVector2', None)
							if v2 is None:
								try:
									parts = val.asString.split()
									v2 = Math.Vector2(float(parts[0]), float(parts[1]))
								except: pass
							return v2
						
						# Collect candidates: real spawn points first, then base positions
						_spawn_cands = []
						if sp is not None:
							for key, val in sp.items():
								vec2 = _read_vec2(val)
								if vec2 is not None:
									_spawn_cands.append(vec2)
						if bp is not None:
							for key, val in bp.items():
								if 'position' in key or key.isdigit():
									vec2 = _read_vec2(val)
									if vec2 is not None:
										_spawn_cands.append(vec2)
						LOG_DEBUG('OfflineBattle.spawn candidates:', len(_spawn_cands), map_name)
						
						def _spawn_ground(x, z):
							# Returns (y, ok): ground height + roof/ledge check
							# (neighbouring ground must exist and be at a similar height)
							y = None
							try:
								hit = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(x, 1000.0, z), Math.Vector3(x, -1000.0, z), 128)
								if hit is not None:
									y = hit[0].y
							except: pass
							if y is None:
								return (None, False)
							for _dx, _dz in ((4.0, 0.0), (-4.0, 0.0), (0.0, 4.0), (0.0, -4.0)):
								try:
									c = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(x + _dx, y + 3.0, z + _dz), Math.Vector3(x + _dx, y - 150.0, z + _dz), 128)
								except:
									continue
								if c is None or abs(c[0].y - y) > 3.0:
									return (y, False)
							return (y, True)
						
						for vec2 in _spawn_cands:
							_sy, _sok = _spawn_ground(vec2.x, vec2.y)
							if _sy is not None and _sok:
								spawn_pos = Math.Vector3(vec2.x, _sy, vec2.y)
								LOG_DEBUG('OfflineBattle.spawn validated pos:', spawn_pos)
								_found_spawn = True
								break
						if not _found_spawn and _spawn_cands:
							# Fallback: first candidate without the roof check (better than map centre)
							vec2 = _spawn_cands[0]
							_sy, _sok = _spawn_ground(vec2.x, vec2.y)
							spawn_pos = Math.Vector3(vec2.x, _sy if _sy is not None else 100.0, vec2.y)
							LOG_DEBUG('OfflineBattle.spawn fallback pos:', spawn_pos)
						
						# Face the enemy base instead of a fixed 180 degrees
						try:
							import math
							_eb_list = g_offline_bases.get(2, [])
							if _eb_list:
								_ddx = _eb_list[0].x - spawn_pos.x
								_ddz = _eb_list[0].z - spawn_pos.z
								if _ddx * _ddx + _ddz * _ddz > 25.0:
									spawn_dir = Math.Vector3(0, 0, math.atan2(_ddx, _ddz))
						except Exception:
							pass
						
						# Hardcoded spawn hack removed: the candidates above are validated against
						# roofs/ledges, so the real arena_def spawn points are safe to use directly.
						import math
		except Exception as e:
			LOG_DEBUG('OfflineBattle.XML_ERROR:', str(e))

		# Use a MatrixProduct as the live vehicle matrix provider.
		# Math.Matrix is a STATIC snapshot - WGTranslationOnlyMP.source needs a C++ live provider.
		# MatrixProduct(a=identity, b=identity) acts as a live provider and can be .set()-like via its parts.
		veh_matrix_static = Math.Matrix()
		veh_matrix_static.setTranslate(spawn_pos)
		veh_matrix = Math.MatrixProduct()
		veh_matrix.a = veh_matrix_static
		veh_matrix.b = Math.Matrix()  # identity
		
		# Chassis matrix: includes yaw + position, driven by Servo
		# so hull/turret/gun chain stays perfectly in sync
		chassis_m = Math.Matrix()
		chassis_m.setTranslate(spawn_pos)
		chassis_mp = Math.MatrixProduct()
		chassis_mp.a = chassis_m
		chassis_mp.b = Math.Matrix()  # identity

		class _MockFilter(object): pass
		mf = _MockFilter()
		mf.position = Math.Vector3(spawn_pos)
		mf.yaw = 0.0
		mf.pitch = 0.0
		mf.matrix = veh_matrix

		class _Appearance(object):
			def changeVisibility(self, part, visible, lod=True): pass
			def showStickers(self, visible): pass
			def isUnderwater(self): return False
			def __getattr__(self, name):
				if 'turretMatrix' in name:
					return turret_matrix_local
				if 'gunMatrix' in name:
					if self.compoundModel is not None:
						try:
							return self.compoundModel.node('HP_gunJoint')
						except Exception:
							pass
					return turret_matrix
				if 'hullMatrix' in name:
					if self.compoundModel is not None:
						try:
							return self.compoundModel.node('V')
						except Exception:
							pass
					return turret_matrix
				if 'Matrix' in name or 'Prov' in name:
					if self.compoundModel is not None:
						return self.compoundModel.matrix
					return turret_matrix
				if 'Bounds' in name:
					import Math
					return (Math.Vector3(-1,-1,-1), Math.Vector3(1,1,1))
				if name.startswith(('is','on','set','get','update','show','hide','add','remove','play','stop','start')) or name == 'refresh':
					return lambda *a, **k: None
				import Math
				return Math.Matrix()

		ma = _Appearance()

		td = None
		try:
			if hasattr(player, '_offhangar_battle_ctx'):
				ctx = player._offhangar_battle_ctx
				vdict = ctx.get('vehicles', {})
				vid = player.playerVehicleID
				vinfo = vdict.get(vid)
				if not vinfo and vdict:
					vinfo = list(vdict.values())[0]
				if vinfo:
					td = vinfo.get('vehicleType')
			
			from items import vehicles
			if type(td) is int:
				nationID = (td >> 4) & 15
				vehicleID = td >> 8
				td = vehicles.VehicleDescr(typeID=(nationID, vehicleID))
				LOG_DEBUG('PHYSICS_DUMP:', td.physics)
			elif td is None:
				td = vehicles.VehicleDescr(typeName='ussr:MS-1')
			elif type(td).__name__ == 'FakeDesc':
				# If offline_battle_stack gave us FakeDesc, fallback to MS-1 so we don't crash
				td = vehicles.VehicleDescr(typeName='ussr:MS-1')
		except Exception as e:
			LOG_DEBUG('OfflineBattle.td error', str(e))

		LOG_DEBUG('OfflineBattle.td resolved:', td, type(td).__name__ if td else None)
		if td is not None:
			LOG_DEBUG('OfflineBattle.td types:', type(td.chassis), type(td.hull), type(td.turret))
			if hasattr(td.chassis, 'keys'):
				LOG_DEBUG('OfflineBattle.td keys:', td.chassis.keys())

		# Inject into player so the GUI finds it!
		player.vehicleTypeDescriptor = td
		# Publish the battle descriptor via _offhangar_td so the account's
		# vehicleTypeDescriptor getattribute override returns THIS tank (not a
		# fresh tier-1 MS-1); the native penetration marker, tracer ballistics
		# and maxHealth then read the real tank being driven. Cleared in the
		# sweep's 'muzzle' stage so the hangar falls back to its stub.
		player._offhangar_td = td

		loaded_models = {'chassis': None, 'hull': None, 'turret': None, 'gun': None, 'td': td}
		loaded_models['chassis_mp'] = chassis_mp
		if td is not None:
			for part_name in ('chassis', 'hull', 'turret', 'gun'):
				try:
					part_desc = getattr(td, part_name, None)
					if part_desc is not None and 'models' in part_desc and 'undamaged' in part_desc['models']:
						modelName = part_desc['models']['undamaged']
						m = BigWorld.Model(modelName)
						loaded_models[part_name] = m
						LOG_DEBUG('OfflineBattle.model loaded:', part_name, modelName)
				except Exception as e:
					LOG_DEBUG('OfflineBattle load model error:', part_name, str(e))
			
			# BigWorld.Model() is async - the model isn't ready immediately.
			# Use a callback to add them after they've loaded.
			_models_to_add = dict((k, v) for k, v in loaded_models.items() if v is not None)
			_add_attempts = [0]
			
			
			def _add_models_when_ready():
				_add_attempts[0] += 1
				try:
					chassis = _models_to_add.get('chassis')
					hull    = _models_to_add.get('hull')
					turret  = _models_to_add.get('turret')
					gun     = _models_to_add.get('gun')
										
					if chassis is not None:
						chassis.position = Math.Vector3(spawn_pos)
						chassis.yaw = 0.0
						_add_model(chassis)
						try:
							chassis.addMotor(BigWorld.Servo(chassis_mp))
							LOG_DEBUG('OfflineBattle.chassis Servo attached')
						except Exception as e:
							LOG_DEBUG('OfflineBattle.chassis Servo error:', str(e))
						
						if hull is not None:
							try:
								chassis.node('V').attach(hull)
								LOG_DEBUG('OfflineBattle: hull attached to chassis.V')
							except Exception as e:
								LOG_DEBUG('OfflineBattle.attach hull error:', str(e))
								hull.position = Math.Vector3(spawn_pos)
								_add_model(hull)
						
							# Attach turret to hull node 'HP_turretJoint'
							if turret is not None:
								try:
									turret_mat = Math.Matrix()
									turret_mat.setIdentity()
									loaded_models['turret_mat'] = turret_mat
									hull.node('HP_turretJoint', turret_mat).attach(turret)
									LOG_DEBUG('OfflineBattle: turret attached to hull.HP_turretJoint')
								except Exception as e:
									LOG_DEBUG('OfflineBattle.attach turret error:', str(e))
								
								# Apply Camouflage and Emblems
								try:
									import items.vehicles as iv
									cust = iv.g_cache.customization(td.type.id[0])
									camo_kind = getattr(player.arena.arenaType, 'vehicleCamouflageKind', 0) if hasattr(player, 'arena') and hasattr(player.arena, 'arenaType') else 0
									camo_params = td.camouflages[camo_kind] if hasattr(td, 'camouflages') and len(td.camouflages) > camo_kind else None
									LOG_DEBUG('OfflineBattle.customization:', 'kind', camo_kind, 'params', camo_params)
									# Offline QoL: if the map-season slot is empty, fall back to any season
									# the player has painted - otherwise the bought camo never shows here.
									if (camo_params is None or camo_params[0] is None) and hasattr(td, 'camouflages'):
										for _ck in range(len(td.camouflages)):
											if td.camouflages[_ck] is not None and td.camouflages[_ck][0] is not None:
												camo_params = td.camouflages[_ck]
												LOG_DEBUG('OfflineBattle.customization: season fallback ->', _ck, camo_params)
												break
									if camo_params is not None and camo_params[0] is not None:
										camo = cust['camouflages'].get(camo_params[0]) if cust else None
										if camo is not None:
											tex = camo['texture']
											colors = camo['colors']
											defaultTiling = camo['tiling'].get(td.type.compactDescr)
											weights = Math.Vector4((colors[0]>>24)/255.0, (colors[1]>>24)/255.0, (colors[2]>>24)/255.0, (colors[3]>>24)/255.0)
											for p_name, p_mdl in [('chassis', chassis), ('hull', hull), ('turret', turret), ('gun', gun)]:
												if p_mdl is not None:
													excl = td.type.camouflageExclusionMask
													tiling = defaultTiling
													if tiling is None: tiling = td.type.camouflageTiling
													p_desc = getattr(td, p_name, None)
													if p_desc is not None:
														coeff = p_desc.get('camouflageTiling')
														if coeff is not None and tiling is not None:
															tiling = (tiling[0]*coeff[0], tiling[1]*coeff[1], tiling[2]*coeff[2], tiling[3]*coeff[3])
														if 'camouflageExclusionMask' in p_desc:
															excl = p_desc['camouflageExclusionMask']
													if excl != '' and tex != '':
														if p_name == 'chassis':
															# Chassis camo must go THROUGH the track fashion (wg_fashion), like the
															# original __updateCamouflage: a second WGBaseFashion on the chassis
															# detaches the scrolling track material (wheels spin, tracks freeze).
															loaded_models['_camo_args'] = (tex, excl, tiling, colors[0], colors[1], colors[2], colors[3], weights)
														else:
															fashion = getattr(p_mdl, 'wg_baseFashion', None)
															if fashion is None: fashion = p_mdl.wg_baseFashion = BigWorld.WGBaseFashion()
															fashion.setCamouflage(tex, excl, tiling, colors[0], colors[1], colors[2], colors[3], weights)
									
									import VehicleStickers
									emblemPositions = (
										('hull', hull, td.hull['emblemSlots']),
										('gun' if td.turret['showEmblemsOnGun'] else 'turret', gun if td.turret['showEmblemsOnGun'] else turret, td.turret['emblemSlots']),
										('turret' if td.turret['showEmblemsOnGun'] else 'gun', turret if td.turret['showEmblemsOnGun'] else gun, [])
									)
									if not hasattr(player, '_offhangar_stickers'): player._offhangar_stickers = []
									for cName, p_mdl, slots in emblemPositions:
										if p_mdl is not None:
											stickers = VehicleStickers.VehicleStickers(td, slots, cName == 'hull', None)
											try:
												stickers.attachStickers(p_mdl, p_mdl.node(''), False)
											except Exception:
												stickers.attachStickers(p_mdl, p_mdl.root, False)
											player._offhangar_stickers.append(stickers)
								except Exception as e:
									import traceback
									import traceback

									LOG_DEBUG('OfflineBattle.customization error:', str(e), traceback.format_exc())

								# Attach gun to turret node 'HP_gunJoint'
								if gun is not None:
									try:
										gun_mat = Math.Matrix()
										gun_mat.setIdentity()
										loaded_models['gun_mat'] = gun_mat
										turret.node('HP_gunJoint', gun_mat).attach(gun)
										LOG_DEBUG('OfflineBattle: gun attached to turret.HP_gunJoint')
										# Barrel recoil animation on the player's own gun
										player._offhangar_gun_recoil = _setup_gun_recoil(gun, td)
										# Hull rocking (shot impulse / pitch-roll swinging) on the chassis
										player._offhangar_swinging = _setup_swinging(chassis, td)
									except Exception as e:
										LOG_DEBUG('OfflineBattle.attach gun error:', str(e))

								try:
									import VehicleStickers
									_nodes = loaded_models['sticker_nodes'] = {
										'hull': chassis.node('V') if chassis else hull.node(''),
										'turret': hull.node('HP_turretJoint', turret_mat) if hull else turret.node(''),
										'gun': turret.node('HP_gunJoint', gun_mat) if turret else gun.node('')
									}
									_emblemPositions = (
										('hull', hull, td.hull['emblemSlots']),
										('gun' if td.turret['showEmblemsOnGun'] else 'turret', gun if td.turret['showEmblemsOnGun'] else turret, td.turret['emblemSlots']),
										('turret' if td.turret['showEmblemsOnGun'] else 'gun', turret if td.turret['showEmblemsOnGun'] else gun, [])
									)
									if not hasattr(player, '_offhangar_stickers'): player._offhangar_stickers = []
									if not hasattr(player, '_offhangar_sticker_map'): player._offhangar_sticker_map = {}
									for cName, p_mdl, slots in _emblemPositions:
										if p_mdl is not None:
											stickers = VehicleStickers.VehicleStickers(td, slots, cName == 'hull', None)
											p_node = _nodes.get(cName)
											if p_node is not None:
												stickers.attachStickers(p_mdl, p_node, False)
												player._offhangar_stickers.append(stickers)
												# Map by component so shell-hole decals can target the hit
												# part. Store the NODE too: attached component models report
												# a local (identity) matrix, so the node gives the world
												# transform needed to place the decal correctly.
												player._offhangar_sticker_map[cName] = (stickers, p_mdl, p_node)
								except Exception as e:
									import traceback
									LOG_DEBUG('OfflineBattle.stickers error:', str(e), traceback.format_exc())
					elif hull is not None:
						hull.position = Math.Vector3(spawn_pos)
						_add_model(hull)
						LOG_DEBUG('OfflineBattle.addModel OK: hull (no chassis)')
					
					root_model = chassis or hull
					ma.models = [root_model]
					ma.compoundModel = root_model
					LOG_DEBUG('OfflineBattle.compoundModel set, attempt:', _add_attempts[0])


					# Engine sounds are now initialized in _step_offline_physics
				
				except Exception as e:
					import traceback
					LOG_DEBUG('OfflineBattle._add_models_when_ready ERROR:', traceback.format_exc())
					if _add_attempts[0] < 10:
						BigWorld.callback(0.3, _add_models_when_ready)
			
			BigWorld.callback(0.2, _add_models_when_ready)
			
			# Set temporary compoundModel so camera logic doesn't fail
			root_model = loaded_models['chassis'] if loaded_models['chassis'] is not None else loaded_models['hull']
			ma.models = [root_model]
			ma.compoundModel = root_model

		try:
			for hitTester in td.getHitTesters():
				hitTester.loadBspModel()
		except Exception as e:
			LOG_DEBUG("Error loading hitTesters for player:", str(e))

		class _MockVeh(object):
			def __init__(self):
				self.damage_from_player = 0
				self.damage_from_bots = 0
				self.hits_from_player = 0
				self.matrix = Math.Matrix()
				self.matrix.setIdentity()
				self.position = Math.Vector3(spawn_pos)
				self.yaw = 0.0
				self.pitch = 0.0
				self.roll = 0.0
				self.filter = mf
				self.appearance = ma
				self.isPlayer = True
				self.typeDescriptor = td
				self.health = getattr(td, 'maxHealth', 400)
				self.maxHealth = getattr(td, 'maxHealth', 400)
				self.isStarted = True
				self.id = getattr(player, 'playerVehicleID', 0)
				self.model = getattr(self.appearance, 'compoundModel', None)
				
				class _ModelsDesc(object):
					def __getitem__(self, key):
						if key in loaded_models and loaded_models.get(key) is not None:
							return {'model': loaded_models[key]}
						# Return None model so SniperCamera falls through
						# to the MatrixProduct branch (which uses getOwnVehicleMatrix)
						return {'model': None}
				self.appearance.modelsDesc = _ModelsDesc()
			def isAlive(self): return True
			def getAutorotation(self): return False
			def __getattr__(self, name): return None
			
			def getComponents(self):
				import Math
				res = []
				m = Math.Matrix()
				m.setIdentity()
				res.append((self.typeDescriptor.chassis, m))
				
				hullOffset = self.typeDescriptor.chassis['hullPosition']
				m = Math.Matrix()
				m.setTranslate(-hullOffset)
				res.append((self.typeDescriptor.hull, m))
				
				if getattr(self, 'isPlayer', False):
					tYaw = turret_matrix_local.yaw
					gPitch = gun_matrix.pitch if 'gun_matrix' in globals() else 0.0
				else:
					tYaw = getattr(self, '_t_mat', m).yaw
					gPitch = getattr(self, '_g_mat', m).pitch
					
				turretMatrix = Math.Matrix()
				turretMatrix.setTranslate(-hullOffset - self.typeDescriptor.hull['turretPositions'][0])
				m = Math.Matrix()
				m.setRotateY(-tYaw)
				turretMatrix.postMultiply(m)
				res.append((self.typeDescriptor.turret, turretMatrix))
				
				gunMatrix = Math.Matrix()
				gunMatrix.setTranslate(-self.typeDescriptor.turret['gunPosition'])
				m = Math.Matrix()
				m.setRotateX(-gPitch)
				gunMatrix.postMultiply(m)
				gunMatrix.preMultiply(turretMatrix)
				res.append((self.typeDescriptor.gun, gunMatrix))
				
				return res

			def collideSegment(self, startPoint, endPoint, skipGun=False):
				import Math
				worldToVehMatrix = Math.Matrix(self.matrix)
				worldToVehMatrix.invert()
				startPoint = worldToVehMatrix.applyPoint(startPoint)
				endPoint = worldToVehMatrix.applyPoint(endPoint)
				res_closest = None
				all_hits = []
				for (compDescr, compMatrix) in self.getComponents():
					if skipGun and compDescr.get('itemTypeName') == 'vehicleGun':
						continue
					if not hasattr(compDescr.get('hitTester'), 'localHitTest'):
						continue
					collisions = compDescr['hitTester'].localHitTest(compMatrix.applyPoint(startPoint), compMatrix.applyPoint(endPoint))
					if collisions is None:
						continue
					for (dist, _, hitAngleCos, matKind) in collisions:
						matInfo = compDescr.get('materials', {}).get(matKind)
						all_hits.append((dist, hitAngleCos, matInfo, compDescr))
						if res_closest is None or res_closest[0] >= dist:
							res_closest = (dist, hitAngleCos, getattr(matInfo, 'armor', 0) if matInfo is not None else 0)
				if res_closest is not None:
					return (res_closest[0], res_closest[1], res_closest[2], all_hits)
				return None

		# Clear persistent data from previous offline battles, BUT keep the player!
		try:
			global G_OFFHANGAR_SHOTS_FIRED
			G_OFFHANGAR_SHOTS_FIRED = 0
			player = BigWorld.player()
			if hasattr(player, 'arena') and player.arena is not None:
				p_id = getattr(player, 'playerVehicleID', -1)
				if hasattr(player.arena, 'vehicles') and type(player.arena.vehicles) is dict:
					p_veh = player.arena.vehicles.get(p_id, None)
					player.arena.vehicles.clear()
					if p_veh is not None:
						player.arena.vehicles[p_id] = p_veh
				if hasattr(player.arena, 'statistics') and type(player.arena.statistics) is dict:
					p_stat = player.arena.statistics.get(p_id, None)
					player.arena.statistics.clear()
					if p_stat is not None:
						# Reset frags to 0 for the new battle!
						if 'frags' in p_stat: p_stat['frags'] = 0
						player.arena.statistics[p_id] = p_stat
		except: pass
		
		mock_veh = _MockVeh()

		mock_vehicles = {getattr(BigWorld.player(), 'playerVehicleID', -1): mock_veh}
		global G_MOCK_VEHICLES
		G_MOCK_VEHICLES = mock_vehicles
		# The sticker list lives on the persistent account entity; without this
		# reset it grew by ~6 VehicleStickers objects every battle.
		try: player._offhangar_stickers = []
		except Exception: pass

		# Wrap once and resolve the mock registry at call time: re-wrapping every
		# battle nested the previous wrapper in _orig_entity, so each battle's
		# whole mock_vehicles dict (bots, descriptors, model refs) stayed
		# reachable forever and the lookup chain grew battle by battle.
		if not getattr(BigWorld, '_offh_entity_wrapped', False):
			_orig_entity = BigWorld.entity
			def _mock_entity(eid):
				_mv = globals().get('G_MOCK_VEHICLES', {}) or {}
				if eid == getattr(BigWorld.player(), 'playerVehicleID', -1) and eid in _mv:
					return _mv[eid]
				orig_e = _orig_entity(eid)
				if orig_e is None and eid in _mv:
					return _mv[eid]
				return orig_e
			BigWorld.entity = _mock_entity
			BigWorld._offh_entity_wrapped = True
		# Minimap & friends read BigWorld.entities[id] directly (minimap.pyc:548
		# matrix = BigWorld.entities[id].matrix). Mock bots are not real engine
		# entities -> KeyError on every notifyVehicleStart ('GUI Add error') and
		# no bot ever reached the minimap. Wrap the dict: real entities first,
		# then the mock registry; enumeration stays original-only (engine-safe).
		if not getattr(BigWorld, '_offh_entities_wrapped', False):
			class _OffhEntities(object):
				def __init__(self, orig):
					self._o = orig
				def __getitem__(self, k):
					try:
						return self._o[k]
					except KeyError:
						_mv = globals().get('G_MOCK_VEHICLES', {}) or {}
						if k in _mv:
							return _mv[k]
						raise
				def get(self, k, d=None):
					try:
						return self[k]
					except KeyError:
						return d
				def __contains__(self, k):
					if k in self._o:
						return True
					return k in (globals().get('G_MOCK_VEHICLES', {}) or {})
				def keys(self):
					return self._o.keys()
				def values(self):
					return self._o.values()
				def items(self):
					return self._o.items()
				def iteritems(self):
					return self._o.iteritems()
				def itervalues(self):
					return self._o.itervalues()
				def __iter__(self):
					return iter(self._o)
				def __len__(self):
					return len(self._o)
				def __getattr__(self, n):
					return getattr(self._o, n)
			BigWorld.entities = _OffhEntities(BigWorld.entities)
			BigWorld._offh_entities_wrapped = True

		player.getVehicleAttached = lambda: mock_veh
		player.getOwnVehicleMatrix = lambda: veh_matrix
		player.getOwnVehiclePosition = lambda: mock_veh.position
		player._offhangar_gui_visible = False
		def _mock_handleKey(key, isDown, mods=0):
			aih = getattr(player, 'inputHandler', None)
			if aih is not None and hasattr(aih, 'handleKeyEvent'):
				try: return aih.handleKeyEvent(key, isDown, mods)
				except: pass
			return False
		player.handleKey = _mock_handleKey

		def _offh_mouse_delta(args):
			try:
				if len(args) == 1 and hasattr(args[0], 'dx'):
					return (float(args[0].dx), float(args[0].dy), float(args[0].dz))
				if len(args) >= 3:
					return (float(args[0]), float(args[1]), float(args[2]))
			except Exception:
				pass
			return (0.0, 0.0, 0.0)

		def _offh_apply_zoom_attrs(ctrl, dz):
			# Ported: some 0.8.2 camera handlers silently reject wheel input in the
			# offline shell. Touch camera-only zoom fields (never aiming/ballistics).
			try:
				dz = float(dz)
				if abs(dz) <= 0.0001:
					return False
			except Exception:
				return False
			try:
				candidates = []
				cam = getattr(ctrl, 'camera', None)
				for obj in (cam, BigWorld.camera()):
					if obj is not None and obj not in candidates:
						candidates.append(obj)
				for obj in list(candidates):
					for name in ('_ArcadeCamera__cam', '_SniperCamera__cam', '_StrategicCamera__cam', '_camera', 'camera', 'cam'):
						try:
							sub = getattr(obj, name, None)
							if sub is not None and sub not in candidates:
								candidates.append(sub)
						except Exception:
							pass
				handled = False
				scale = 1.0 - max(-3.0, min(3.0, dz)) * 0.12
				if scale < 0.35:
					scale = 0.35
				if scale > 2.25:
					scale = 2.25
				# NEVER touch SniperCamera/StrategicCamera zoom state here: those
				# modes render their own camera offline and apply dz natively.
				# SniperCamera.__setupZoom walks the discrete zooms list and exits
				# to arcade only on the EXACT check zoom == zooms[0]; a scaled
				# float (2.0 -> 1.76) breaks both the levels and the scroll-out.
				attrs = ('distance', 'dist', 'height', 'curHeight', 'curDistance', '_distance', '_dist', '_height', '_curHeight', '_curDistance', '_ArcadeCamera__distance', '_ArcadeCamera__dist', '_ArcadeCamera__curDist')
				for obj in candidates:
					for name in attrs:
						try:
							old = getattr(obj, name)
						except Exception:
							continue
						try:
							if isinstance(old, (int, long, float)):
								new = float(old) * scale
								if new < 1.0:
									new = 1.0
								if new > 1200.0:
									new = 1200.0
								setattr(obj, name, new)
								handled = True
						except Exception:
							pass
				return handled
			except Exception:
				return False

		def _offh_mouse_cam_fallback(aih, args):
			try:
				ctrl = getattr(aih, 'ctrl', None)
				if ctrl is None:
					return False
				cam = getattr(ctrl, 'camera', None)
				dx, dy, dz = _offh_mouse_delta(args)
				handled = False
				if cam is not None and hasattr(cam, 'update'):
					try:
						# clamp dz like the game's own paths (_clamp(-1, 1, dz))
						# so one notch never jumps several zoom steps
						cam.update(dx, dy, max(-1.0, min(1.0, dz)))
						handled = True
					except Exception:
						pass
				if abs(dz) > 0.0001 and _offh_apply_zoom_attrs(ctrl, dz):
					handled = True
				return handled
			except Exception:
				return False

		def _mock_handleMouse(*args):
			# Ported arty-camera fix: without this hook the wheel never reaches the
			# strategic camera offline, so the SPG view height could not be changed.
			try:
				aih = getattr(player, 'inputHandler', None)
				if aih is not None and hasattr(aih, 'handleMouseEvent'):
					try:
						if len(args) == 1 and hasattr(args[0], 'dx'):
							_ret = aih.handleMouseEvent(args[0].dx, args[0].dy, args[0].dz)
						else:
							_ret = aih.handleMouseEvent(*args)
						if (not _ret) and abs(_offh_mouse_delta(args)[2]) > 0.0001:
							if _offh_mouse_cam_fallback(aih, args):
								return True
						return _ret
					except Exception:
						if _offh_mouse_cam_fallback(aih, args):
							return True
			except Exception:
				pass
			return False
		player.handleMouseEvent = _mock_handleMouse
		
		import game
		if not getattr(game, '_offhangar_hooked', False):
			game._offhangar_hooked = True
			orig_game_handleKeyEvent = game.handleKeyEvent
			def _mock_game_handleKeyEvent(event):
				# NO ESC handling here! The flash menu handles ESC itself (on key
				# DOWN) and fires Battle.cursorVisibility on BOTH open and close -
				# proven by the CursorDBG log - and the patched cursorVisibility
				# below drives the input gate from it. The old key-UP toggle here
				# double-acted on the same press, always leaving the state inverted
				# from the actual menu (aim stuck with cursor shown after closing,
				# or menu open with no cursor).
				return orig_game_handleKeyEvent(event)
			game.handleKeyEvent = _mock_game_handleKeyEvent
			# Wheel: offline the flash GUI often EATS wheel events before they
			# reach the AIH (InputDBG: in sniper the fullscreen binoculars ate
			# 19 of 21 events), so the native zoom path never sees them. The old
			# unconditional fallback masked that but also ran when the native
			# path DID handle the wheel - double zoom in arcade, and its direct
			# _SniperCamera__zoom writes broke the discrete 2/4/8 walk and the
			# scroll-out exit (exact zoom == zooms[0] check in __setupZoom).
			# Correct rule: detect whether the native path consumed this wheel
			# event, and only if not, re-deliver dz through the camera wrapper's
			# own update() so all stock logic (zoom walk, clamps, mode
			# transitions) still runs:
			#  - Arcade/Strategic apply dz SYNCHRONOUSLY to their __camDist, so
			#    an unchanged __camDist right after the orig call means the
			#    event was eaten. (Their __camDist also legitimately stays put
			#    at the range ends - re-delivering there is a no-op, except the
			#    min-end where it correctly (re)fires the mode transition.)
			#  - Sniper stores dz in __dxdydz and applies it next frame, so a
			#    zero stored dz right after the orig call means it was eaten;
			#    re-deliver preserving any stored dx/dy from move events.
			orig_game_handleMouseEvent = game.handleMouseEvent
			def _mock_game_handleMouseEvent(event):
				pre = None
				try:
					dz = float(getattr(event, 'dz', 0.0))
					if abs(dz) > 0.0001:
						p = BigWorld.player()
						if p is not None and getattr(p, 'isOffline', False):
							aih = getattr(p, 'inputHandler', None)
							ctrl = getattr(aih, 'ctrl', None)
							cam = getattr(ctrl, 'camera', None)
							# gated input (pause menu open / cursor detached):
							# eaten on purpose, do not zoom
							if cam is not None and getattr(aih, '_AvatarInputHandler__isStarted', False) and getattr(aih, '_AvatarInputHandler__detachCount', 0) >= 0:
								dist = getattr(cam, '_ArcadeCamera__camDist', None)
								if dist is None:
									dist = getattr(cam, '_StrategicCamera__camDist', None)
								pre = (aih, ctrl, cam, None if dist is None else float(dist), dz)
				except Exception:
					pre = None
				result = orig_game_handleMouseEvent(event)
				if pre is not None:
					try:
						aih, ctrl, cam, dist_before, dz = pre
						if getattr(aih, 'ctrl', None) is ctrl:
							dzc = max(-1.0, min(1.0, dz))
							if dist_before is not None:
								dist_after = getattr(cam, '_ArcadeCamera__camDist', None)
								if dist_after is None:
									dist_after = getattr(cam, '_StrategicCamera__camDist', None)
								if dist_after is not None and abs(float(dist_after) - dist_before) < 0.0001:
									cam.update(0, 0, dzc)
							else:
								stored = getattr(cam, '_SniperCamera__dxdydz', None)
								if stored is not None and abs(float(stored[2])) < 0.0001:
									cam.update(float(stored[0]), float(stored[1]), dzc)
					except Exception:
						pass
				return result
			game.handleMouseEvent = _mock_game_handleMouseEvent
			# Route the flash cursor callback through the same state-setter so
			# menu-button closes restore aiming (fixes the stuck-aim repro).
			try:
				from gui.Scaleform.Battle import Battle as _BattleWnd
				if not getattr(_BattleWnd, '_offh_cursor_patched', False):
					_orig_cv = _BattleWnd.cursorVisibility
					def _offh_cursorVisibility(self, callbackId, visible, x=None, y=None, customCall=False, enableAiming=True):
						_orig_cv(self, callbackId, visible, x, y, customCall, enableAiming)
						try:
							import BigWorld
							p = BigWorld.player()
							if p is not None and getattr(p, 'isOffline', False):
								LOG_DEBUG('CursorDBG: flash cursorVisibility ->', visible)
								_offh_set_battle_gui_mode(visible)
						except Exception:
							pass
					_BattleWnd.cursorVisibility = _offh_cursorVisibility
					_BattleWnd._offh_cursor_patched = True
			except Exception:
				LOG_CURRENT_EXCEPTION()
			# Alt-tab fix: offline the aim object can be None during a device recreate;
			# the exception aborted game.onRecreateDevice mid-way so the GUI resetters
			# never ran and HUD/input came back broken after tabbing back in.
			try:
				import AvatarInputHandler as _AIHmod
				if not getattr(_AIHmod.AvatarInputHandler, '_offh_rc_wrapped', False):
					_orig_rc = _AIHmod.AvatarInputHandler._AvatarInputHandler__onRecreateDevice
					def _offh_safe_rc(self, *a, **kw):
						try:
							return _orig_rc(self, *a, **kw)
						except Exception:
							pass
					_AIHmod.AvatarInputHandler._AvatarInputHandler__onRecreateDevice = _offh_safe_rc
					_AIHmod.AvatarInputHandler._offh_rc_wrapped = True
			except Exception:
				pass
		
		def _leaveArena():
			_battle_finished[0] = True
			# Exactly ONE exit path may tear the battle down. Player death
			# schedules _exit_battle(+3s) AND triggers battle results ->
			# _leaveArena: both ran the full teardown, so the hangar was
			# destroyed + re-inited TWICE, the second init racing the first
			# one's async load -> broken garage return and a leaked
			# half-loaded hangar space per occurrence.
			if _exit_done[0]:
				return
			_exit_done[0] = True
			# ESC runs battle-teardown AND the synchronous hangar load in this
			# ONE call. Free the whole battle (models, sounds, mocks, mapped
			# battle space) FIRST, or g_hangarSpace.init below OOM-crashes.
			try:
				_offh_battle_sweep('quit')
			except:
				pass
			try: player._offhangar_stickers = []
			except Exception: pass
			try:
				import SoundGroups as _SG
				if getattr(_SG, 'g_instance', None) is not None:
					_SG.g_instance.enableArenaSounds(False)
					_SG.g_instance.enableLobbySounds(True)
			except Exception: pass
			try:
				_aih = getattr(player, 'inputHandler', None)
				if _aih is not None:
					try: _aih._AvatarInputHandler__isStarted = False
					except: pass
					for _cm in getattr(_aih, '_AvatarInputHandler__ctrls', {}).values():
						try: _cm.destroy()
						except: pass
					player.inputHandler = None
			except Exception: pass

			try:
				from gui import WindowsManager
				if hasattr(WindowsManager.g_windowsManager, 'destroyBattle'):
					WindowsManager.g_windowsManager.destroyBattle()
				else:
					WindowsManager.g_windowsManager.hideAll()
				if hasattr(WindowsManager.g_windowsManager, 'showLobby'):
					WindowsManager.g_windowsManager.showLobby()
			except Exception: pass

			try:
				import BigWorld
				BigWorld.camera(None)
				BigWorld.worldDrawEnabled(True)
			except: pass

			try:
				from gui.Scaleform.utils.HangarSpace import g_hangarSpace
				if g_hangarSpace is not None:
					try: g_hangarSpace.destroy()
					except Exception: pass
					
					# Prevent showLobby from destroying the space
					def _mock_refreshSpace(self, isPremium):
						pass
					g_hangarSpace.__class__.refreshSpace = _mock_refreshSpace
					
					# Force premium
					def _mock_getSpacePath(self, isPremium):
						return self._HangarSpace__space.getDefSpacePath(True)
					g_hangarSpace.__class__._HangarSpace__getSpacePath = _mock_getSpacePath
					
					# Init manually
					# WG 'no man's land' purge: hangar destroyed, nothing active, before re-init.
					_offh_safe_purge()
					g_hangarSpace.init(True)
			except Exception: pass


			try:
				global g_offline_models
				# Clear FIRST (see sweep 'models' stage): delModel's pending error
				# raises at loop exhaustion and would skip a post-loop clear,
				# leaking the dead battle's models into the next one.
				_gm_list = list(g_offline_models)
				g_offline_models = []
				for m in _gm_list:
					_offh_del_model(m)
			except Exception: pass
			try:
				import gui.mods.offhangar._constants as _c
				for _e in BigWorld.entities.values():
					if _e.__class__.__name__ in ('PlayerAccount', 'Account'):
						_e._offline_allow_become_non_player = True
						if hasattr(_e, '_offhangar_orig_stats') and _e._offhangar_orig_stats is not None:
							_e.stats = _e._offhangar_orig_stats
						try: _e.showGUI(_c.OFFLINE_GUI_CTX)
						except Exception: pass
			except Exception: pass
			
		player.leaveArena = _leaveArena
		
		def _setGUIVisible(visible):
			aih = getattr(player, 'inputHandler', None)
			if aih is not None:
				try: aih._AvatarInputHandler__isGUIVisible = visible
				except: pass
				if hasattr(aih, 'setGUIVisible'):
					try: aih.setGUIVisible(visible)
					except: pass
		player.setGUIVisible = _setGUIVisible
		
		player.getAutorotation = lambda: False
		player.enableOwnVehicleAutorotation = lambda val: None

		class FakePositionControl(object):
			def bindToVehicle(self, *a, **k): pass
			def followCamera(self, *a, **k): pass
			def moveTo(self, *a, **k): pass
		player.positionControl = FakePositionControl()

		class FakeStats(object):
			def getCache(self, cb): cb(1, {})
			def __getattr__(self, name): return lambda *a, **k: None
			
		if not hasattr(player, '_offhangar_orig_stats'):
			player._offhangar_orig_stats = getattr(player, 'stats', None)
		player.stats = FakeStats()

		class FakeGunRotator(object):
			def __init__(self):
				self.markerInfo = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
				self.dispersionAngle = 0.1
			def getShotParams(self, targetPos, *a, **kw):
				import BigWorld, Math
				try:
					from projectile_trajectory import getShotAngles
					descr = BigWorld.player().vehicleTypeDescriptor
					speed = descr.shot['speed']
					gravity = descr.shot['gravity']
					mat = BigWorld.player().getOwnVehicleMatrix()
					
					# Get exact required gun elevation angle to hit targetPos
					try:
						(shotTurretYaw, shotGunPitch) = getShotAngles(descr, mat, (0, 0), targetPos)
					except Exception:
						shotTurretYaw, shotGunPitch = getattr(self, '_turret_yaw', 0.0), getattr(self, '_gun_pitch', 0.0)
					
					# Clamp to limits so trajectory doesn't draw where gun can't reach
					import math
					try:
						pl = descr.gun['pitchLimits']
						from gun_rotation_shared import calcPitchLimitsFromDesc
						limits = calcPitchLimitsFromDesc(shotTurretYaw, pl)
						if shotGunPitch < limits[0]: shotGunPitch = limits[0]
						elif shotGunPitch > limits[1]: shotGunPitch = limits[1]
					except: pass
					
					try:
						yl = descr.gun.get('turretYawLimits', None)
						if yl is None and descr.turret is not None:
							yl = descr.turret.get('yawLimits', None)
						if yl is not None:
							min_yaw = float(yl[0])
							max_yaw = float(yl[1])
							if abs(min_yaw) > 10.0:
								min_yaw = math.radians(min_yaw)
								max_yaw = math.radians(max_yaw)
							if shotTurretYaw < min_yaw: shotTurretYaw = min_yaw
							elif shotTurretYaw > max_yaw: shotTurretYaw = max_yaw
					except: pass
					
					# Calculate actual world space gun position and velocity vector
					turretOffs = descr.hull['turretPositions'][0] + descr.chassis['hullPosition']
					gunOffs = descr.turret['gunPosition']
					turretWorldMatrix = Math.Matrix()
					turretWorldMatrix.setRotateY(shotTurretYaw)
					turretWorldMatrix.translation = turretOffs
					turretWorldMatrix.postMultiply(mat)
					position = turretWorldMatrix.applyPoint(gunOffs)
					gunWorldMatrix = Math.Matrix()
					gunWorldMatrix.setRotateX(shotGunPitch)
					gunWorldMatrix.postMultiply(turretWorldMatrix)
					vector = gunWorldMatrix.applyVector(Math.Vector3(0, 0, speed))
					
					return (position, vector, Math.Vector3(0, -gravity, 0))
				except Exception as e:
					LOG_DEBUG('OfflineBattle getShotParams ERROR:', str(e))
					# fallback
					try:
						speed = BigWorld.player().vehicleTypeDescriptor.shot['speed']
						gravity = BigWorld.player().vehicleTypeDescriptor.shot['gravity']
					except:
						speed, gravity = 250.0, 9.81
					if hasattr(self, '_gun_pos') and hasattr(self, '_gun_dir'):
						return (self._gun_pos, self._gun_dir.scale(speed), Math.Vector3(0, -gravity, 0))
					startPos = BigWorld.player().getOwnVehiclePosition()
					startPos.y += 2.0
					v0 = BigWorld.camera().direction
					return (startPos, v0.scale(speed), Math.Vector3(0, -gravity, 0))
			def _VehicleGunRotator__getCurShotPosition(self):
				import BigWorld, Math
				try:
					speed = BigWorld.player().vehicleTypeDescriptor.shot['speed']
				except:
					speed = 250.0
				if hasattr(self, '_gun_pos') and hasattr(self, '_gun_dir'):
					return (self._gun_pos, self._gun_dir.scale(speed))
				startPos = BigWorld.player().getOwnVehiclePosition()
				startPos.y += 2.0
				v0 = BigWorld.camera().direction
				return (startPos, v0.scale(speed))
		player.gunRotator = FakeGunRotator()

		# Report real simulated speeds so dispersion reacts to movement
		# (_veh_velocity/_veh_turn_velocity are defined below; resolved at call time)
		player.getOwnVehicleSpeeds = lambda: (_veh_velocity[0], _veh_turn_velocity[0])
		player.autoAim = lambda val: None

		if hasattr(player, 'arena') and player.arena is not None:
			if not hasattr(player.arena, 'collideWithSpaceBB') or not callable(getattr(player.arena, 'collideWithSpaceBB', None)):
				player.arena.collideWithSpaceBB = lambda *a, **kw: None

		veh_yaw     = [spawn_dir.z]
		turret_yaw  = [0.0]   # relative to hull
		gun_pitch   = [0.0]   # gun elevation
		veh_pos = [spawn_pos.x, spawn_pos.y, spawn_pos.z]
		turret_matrix = Math.Matrix()
		turret_matrix.setTranslate(Math.Vector3(spawn_pos.x, spawn_pos.y + 2.0, spawn_pos.z))
		turret_matrix_local = Math.Matrix()

		# Read turret/gun rotation limits from vehicle descriptor
		_turret_rot_speed = 1.5  # rad/s default
		_gun_min_pitch    = -0.35  # ~-20 deg (ELEVATION - UP) default
		_gun_max_pitch    =  0.15  # ~+8.6 deg (DEPRESSION - DOWN) default
		_gun_pitch_desc   = None   # full 0.8.2 pitchLimits descriptor (yaw-dependent)
		_gun_pitch_speed  = 0.75   # rad/s fallback vertical aim speed
		_gun_min_yaw      = -3.14159
		_gun_max_yaw      =  3.14159
		try:
			if td is not None:
				rot = td.turret.get('rotationSpeed', None)
				if rot is not None:
					_turret_rot_speed = float(rot)  # descriptor stores rad/s
				pl = td.gun.get('pitchLimits', None)
				if pl is not None:
					try:
						if isinstance(pl, dict):
							# 0.8.2 descriptor: {'basic': (minRad, maxRad), 'absolute': (...),
							# optional 'front'/'back'/'transition'} - values ALREADY in radians.
							# (The old minPitch/minAngle keys never existed in this format, so
							# every tank silently fell back to the hardcoded default limits.)
							_gun_pitch_desc = pl
							lim = pl.get('basic') or pl.get('absolute')
							if lim:
								_gun_min_pitch = float(lim[0])
								_gun_max_pitch = float(lim[1])
						elif isinstance(pl, (list, tuple)) and len(pl) >= 2:
							_gun_min_pitch = float(pl[0])
							_gun_max_pitch = float(pl[1])
					except Exception as pe:
						LOG_DEBUG('OfflineBattle pitch parsing error:', str(pe))
				# Vertical aim speed from the descriptor (radians/s) instead of the
				# old hardcoded 2.5 rad/s (~143 deg/s - several times too fast).
				try:
					_gs = td.gun.get('rotationSpeed', None)
					if _gs:
						_gun_pitch_speed = float(_gs)
				except Exception:
					pass
				try:
					import math as _math
					LOG_DEBUG('PitchDBG: elevation=%.1f deg (up), depression=%.1f deg (down), yawDependent=%s, aimSpeed=%.1f deg/s' % (
						-_math.degrees(_gun_min_pitch), _math.degrees(_gun_max_pitch),
						_gun_pitch_desc is not None and (('front' in _gun_pitch_desc) or ('back' in _gun_pitch_desc)),
						_math.degrees(_gun_pitch_speed)))
				except Exception:
					pass
				yl = td.gun.get('turretYawLimits', None)
				if yl is None and td.turret is not None:
					yl = td.turret.get('yawLimits', None)
				if yl is not None:
					import math as _math
					_gun_min_yaw = float(yl[0])
					_gun_max_yaw = float(yl[1])
					if abs(_gun_min_yaw) > 10.0 or abs(_gun_max_yaw) > 10.0:
						_gun_min_yaw = _math.radians(_gun_min_yaw)
						_gun_max_yaw = _math.radians(_gun_max_yaw)
		except Exception as e:
			LOG_DEBUG('OfflineBattle.limits error:', str(e))

		_tick_counter = [0]

		# Engine and track sound state
		_sound_state = {
			'engine_sound': None,
			'tread_sound': None,
			'last_engine_event': '',
			'last_tread_event': '',
		}

		# Determine tank class for sound events
		_tank_class = 'medium'
		try:
			if td is not None:
				tags = td.type.tags if hasattr(td, 'type') and hasattr(td.type, 'tags') else set()
				if 'lightTank' in tags: _tank_class = 'light'
				elif 'heavyTank' in tags: _tank_class = 'heavy'
				elif 'SPG' in tags or 'AT-SPG' in tags: _tank_class = 'SAU'
				else: _tank_class = 'medium'
			LOG_DEBUG('OfflineBattle.tank_class:', _tank_class)
		except Exception as e:
			LOG_DEBUG('OfflineBattle.tank_class error:', str(e))

		# Map tank class to FMOD event prefix
		_engine_idle_event = '/tanks/%s/%s/%s' % (
			{'light': 'light', 'heavy': 'heavy', 'medium': 'medium', 'SAU': 'medium'}.get(_tank_class, 'medium'),
			{'light': 'MC-1', 'heavy': 'IS_2', 'medium': 'tiger', 'SAU': 'tiger'}.get(_tank_class, 'tiger'),
			{'light': 'idle', 'heavy': 'IS_2_stand', 'medium': 'tiger_idle', 'SAU': 'tiger_idle'}.get(_tank_class, 'tiger_idle'),
		)
		_engine_run_event = '/tanks/%s/%s/%s' % (
			{'light': 'light', 'heavy': 'heavy', 'medium': 'medium', 'SAU': 'medium'}.get(_tank_class, 'medium'),
			{'light': 'MC-1', 'heavy': 'IS_2', 'medium': 'tiger', 'SAU': 'tiger'}.get(_tank_class, 'tiger'),
			{'light': 'run', 'heavy': 'heavy_tank_run_state2', 'medium': 'medium_tank_state2', 'SAU': 'medium_tank_state2'}.get(_tank_class, 'medium_tank_state2'),
		)
		_tread_prefix = '/tanks/tanks_treads/%s_tank' % ({'SAU': 'SAU'}.get(_tank_class, _tank_class))

# --- GUN MECHANICS STATE ---
		_gun_state = {
			'base_dispersion': 0.1,
			'after_shot': 1.5,
			'aim_time': 2.0,
			'clip_size': 1,
			'clip_reload': 2.0,
			'reload': 5.0,
			'ammo': 100,
			'clip': 1,
			'reloadTime': 0.0,
			'dispersion': 0.1,
			'initialized': False,
			'shot_index': 0
		}

		_engine_state = {'init': False, 'snd1': None, 'snd2': None}
		globals()['g_offh_engine_state'] = _engine_state
		
		_veh_velocity = [0.0]        # m/s, forward speed
		_veh_turn_velocity = [0.0]   # rad/s, current hull rotation speed
		_last_tick_time = [BigWorld.time()]
		_veh_vert_vel = [0.0]        # m/s, vertical (falling) speed
		_veh_airborne = [False]      # True while the hull has left the ground
		
		# === WoT-style physics parameters ===
		import math
		_phys_mass           = 5730.0     # kg (total vehicle mass)
		_phys_enginePowerHP  = 45.0       # HP (engine power)
		_phys_speedFwd       = 32.0 / 3.6 # m/s (forward speed limit)
		_phys_speedBwd       = 12.0 / 3.6 # m/s (backward speed limit)
		_phys_chassisRotSpd  = math.radians(38.0) # rad/s (chassis rotation speed)
		_phys_terrainResist  = (1.1, 1.4, 2.6)    # (hard, medium, soft) coefficients
		_phys_specificFriction = 0.6867              # rolling friction coefficient
		
		# Try to read actual values from the vehicle descriptor
		try:
			_tdp = td.physics
			LOG_DEBUG('OfflineBattle.PHYSICS_KEYS:', str(_tdp.keys()) if hasattr(_tdp, 'keys') else str(type(_tdp)))
			
			if 'weight' in _tdp:
				_phys_mass = float(_tdp['weight'])
			if 'enginePower' in _tdp:
				# Engine power in td.physics is already in Watts
				_phys_enginePowerW = float(_tdp['enginePower'])
			else:
				_phys_enginePowerW = _phys_enginePowerHP * 746.0
				
			if 'speedLimits' in _tdp:
				# Speed limits in td.physics are already in m/s
				_phys_speedFwd = float(_tdp['speedLimits'][0])
				_phys_speedBwd = float(_tdp['speedLimits'][1])
			if 'terrainResistance' in _tdp:
				_tr = _tdp['terrainResistance']
				_phys_terrainResist = (float(_tr[0]), float(_tr[1]), float(_tr[2]))
			if 'specificFriction' in _tdp:
				_phys_specificFriction = float(_tdp['specificFriction'])
		except Exception as e:
			LOG_DEBUG('OfflineBattle.physics_read_1:', str(e))
			_phys_enginePowerW = _phys_enginePowerHP * 746.0
		
		# Try to read rotation speed from chassis descriptor
		try:
			if hasattr(td, 'chassis') and 'rotationSpeed' in td.chassis:
				_raw_rot = float(td.chassis['rotationSpeed'])
				# Descriptor already stores rad/s; only convert if the value looks like deg/s
				_phys_chassisRotSpd = math.radians(_raw_rot) if _raw_rot > 6.3 else _raw_rot
		except Exception as e:
			LOG_DEBUG('OfflineBattle.physics_read_2:', str(e))
		
		# Try rotationSpeedLimit from physics dict
		try:
			if 'rotationSpeedLimit' in _tdp:
				_phys_chassisRotSpd = float(_tdp['rotationSpeedLimit'])
		except Exception:
			pass
		
		# Use hard terrain by default (index 0)
		# Use hard terrain by default (index 0)
		_phys_terrainCoeff = _phys_terrainResist[0]
		# Gravity
		_phys_gravity = 9.81
		
		LOG_DEBUG('OfflineBattle.PHYSICS: mass=%.0f, power=%.0fHP(%.0fW), fwd=%.1f m/s, bwd=%.1f m/s, rot=%.1f deg/s, terrain=(%.2f,%.2f,%.2f), friction=%.4f' % (
			_phys_mass, _phys_enginePowerHP, _phys_enginePowerW, _phys_speedFwd, _phys_speedBwd,
			math.degrees(_phys_chassisRotSpd), _phys_terrainResist[0], _phys_terrainResist[1], _phys_terrainResist[2],
			_phys_specificFriction))
		_battle_finished = [False]
		_exit_done = [False]  # once-guard shared by ALL exit paths (leaveArena / death / K)
		# One battle = one generation: loops of an older battle see the bump
		# and stop instead of stacking up (every stale loop pins its whole
		# battle graph -> the 32-bit client runs out of memory on start #3).
		globals()['g_offh_battle_gen'] = (globals().get('g_offh_battle_gen', 0) or 0) + 1
		_offh_my_gen = [globals()['g_offh_battle_gen']]
		_offh_seen_arena = [False]
		_offh_seen_bw = [False]
		
		global g_base_capture
		g_base_capture = {1: {'points': 0}, 2: {'points': 0}}
		
		global g_capture_tick_ref
		def trigger_battle_results(winnerTeam=1):
			import BigWorld
			player = BigWorld.player()
			if player is None: return
			try:
				from gui.SystemMessages import SM_TYPE, pushMessage
				pushMessage('Offline battle finished. Returning to Hangar...'.encode('utf-8'), SM_TYPE.Information)
			except Exception as e: pass
			
			try:
				import MusicController
				if hasattr(MusicController, 'g_musicController') and MusicController.g_musicController:
					_mc = MusicController.g_musicController
					try: _mc.stop()
					except: pass
					evt = None
					p_team = getattr(player, 'team', 1)
					if winnerTeam == p_team:
						evt = getattr(MusicController, 'MUSIC_EVENT_COMBAT_VICTORY', getattr(MusicController, 'MUSIC_EVENT_VICTORY', 'music_victory'))
					elif winnerTeam != 0:
						evt = getattr(MusicController, 'MUSIC_EVENT_COMBAT_LOSE', getattr(MusicController, 'MUSIC_EVENT_LOSE', 'music_lose'))
					else:
						evt = getattr(MusicController, 'MUSIC_EVENT_COMBAT_DRAW', getattr(MusicController, 'MUSIC_EVENT_DRAW', 'music_draw'))
					try: _mc.play(evt)
					except: pass
			except Exception as e: pass
			
			try:
				import battle_results_shared
				mock_arena_id = 999
				
				v_id = getattr(player, 'playerVehicleID', 1)
				p_max_health = getattr(getattr(player, 'vehicleTypeDescriptor', None), 'maxHealth', 1000)
				p_health = getattr(getattr(player, 'vehicle', None), 'health', p_max_health)
				
				_player_mock = globals().get('G_MOCK_VEHICLES', {}).get(getattr(player, 'playerVehicleID', -1))
				_p_killer_id = getattr(_player_mock, 'last_killer_id', 255) if p_health <= 0 else 0
				
				p_team = getattr(player, 'team', 1)
				p_dbid = getattr(player, 'databaseID', 1)
				p_name = getattr(player, 'name', 'Player')
				p_cd = getattr(getattr(getattr(player, 'vehicleTypeDescriptor', None), 'type', None), 'compactDescr', 0)
				
				players_dict = {p_dbid: {'name': p_name, 'clanDBID': 0, 'clanAbbrev': '', 'prebattleID': 0, 'team': p_team, 'igrType': 0}}
				vehicles_dict = {v_id: {'health': p_health, 'credits': 10000, 'xp': 1000, 'shots': 10, 'hits': 8, 'he_hits': 0, 'pierced': 8, 'damageDealt': 0, 'damageAssisted': 0, 'damageReceived': max(0, p_max_health - p_health), 'shotsReceived': 0, 'spotted': 0, 'damaged': 0, 'kills': 0, 'tdamageDealt': 0, 'tkills': 0, 'isTeamKiller': False, 'capturePoints': 0, 'droppedCapturePoints': 0, 'mileage': 100, 'lifeTime': 300, 'killerID': _p_killer_id, 'achievements': [], 'repair': 0, 'freeXP': 50, 'details': {}, 'accountDBID': p_dbid, 'team': p_team, 'typeCompDescr': p_cd, 'gold': 0}}
				
				for vid, vinfo in getattr(player.arena, 'vehicles', {}).items():
					if vid == v_id: continue
					bot_team = vinfo.get('team', 2)
					bot_name = vinfo.get('name', 'Bot')
					bot_dbid = vid
					td = vinfo.get('vehicleType', None)
					td_type = getattr(td, 'type', None)
					bot_cd = getattr(td_type, 'compactDescr', 0)
					
					players_dict[bot_dbid] = {'name': bot_name, 'clanDBID': 0, 'clanAbbrev': '', 'prebattleID': 0, 'team': bot_team, 'igrType': 0}
					
					is_killed = not vinfo.get('isAlive', True)
					bot_hp = getattr(td, 'maxHealth', 1000)
					if is_killed: bot_hp = 0
					
					vehicles_dict[vid] = {'health': bot_hp, 'credits': 0, 'xp': 0, 'shots': 0, 'hits': 0, 'he_hits': 0, 'pierced': 0, 'damageDealt': 0, 'damageAssisted': 0, 'damageReceived': getattr(td, 'maxHealth', 1000) - bot_hp, 'shotsReceived': 0, 'spotted': 0, 'damaged': 0, 'kills': 0, 'tdamageDealt': 0, 'tkills': 0, 'isTeamKiller': False, 'capturePoints': 0, 'droppedCapturePoints': 0, 'mileage': 10, 'lifeTime': 300, 'killerID': v_id if is_killed else 0, 'achievements': [], 'repair': 0, 'freeXP': 0, 'details': {}, 'accountDBID': bot_dbid, 'team': bot_team, 'typeCompDescr': bot_cd, 'gold': 0}
				
				mock_res = {
					'arenaUniqueID': mock_arena_id,
					'personal': {'health': p_health, 'credits': 10000, 'xp': 1000, 'shots': 10, 'hits': 8, 'he_hits': 0, 'pierced': 8, 'damageDealt': 0, 'damageAssisted': 0, 'damageReceived': 0, 'shotsReceived': 0, 'spotted': 0, 'damaged': 0, 'kills': 0, 'tdamageDealt': 0, 'tkills': 0, 'isTeamKiller': False, 'capturePoints': 0, 'droppedCapturePoints': 0, 'mileage': 100, 'lifeTime': 300, 'killerID': _p_killer_id, 'achievements': [], 'repair': 0, 'freeXP': 50, 'details': {}, 'accountDBID': p_dbid, 'team': p_team, 'typeCompDescr': p_cd, 'gold': 0, 'xpPenalty': 0, 'creditsPenalty': 0, 'creditsContributionIn': 0, 'creditsContributionOut': 0, 'tmenXP': 0, 'eventCredits': 0, 'eventGold': 0, 'eventXP': 0, 'eventFreeXP': 0, 'eventTMenXP': 0, 'autoRepairCost': 0, 'autoLoadCost': (0, 0), 'autoEquipCost': (0, 0), 'isPremium': True, 'premiumXPFactor10': 15, 'premiumCreditsFactor10': 15, 'dailyXPFactor10': 10, 'aogasFactor10': 10, 'markOfMastery': 0, 'dossierPopUps': []},
					'common': {'arenaTypeID': getattr(player.arena, 'arenaTypeID', 1), 'arenaCreateTime': __import__('time').time(), 'winnerTeam': winnerTeam, 'finishReason': 1, 'duration': 300, 'bonusType': 1, 'guiType': 1, 'vehLockMode': 0},
					'players': players_dict,
					'vehicles': vehicles_dict
				}
				
				
				
				try:
					from gui import WindowsManager
					if hasattr(WindowsManager.g_windowsManager, 'showBattleResults'):
						WindowsManager.g_windowsManager.showBattleResults(mock_arena_id)
				except: pass
				
			except Exception as e:
				import traceback
				import gui.mods.offhangar.logging as __offlog
				__offlog.LOG_DEBUG('CRITICAL ERROR IN TRIGGER BATTLE RESULTS:', e)
				__offlog.LOG_DEBUG(traceback.format_exc())
				
			# Now clean up and leave arena!
			# Restore original stats object which was replaced with FakeStats
			if hasattr(player, '_offhangar_orig_stats') and player._offhangar_orig_stats is not None:
				player.stats = player._offhangar_orig_stats
			
			_leaveArena()
			player.onBecomeNonPlayer()
			
			# HACK: Because we triggered onBecomeNonPlayer manually but never call
			# onBecomePlayer to avoid crashing the offline mock state, we must manually
			# re-bind the requester modules and un-ignore them!
			for helper in ('syncData', 'inventory', 'stats', 'trader', 'shop', 'dossierCache', 'battleResultsCache', 'questProgress'):
				h = getattr(player, helper, None)
				if hasattr(h, 'setAccount'):
					try: h.setAccount(player)
					except: pass
				if hasattr(h, 'onAccountBecomePlayer'):
					try: h.onAccountBecomePlayer()
					except: pass

		def _capture_tick():
			import gui.mods.offhangar.logging as __offlog
			__offlog.LOG_DEBUG('LOUD: Capture tick started running!')
			try:
				if _battle_finished[0]: return
				import BigWorld
				player = BigWorld.player()
				if player is None or _battle_finished[0]:
					return
				if globals().get('g_offh_battle_gen', 0) != _offh_my_gen[0]:
					return  # a newer battle owns the globals - stop this stale loop
				if getattr(player, 'arena', None) is not None:
					_offh_seen_arena[0] = True
				elif _offh_seen_arena[0]:
					return  # battle left (hangar) - stop, let the battle graph free
				# The battle GUI dies on EVERY exit path (ESC quit has no hook of
				# its own). Once it existed and is gone: clean up NOW and stop -
				# ticking into the teardown/hangar load crashed the client, and
				# the leaked battle OOM-crashed the hangar load itself.
				try:
					from gui import WindowsManager as _gwm
					_bwref = getattr(_gwm.g_windowsManager, 'battleWindow', None)
				except Exception:
					_bwref = None
				if _bwref is not None:
					_offh_seen_bw[0] = True
				elif _offh_seen_bw[0]:
					try:
						_offh_battle_sweep('esc')
					except:
						pass
					_battle_finished[0] = True
					return
				if globals().get('g_offh_battle_gen', 0) != _offh_my_gen[0]:
					return  # a newer battle owns the globals - stop this stale loop
				if getattr(player, 'arena', None) is not None:
					_offh_seen_arena[0] = True
				elif _offh_seen_arena[0]:
					return  # battle left (hangar) - stop, let the battle graph free
				# The battle GUI dies on EVERY exit path (ESC quit has no hook of
				# its own). Once it existed and is gone: clean up NOW and stop -
				# ticking into the teardown/hangar load crashed the client, and
				# the leaked battle OOM-crashed the hangar load itself.
				try:
					from gui import WindowsManager as _gwm
					_bwref = getattr(_gwm.g_windowsManager, 'battleWindow', None)
				except Exception:
					_bwref = None
				if _bwref is not None:
					_offh_seen_bw[0] = True
				elif _offh_seen_bw[0]:
					try:
						_offh_battle_sweep('esc')
					except:
						pass
					_battle_finished[0] = True
					return
				
				# Get alive vehicles per team
				vehs_by_team = {1: [], 2: []}
				if getattr(player, 'isVehicleAlive', True):
					vehs_by_team[1].append(player) # player is always team 1
					
				_mock_vehicles = globals().get('G_MOCK_VEHICLES', {})
				for e_mock in _mock_vehicles.values():
					if getattr(e_mock, 'isVehicleAlive', True) and getattr(e_mock, '_team', 2) in vehs_by_team:
						vehs_by_team[e_mock._team].append(e_mock)
				
				# Check base distances
				for base_team, bases in g_offline_bases.items():
					if not bases: continue
					
					invading_team = 2 if base_team == 1 else 1
					
					invaders_count = 0
					for invader in vehs_by_team[invading_team]:
						for base_pos in bases:
							import BigWorld
							if invader == BigWorld.player():
								inv_x = veh_pos[0]
								inv_z = veh_pos[2]
							else:
								inv_x = invader.position.x
								inv_z = invader.position.z
							dx = inv_x - base_pos.x
							dz = inv_z - base_pos.z
							import gui.mods.offhangar.logging as __offlog
							__offlog.LOG_DEBUG('LOUD: Distance to base', base_team, 'is', dx*dx + dz*dz, 'pos:', inv_x, inv_z, 'base:', base_pos.x, base_pos.z)
							if dx*dx + dz*dz <= 2500.0: # 50m radius
								invaders_count += 1
								break
					
					defenders_count = 0
					for defender in vehs_by_team[base_team]:
						for base_pos in bases:
							import BigWorld
							if defender == BigWorld.player():
								def_x = veh_pos[0]
								def_z = veh_pos[2]
							else:
								def_x = defender.position.x
								def_z = defender.position.z
							dx = def_x - base_pos.x
							dz = def_z - base_pos.z
							if dx*dx + dz*dz <= 2500.0:
								defenders_count += 1
								break
					
					state = g_base_capture[base_team]
					old_points = state['points']
					
					# Handle transition from PREBATTLE to BATTLE
					if getattr(player.arena, 'period', 0) == 2 and BigWorld.serverTime() >= getattr(player.arena, 'periodEndTime', 0):
						import gui.mods.offhangar.logging as __offlog
						__offlog.LOG_DEBUG('LOUD: TRANSITION TO BATTLE PERIOD')
						player.arena.period = 3
						player.arena.periodLength = 900
						player.arena.periodEndTime = BigWorld.serverTime() + 900
						player.arena.onPeriodChange(3, player.arena.periodEndTime, 900, {}) # dict, not int: UI handlers call has_key() on it

					
					import debug_utils
					if state['points'] != old_points or invaders_count > 0:
						debug_utils.LOG_DEBUG('Capture tick: team', base_team, 'invaders:', invaders_count, 'defenders:', defenders_count, 'points:', state['points'], 'serverTime:', BigWorld.serverTime())
					
					if invaders_count > 0 and defenders_count == 0:
						state['points'] = min(100, state['points'] + min(invaders_count, 3))
					elif invaders_count == 0:
						state['points'] = 0
						
					# Removed old hack
						
					if state['points'] != old_points or invaders_count > 0:
						import gui.mods.offhangar.logging as __offlog
						__offlog.LOG_DEBUG('LOUD: PERIOD:', getattr(player.arena, 'period', None), 'SERVERTIME:', BigWorld.serverTime(), 'PERIODENDTIME:', getattr(player.arena, 'periodEndTime', None))
						__offlog.LOG_DEBUG('Capture UI updating points! base:', base_team, 'points:', state['points'], 'invaders:', invaders_count)
						try:
							import gui.Scaleform.Battle
							if not hasattr(gui.Scaleform.Battle.TeamBasesPanel, '_patched_update'):
								orig = gui.Scaleform.Battle.TeamBasesPanel._TeamBasesPanel__onTeamBasePointsUpdate
								def _hook(self, team, baseID, points, capturingStopped):
									import gui.mods.offhangar.logging as __offlog
									__offlog.LOG_DEBUG('LOUD: UI HOOK! team', team, 'base', baseID, 'pts', points, 'stop', capturingStopped)
									try:
										orig(self, team, baseID, points, capturingStopped)
										__offlog.LOG_DEBUG('LOUD: UI HOOK orig executed successfully!')
									except Exception as e:
										__offlog.LOG_DEBUG('LOUD: UI HOOK EXCEPTION:', e)
								gui.Scaleform.Battle.TeamBasesPanel._TeamBasesPanel__onTeamBasePointsUpdate = _hook
								gui.Scaleform.Battle.TeamBasesPanel._patched_update = True
						except Exception as e:
							__offlog.LOG_DEBUG('LOUD: UI HOOK INIT ERROR:', e)
						try:
							player.arena.onTeamBasePointsUpdate(base_team, 0, state['points'], defenders_count > 0)
						except Exception as e:
							__offlog.LOG_DEBUG('LOUD: Capture UI Error:', e)
					
					if state['points'] >= 100:
						try:
							player.arena.onTeamBaseCaptured(1, base_team)
						except: pass
						_battle_finished[0] = True
						
						# Stop the battle!
						try: player.arena.onPeriodChange(4, BigWorld.serverTime() + 5.0, 5.0, 0) # ArenaPeriod.AFTERBATTLE
						except: pass
						
						# Trigger battle results in 5 seconds
						import BigWorld
						BigWorld.callback(5.0, lambda: trigger_battle_results(3 - base_team))
						
			except Exception as e:
				import gui.mods.offhangar.logging as __offlog
				__offlog.LOG_DEBUG('LOUD: Capture Tick Error:', e)
			finally:
				# Reschedule ONLY while this battle is alive and owns the globals;
				# unconditional rescheduling kept whole old battles in memory.
				try:
					import BigWorld as _cbw
					_cpl = _cbw.player()
					_cok = (not _battle_finished[0]) and globals().get('g_offh_battle_gen', 0) == _offh_my_gen[0]
					if _cok and _offh_seen_arena[0] and (_cpl is None or getattr(_cpl, 'arena', None) is None):
						_cok = False
					if _cok:
						_cbw.callback(1.0, _capture_tick)
				except Exception:
					pass
					
		g_capture_tick_ref = _capture_tick
		BigWorld.callback(5.0, _capture_tick)
		
		global g_aih_tick_ref
		def _aih_tick():
			try:
				import BigWorld, Math, Keys, math
				player = BigWorld.player()
				
				# Stop the loop if battle is over
				if _battle_finished[0] or player is None:
					return
				# Stale-loop guard: each battle start bumps the generation. A stale
				# per-frame loop pins its whole battle (models/mocks) in the 32-bit
				# client - three battles piled up = OOM crash while loading #3.
				if globals().get('g_offh_battle_gen', 0) != _offh_my_gen[0]:
					return
				if getattr(player, 'arena', None) is not None:
					_offh_seen_arena[0] = True
				elif _offh_seen_arena[0]:
					return  # back in the hangar - stop and release the battle
				# The battle GUI dies on EVERY exit path (ESC quit has no hook of
				# its own). Once it existed and is gone: clean up NOW and stop -
				# ticking into the teardown/hangar load crashed the client, and
				# the leaked battle OOM-crashed the hangar load itself.
				try:
					from gui import WindowsManager as _gwm
					_bwref = getattr(_gwm.g_windowsManager, 'battleWindow', None)
				except Exception:
					_bwref = None
				if _bwref is not None:
					_offh_seen_bw[0] = True
				elif _offh_seen_bw[0]:
					try:
						_offh_battle_sweep('esc')
					except:
						pass
					_battle_finished[0] = True
					return
				# Stale-loop guard: each battle start bumps the generation. A stale
				# per-frame loop pins its whole battle (models/mocks) in the 32-bit
				# client - three battles piled up = OOM crash while loading #3.
				if globals().get('g_offh_battle_gen', 0) != _offh_my_gen[0]:
					return
				if getattr(player, 'arena', None) is not None:
					_offh_seen_arena[0] = True
				elif _offh_seen_arena[0]:
					return  # back in the hangar - stop and release the battle
				# The battle GUI dies on EVERY exit path (ESC quit has no hook of
				# its own). Once it existed and is gone: clean up NOW and stop -
				# ticking into the teardown/hangar load crashed the client, and
				# the leaked battle OOM-crashed the hangar load itself.
				try:
					from gui import WindowsManager as _gwm
					_bwref = getattr(_gwm.g_windowsManager, 'battleWindow', None)
				except Exception:
					_bwref = None
				if _bwref is not None:
					_offh_seen_bw[0] = True
				elif _offh_seen_bw[0]:
					try:
						_offh_battle_sweep('esc')
					except:
						pass
					_battle_finished[0] = True
					return

				current_time = BigWorld.time()
				dt = current_time - _last_tick_time[0]
				_last_tick_time[0] = current_time
				# full_space_release: pin the render camera to the dedicated
				# battle space each frame (camera-mode switches recreate cameras
				# that would revert rendering to the empty account space -> black).
				if globals().get('g_offh_full_release', False):
					_offh_set_render_space(_offh_bspace())
				if dt <= 0.0 or dt > 0.5:
					dt = 0.016 # fallback to 60fps
				_frame_dt = dt # real per-frame delta (dt is reused by the bot section below)

				# --- One-time spawn correction once the terrain has streamed in ---
				# The initial spawn runs before the space is loaded (all ground rays
				# miss -> y=100 fallback, sometimes onto/inside buildings). As soon
				# as the ground answers, snap the player onto formation slot 0 at his
				# team base, facing the enemy base - the original line-up position.
				if not getattr(player, '_offh_spawn_fixed', False):
					try:
						_bases_fix = globals().get('g_offline_bases', {}) or {}
						_my_bl = _bases_fix.get(getattr(player, '_offhangar_team', 1) or 1) or []
						_my_b = _my_bl[0] if _my_bl else None
						if _my_b is not None:
							_probe = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(_my_b.x, 800.0, _my_b.z), Math.Vector3(_my_b.x, -500.0, _my_b.z), 128)
							if _probe is not None:
								# Terrain is ready: take the player's line-up slot
								_fs = globals().get('g_offline_formation_slot')
								if _fs is not None:
									_sx, _sz, _syaw = _fs(getattr(player, '_offhangar_team', 1) or 1, 0)
								else:
									_sx, _sz, _syaw = _my_b.x, _my_b.z, 0.0
								# Roof-safe ground probe: while something substantially
								# lower exists below the hit (roof/bridge), keep going down
								_gy = None
								_from_y = 800.0
								for _ri in range(4):
									_c1 = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(_sx, _from_y, _sz), Math.Vector3(_sx, -500.0, _sz), 128)
									if _c1 is None: break
									_gy = _c1[0].y
									_c2 = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(_sx, _gy - 0.4, _sz), Math.Vector3(_sx, -500.0, _sz), 128)
									if _c2 is None or (_gy - _c2[0].y) < 2.5: break
									_from_y = _gy - 0.4
								if _gy is not None:
									player._offh_spawn_fixed = True
									veh_pos[0] = _sx
									veh_pos[1] = _gy
									veh_pos[2] = _sz
									veh_yaw[0] = _syaw
									_veh_velocity[0] = 0.0
									_veh_turn_velocity[0] = 0.0
									_veh_vert_vel[0] = 0.0
									_veh_airborne[0] = False
									LOG_DEBUG('OfflineBattle: spawn corrected to line-up slot:', _sx, _gy, _sz)
					except Exception as _sce:
						LOG_DEBUG('Spawn correction error:', str(_sce))
				
				import debug_utils
				if not hasattr(player, '_debug_dump_done_6'):
					player._debug_dump_done_6 = True
					debug_utils.LOG_DEBUG('AIH_TICK DUMP AT START!')
					_mock_vehicles = globals().get('G_MOCK_VEHICLES', {})
					debug_utils.LOG_DEBUG('AIH_TICK keys:', _mock_vehicles.keys())
					
				def _get_terrain_ypr(spaceID, pos, yaw, length=5.0, width=3.0):
					import math, BigWorld, Math
					cos_y = math.cos(yaw)
					sin_y = math.sin(yaw)
					
					hl = length / 2.0
					hw = width / 2.0
					
					# 4 body na podvozku
					fx = pos.x + sin_y * hl
					fz = pos.z + cos_y * hl
					bx = pos.x - sin_y * hl
					bz = pos.z - cos_y * hl
					
					rx = pos.x + cos_y * hw
					rz = pos.z - sin_y * hw
					lx = pos.x - cos_y * hw
					lz = pos.z + sin_y * hw
					
					def get_y(x, z):
						try:
							# Ray from well above: the old +1.5 start sat BELOW steep uphill
							# ground so the hull stayed flat. Accept ground within a hull-height
							# window; reject walls/roofs far above and holes/cliffs far below.
							c = BigWorld.wg_collideSegment(spaceID, Math.Vector3(x, pos.y + 8.0, z), Math.Vector3(x, pos.y - 30.0, z), 128)
							if c is not None and -14.0 < (c[0].y - pos.y) < 6.0:
								return c[0].y
						except: pass
						return pos.y
					
					fy = get_y(fx, fz)
					by = get_y(bx, bz)
					ry = get_y(rx, rz)
					ly = get_y(lx, lz)
					
					pitch = -math.atan2(fy - by, length)
					roll = math.atan2(ry - ly, width)
					
					# Pitch and roll limits to prevent insane flips (max ~45 deg)
					pitch = max(-0.8, min(0.8, pitch))
					roll = max(-0.8, min(0.8, roll))
					
					# --- Slope gradient: unit downhill dir + magnitude (caller integrates slide) ---
					slide_x = 0.0
					slide_z = 0.0
					slope = 0.0
					try:
						grad_f = (by - fy) / length   # + = downhill toward hull front
						grad_l = (ly - ry) / width    # + = downhill toward hull right
						slope = math.sqrt(grad_f * grad_f + grad_l * grad_l)
						if slope > 0.001:
							dh_x = grad_f * sin_y + grad_l * cos_y
							dh_z = grad_f * cos_y - grad_l * sin_y
							dl = math.sqrt(dh_x * dh_x + dh_z * dh_z)
							if dl > 0.001:
								slide_x = dh_x / dl
								slide_z = dh_z / dl
					except: pass
					return (yaw, pitch, roll, slide_x, slide_z, slope)
					
				def _try_destroy_destructible(spaceID, matInfo, yaw, vel):
					import AreaDestructibles, BigWorld, constants
					try:
						if not hasattr(AreaDestructibles, 'g_destructiblesManager') or not AreaDestructibles.g_destructiblesManager:
							return False
							
						hitPt, surfNormal, chunkID, itemIndex, matKind, fname = matInfo
						_dseen = globals().setdefault('g_offh_destr_seen', set())
						_dkey = (matKind, fname)
						if _dkey not in _dseen:
							_dseen.add(_dkey); LOG_DEBUG('Destr hit: matKind=', matKind, 'fname=', repr(fname), 'chunk=', chunkID, 'idx=', itemIndex)
						# Widened band: the strict 71-100 range rejected spawn barriers/props at
						# matKind 102. getDescByFilename below is the real filter, so a wider band
						# only lets more candidates reach the authoritative desc check.
						if matKind < 71 or matKind > 130:
							return False
						desc = AreaDestructibles.g_cache.getDescByFilename(fname)
						if not desc:
							_dnd = globals().setdefault('g_offh_destr_nodesc', set())
							if _dkey not in _dnd:
								_dnd.add(_dkey); LOG_DEBUG('Destr no desc: matKind=', matKind, 'fname=', repr(fname), 'chunk=', chunkID, 'idx=', itemIndex)
							return False
						
						# Data-driven vegetation gate: soft vegetation (bush/shrub/fern)
						# ships with health <= 5; real fallable trees start at 10.
						if desc['type'] in (AreaDestructibles.DESTR_TYPE_TREE, AreaDestructibles.DESTR_TYPE_FALLING_ATOM):
							_hp_gate = desc.get('health', 0)
							if _hp_gate < 10 or _hp_gate > 1000:
								return False
						# All bookkeeping (chunk bootstrap, dedup, encoding) lives in
						# the authority - this path is now just a contact sensor.
						_auth = _get_destr_authority()
						
						typ = desc['type']
						# STRUCTURE (buildings) now falls through to the module-destroy
						# path: online, small buildings crumble module by module as the
						# tank pushes through. Requires the working effects pipeline
						# (terrainEffects + real fake_model), else it raises mid-destroy.
						if _auth.is_destroyed(chunkID, itemIndex, matKind):
							LOG_DEBUG('Destr: already broken')
							return True
							
						if typ == AreaDestructibles.DESTR_TYPE_TREE:
							_destr_ok = _auth.destroy_tree(spaceID, chunkID, itemIndex, yaw, vel, hitPt)
						elif typ == AreaDestructibles.DESTR_TYPE_FALLING_ATOM:
							_destr_ok = _auth.destroy_column(spaceID, chunkID, itemIndex, yaw, vel, hitPt)
						elif typ == AreaDestructibles.DESTR_TYPE_FRAGILE:
							_destr_ok = _auth.destroy_fragile(spaceID, chunkID, itemIndex, hitPt)
						else:
							# STRUCTURE: buildings crumble module by module
							_destr_ok = _auth.destroy_module(spaceID, chunkID, itemIndex, matKind, hitPt, False)
							
						if _destr_ok:
							LOG_DEBUG('Destr SUCCESS!', typ)
						return True
					except Exception as e:
						LOG_DEBUG('Destr Exception:', str(e))
					return False
					
				# The destructible effect pipeline (fall dust, decay effects) calls
				# player.terrainEffects.addNew(); only the real battle Avatar has it.
				# Without it __launchFallEffect raises and trees never start falling.
				try:
					from helpers import bound_effects
					if getattr(player, 'terrainEffects', None) is None:
						player.terrainEffects = bound_effects.StaticSceneBoundEffects()
					# Effects attach to player.newFakeModel(); the offline stub
					# returned BigWorld.Model('') and Model.node() rejects blank
					# models. Use the real fake model like Avatar does.
					def _offh_new_fake_model():
						try:
							return BigWorld.Model('objects/fake_model.model')
						except Exception:
							return BigWorld.Model('')
					player.newFakeModel = _offh_new_fake_model
				except Exception:
					LOG_CURRENT_EXCEPTION()
				
				# Export for _mock_shoot (different function scope); resolved at call time
				loaded_models['_destr_fn'] = _try_destroy_destructible

				def _fell_trees_near(spaceID, pos, yaw, vel, td=None):
					# Offline tree/pole felling. Online the SERVER detected tank-vs-tree
					# contact; the client-side collision probes never return tree/column
					# materials, so trees could never fall offline. Instead: enumerate
					# each chunk's destructibles once (filename + world matrix), then
					# fell TREE / FALLING_ATOM items that intersect the moving hull.
					import math
					import AreaDestructibles
					try:
						if abs(vel) < 1.0:
							return
						mgr = getattr(AreaDestructibles, 'g_destructiblesManager', None)
						if not mgr:
							return
						if mgr.getSpaceID() is None:
							mgr.startSpace(spaceID)
						_st = globals().setdefault('g_offh_tree_state', {'chunks': {}, 'felled': set(), 'spaceID': None})
						if _st.get('spaceID') != spaceID:
							# New battle/space: chunk IDs collide between maps and the
							# dedup sets would suppress destruction of fresh objects.
							_st['chunks'] = {}
							_st['felled'] = set()
							_st['spaceID'] = spaceID
							globals()['g_offh_destr_ordered'] = set()
							globals()['g_offh_destr_chunks'] = set()
							globals()['g_offh_destr_seen'] = set()
						cos_y = math.cos(yaw); sin_y = math.sin(yaw)
						cids = set()
						for _pf in (0.0, 6.0 if vel >= 0 else -6.0):
							try:
								cids.add(AreaDestructibles.chunkIDFromPosition(Math.Vector3(pos.x + sin_y * _pf, pos.y, pos.z + cos_y * _pf)))
							except Exception:
								pass
						hw = 1.6; hl_f = 3.6; hl_b = 3.6
						try:
							if td is not None and hasattr(td, 'hull') and 'hitTester' in td.hull:
								bbox = td.hull['hitTester'].bbox
								hw = max(abs(bbox[0][0]), abs(bbox[1][0]))
								hl_b = abs(bbox[0][2])
								hl_f = abs(bbox[1][2])
						except Exception:
							pass
						for cid in cids:
							trees = _st['chunks'].get(cid)
							if trees is None:
								_dfn = None
								try:
									_dfn = BigWorld.wg_getChunkDestrFilenames(spaceID, cid)
								except Exception:
									pass
								if _dfn is None:
									continue # chunk not streamed in yet; retry next tick
								trees = []
								_cm_t = None
								try:
									_cm_t = BigWorld.wg_getChunkMatrix(spaceID, cid).translation
								except Exception:
									pass
								if _cm_t is None:
									continue
								for _ti in xrange(len(_dfn)):
									try:
										desc = AreaDestructibles.g_cache.getDescByFilename(_dfn[_ti])
										if desc is None:
											continue
										if desc['type'] not in (AreaDestructibles.DESTR_TYPE_TREE, AreaDestructibles.DESTR_TYPE_FALLING_ATOM, AreaDestructibles.DESTR_TYPE_FRAGILE):
											continue
										# Data-driven vegetation gate: destructibles.xml gives
										# soft vegetation (bushes/shrubs/ferns/weeds) health<=5
										# (or -2); real fallable trees start at health 10.
										# ChristmasTree sentinels use 40000 = unrammable.
										if desc['type'] != AreaDestructibles.DESTR_TYPE_FRAGILE:
											_hp_gate = desc.get('health', 0)
											if _hp_gate < 10 or _hp_gate > 1000:
												continue
										# Destructible matrices are CHUNK-LOCAL: world pos =
										# chunk translation + destructible translation
										# (see AreaDestructibles.__launchEffect)
										_m = Math.Matrix(BigWorld.wg_getDestructibleMatrix(spaceID, cid, _ti))
										trees.append((_ti, _cm_t.x + _m.translation.x, _cm_t.z + _m.translation.z, desc['type'], _dfn[_ti], desc.get('health', 0), desc.get('mass', 0)))
									except Exception:
										continue
								_st['chunks'][cid] = trees
								LOG_DEBUG('DestrTree: chunk registry', cid, len(trees), 'trees/poles')
								if trees:
									LOG_DEBUG('DestrTree: sample world pos', trees[0][1], trees[0][2], 'tank at', pos.x, pos.z)
							if not trees:
								continue
							reach_f = hl_f + 0.8 + min(abs(vel) * 0.25, 1.2)
							for (_ti, _tx, _tz, _ttyp, _tfn, _thp, _tmass) in trees:
								dx = _tx - pos.x; dz = _tz - pos.z
								if dx * dx + dz * dz > 64.0:
									continue
								fwd = dx * sin_y + dz * cos_y
								lat = dx * cos_y - dz * sin_y
								if vel < 0:
									in_reach = -(hl_b + 0.8) <= fwd <= hl_f
								else:
									in_reach = -hl_b <= fwd <= reach_f
								if abs(lat) > hw + 0.5 or not in_reach:
									continue
								_key = (cid, _ti)
								if _key in _st['felled']:
									continue
								_st['felled'].add(_key)
								fall_yaw = yaw if vel >= 0 else (yaw + math.pi)
								_auth = _get_destr_authority()
								if _ttyp == AreaDestructibles.DESTR_TYPE_FRAGILE:
									# Haybales, barrels, wire fences: collision skins often
									# resolve to no item in the probes; crush by proximity.
									_ok = _auth.destroy_fragile(spaceID, cid, _ti, pos)
								elif _ttyp == AreaDestructibles.DESTR_TYPE_TREE:
									_ok = _auth.destroy_tree(spaceID, cid, _ti, fall_yaw, vel, pos)
								else:
									_ok = _auth.destroy_column(spaceID, cid, _ti, fall_yaw, vel, pos)
								if _ok:
									LOG_DEBUG('DestrTree: FELLED', cid, _ti, 'type', _ttyp, 'hp', _thp, 'mass', _tmass, _tfn)
					except Exception:
						import traceback
						LOG_DEBUG('DestrTree error:', traceback.format_exc())
				
				def _try_destroy_solid_hit(spaceID, seg_start, hit_pt, yaw, vel):
					# wg_collideSegment returns no material info: probe the hit point for a
					# destructible (fence/wall segment) before treating it as solid
					import BigWorld
					try:
						# Probe along the SURFACE NORMAL like Vehicle.onStaticCollision: the
						# forward probe grazed the solid collision skin (matKind 101/109, empty
						# fname); crossing the surface perpendicular resolves the destructible
						# mesh's real chunk/index/fname. dir points into the surface; normal = -dir,
						# so segStart = point - normal*3 = point + dir*3, segStop = point - dir*2.
						_dirv = hit_pt - seg_start
						if _dirv.length > 0.001:
							_dirv.normalise()
						else:
							return False
						_seg_a = hit_pt + _dirv.scale(3.0)
						_seg_b = hit_pt - _dirv.scale(2.0)
						_mi = BigWorld.wg_getMatInfoNearPoint(spaceID, _seg_a, _seg_b, hit_pt, lambda *a: False)
						if _mi is not None:
							return _try_destroy_destructible(spaceID, _mi, yaw, vel)
					except Exception:
						pass
					return False
				
				def _collision_damage(victim, dmg, attacker_id):
					# Ported ram-damage sink: HP, damage panel / marker feedback, kill.
					if dmg <= 0 or victim is None:
						return
					try:
						if getattr(victim, 'health', 0) <= 0:
							return
						victim.health = max(0, int(getattr(victim, 'health', 0)) - int(dmg))
						victim.last_killer_id = attacker_id
						v_id = getattr(victim, 'id', -1)
						is_player_victim = (v_id == getattr(player, 'playerVehicleID', -1))
						if is_player_victim:
							try:
								if hasattr(player, 'vehicle') and player.vehicle:
									player.vehicle.health = victim.health
							except Exception:
								pass
							try:
								from gui import WindowsManager as _rwm
								bw = getattr(_rwm.g_windowsManager, 'battleWindow', None)
								if bw and hasattr(bw, 'damagePanel'):
									bw.damagePanel.updateHealth(victim.health)
							except Exception:
								pass
						else:
							try:
								if hasattr(player.arena, 'onVehicleStatisticsUpdate'):
									player.arena.onVehicleStatisticsUpdate(v_id)
								from gui import WindowsManager as _rwm
								bw = getattr(_rwm.g_windowsManager, 'battleWindow', None)
								if bw and hasattr(bw, 'vMarkersManager'):
									marker = getattr(victim, 'marker', None)
									if marker is not None:
										bw.vMarkersManager.onVehicleHealthChanged(marker, victim.health, attacker_id, 0)
										try: bw.vMarkersManager.showVehicleDamageInfo(marker, dmg, 0, 0, 0)
										except Exception: pass
							except Exception:
								pass
						if victim.health <= 0 and not is_player_victim:
							victim.isAlive = False
							try:
								if v_id in player.arena.vehicles:
									player.arena.vehicles[v_id]['isAlive'] = False
								if hasattr(player.arena, 'onVehicleKilled'):
									player.arena.onVehicleKilled(v_id, attacker_id, 3)  # reason 3 = ram (wrapper swaps wreck)
							except Exception:
								pass
					except Exception as e:
						LOG_DEBUG('Collision damage error:', str(e))

				def _tank_hull_dims(td):
					# (half_width, front_len, back_len) from the hull hit-tester bbox.
					# Cached per descriptor: this sits inside the per-frame tank-pair loop.
					_c = globals().setdefault('g_offh_dims', {})
					_k = id(td)
					_v = _c.get(_k)
					if _v is not None:
						return _v
					hw = 1.5; hlf = 3.5; hlb = 3.5
					try:
						if td is not None and hasattr(td, 'hull') and 'hitTester' in td.hull:
							bbox = td.hull['hitTester'].bbox
							hw = max(abs(bbox[0][0]), abs(bbox[1][0]))
							hlb = abs(bbox[0][2])
							hlf = abs(bbox[1][2])
					except: pass
					_v = (hw, hlf, hlb)
					_c[_k] = _v
					return _v

				def _tank_circles(x, z, yaw, td):
					# Approximate the rectangular hull by a chain of circles along the
					# forward axis (circle radius = hull half-width). Cheap tank-vs-tank.
					import math
					hw, hlf, hlb = _tank_hull_dims(td)
					r = hw if hw > 0.8 else 0.8
					fx = math.sin(yaw); fz = math.cos(yaw)
					start = -hlb + r
					end = hlf - r
					out = []
					if end <= start:
						out.append((x, z, r))
						return out
					n = int((end - start) / (r * 1.5))
					if n < 1: n = 1
					step = (end - start) / n
					i = 0
					while i <= n:
						o = start + step * i
						out.append((x + fx * o, z + fz * o, r))
						i += 1
					return out

				def _tank_resolve(self_id, x, z, yaw, td, inv_self, svx, svz):
					# Velocity-relative impulse (e=0) + Baumgarte push-apart vs every
					# other living tank. (svx, svz) = self's world velocity. Returns
					# (corr_x, corr_z, dvx, dvz): positional correction + velocity
					# impulse for self's push velocity. Movement is NEVER blocked ->
					# no deadlock; inverse-mass weighting shoves the lighter tank aside.
					import BigWorld, math
					_mv = globals().get('G_MOCK_VEHICLES', {}) or {}
					_plobj = BigWorld.player()
					_pid = getattr(_plobj, 'playerVehicleID', -1)
					my_c = _tank_circles(x, z, yaw, td)
					corr_x = 0.0; corr_z = 0.0; dvx = 0.0; dvz = 0.0
					_SLOP = 0.02; _PCT = 0.4
					for oid, ov in _mv.items():
						if oid == self_id or ov is None:
							continue
						if oid == _pid:
							ox = veh_pos[0]; oz = veh_pos[2]; oyaw = veh_yaw[0]; otd = loaded_models.get('td'); inv_o = 1.0 / max(_phys_mass, 1.0)
							ovx = math.sin(oyaw) * _veh_velocity[0] + (getattr(_plobj, '_push_x', 0.0) or 0.0)
							ovz = math.cos(oyaw) * _veh_velocity[0] + (getattr(_plobj, '_push_z', 0.0) or 0.0)
						else:
							op = getattr(ov, 'position', None)
							if op is None:
								continue
							ox = op.x; oz = op.z; oyaw = getattr(ov, 'yaw', 0.0); otd = getattr(ov, 'typeDescriptor', None); inv_o = 1.0 / 25000.0
							_ovv = getattr(ov, '_veh_velocity', 0.0) or 0.0
							ovx = math.sin(oyaw) * _ovv + (getattr(ov, '_push_x', 0.0) or 0.0)
							ovz = math.cos(oyaw) * _ovv + (getattr(ov, '_push_z', 0.0) or 0.0)
						dcx = x - ox; dcz = z - oz
						if dcx * dcx + dcz * dcz > 144.0:
							continue
						_isum = inv_self + inv_o
						if _isum <= 0.0:
							continue
						_best = 0.0; _bnx = 0.0; _bnz = 0.0
						_ocl = _tank_circles(ox, oz, oyaw, otd)  # hoisted: was rebuilt per self-circle
						for _cc in my_c:
							for _oc in _ocl:
								ddx = _cc[0] - _oc[0]; ddz = _cc[1] - _oc[1]
								rr = _cc[2] + _oc[2]
								_d2 = ddx * ddx + ddz * ddz
								if _d2 < rr * rr and _d2 > 1e-06:
									_dist = math.sqrt(_d2)
									_pen = rr - _dist
									if _pen > _best:
										_best = _pen; _bnx = ddx / _dist; _bnz = ddz / _dist
						if _best > 0.0:
							_corr = max(_best - _SLOP, 0.0) / _isum * _PCT * inv_self
							corr_x += _bnx * _corr; corr_z += _bnz * _corr
							_vn = (svx - ovx) * _bnx + (svz - ovz) * _bnz
							if _vn < 0.0:
								_j = -_vn / _isum
								dvx += _j * inv_self * _bnx; dvz += _j * inv_self * _bnz
								# Ram damage (ported): approach speed beyond 3.5 m/s hurts both hulls
								if _vn < -3.5:
									_now = BigWorld.time()
									_rcd = globals().setdefault('g_offh_ram_cd', {})
									_rkey = (min(self_id, oid), max(self_id, oid))
									if _now - _rcd.get(_rkey, 0.0) > 0.75:
										_rcd[_rkey] = _now
										_rel = -_vn
										_rimp = (_rel - 3.5) * (_rel - 3.5)
										_rms = 1.0 / max(inv_self, 1e-09)
										_rmo = 1.0 / max(inv_o, 1e-09)
										_rmr = max(0.1, min(4.0, _rms / max(_rmo, 1.0)))
										_dmo = min(450, int(_rimp * 1.7 * max(0.35, min(2.6, _rmr))))
										_dms = min(350, int(_rimp * 1.0 * max(0.25, min(2.2, 1.0 / _rmr))))
										_rsv = _mv.get(self_id)
										if _dmo > 0:
											_collision_damage(ov, _dmo, self_id)
										if _dms > 0 and _rsv is not None:
											_collision_damage(_rsv, _dms, oid)
										LOG_DEBUG('RAM:', self_id, '<->', oid, 'rel=%.1f' % _rel, 'dmg', _dmo, _dms)
					return (corr_x, corr_z, dvx, dvz)

				def _drive_pitch(spaceID, x, z, yaw, y):
					# Real fore/aft ground slope in the travel direction (nose-up = negative,
					# BigWorld convention). Detects steep uphills the visual YPR misses, so a
					# hill costs real engine power -> tanks stop climbing cliffs like flat ground.
					import math, BigWorld, Math
					fx = math.sin(yaw); fz = math.cos(yaw)
					L = 3.0
					def _gy(px, pz):
						try:
							c = BigWorld.wg_collideSegment(spaceID, Math.Vector3(px, y + 15.0, pz), Math.Vector3(px, y - 60.0, pz), 128)
							if c is not None:
								return c[0].y
						except: pass
						return None
					fy = _gy(x + fx * L, z + fz * L)
					by = _gy(x - fx * L, z - fz * L)
					if fy is None or by is None:
						return 0.0
					p = -math.atan2(fy - by, 2.0 * L)
					if p > 1.2: p = 1.2
					if p < -1.2: p = -1.2
					return p

				def _check_horizontal_collision(spaceID, pos, yaw, vel, td=None):
					import math, BigWorld, Math
					try:
						hw = 1.5
						hl_front = 3.5
						hl_back = 3.5
						
						if td and hasattr(td, 'hull') and 'hitTester' in td.hull:
							try:
								bbox = td.hull['hitTester'].bbox
								hw = max(abs(bbox[0][0]), abs(bbox[1][0])) - 0.1
								hl_back = abs(bbox[0][2])
								hl_front = abs(bbox[1][2])
							except: pass
							
						back_margin = -2.0 if vel > 0 else 2.0
						front_margin = (hl_front + 2.0) if vel > 0 else -(hl_back + 2.0)
						
						cos_y = math.cos(yaw)
						sin_y = math.sin(yaw)
						
						for offset_x in (-hw, 0, hw):
							sx = pos.x + cos_y * offset_x
							sz = pos.z - sin_y * offset_x
							
							x1 = sx + sin_y * back_margin
							z1 = sz + cos_y * back_margin
							x2 = sx + sin_y * front_margin
							z2 = sz + cos_y * front_margin
							
							# Nezávislý scan na stromy a ploty před tankem
							try:
								if offset_x != 0:
									raise StopIteration  # perf: look-ahead only on centre column
								seg_start = Math.Vector3(sx, pos.y + 0.5, sz)
								seg_stop = Math.Vector3(x2, pos.y + 0.5, z2)
								matInfo = BigWorld.wg_getMatInfoNearPoint(spaceID, seg_start, seg_stop, seg_stop, lambda *a: False)
								if matInfo:
									if _try_destroy_destructible(spaceID, matInfo, yaw, vel):
										# Pokud jsme rozbili strom/plot, můžeme ignorovat pevnou kolizi, která na něj případně navazuje (nebo i když žádná není)
										pass
							except: pass
							
							# Spodní paprsek pro pevnou geometrii (0.6m nad zemí)
							start_bot = Math.Vector3(x1, pos.y + 0.6, z1)
							end_bot = Math.Vector3(x2, pos.y + 0.6, z2)
							col_bot = BigWorld.wg_collideSegment(spaceID, start_bot, end_bot, 128)
							
							if col_bot is not None:
								d_bot = (col_bot[0] - start_bot).length
								target_len = abs(back_margin) + (hl_front if vel > 0 else hl_back) + 0.2
								if d_bot < target_len:
									# Něco jsme trefili, zkontrolujeme horní paprsek (1.6m nad zemí)
									start_top = Math.Vector3(x1, pos.y + 1.6, z1)
									end_top = Math.Vector3(x2, pos.y + 1.6, z2)
									col_top = BigWorld.wg_collideSegment(spaceID, start_top, end_top, 128)
									
									if col_top is not None:
										d_top = (col_top[0] - start_top).length
										if (d_top - d_bot) < 0.5:
											if _try_destroy_solid_hit(spaceID, start_bot, col_bot[0], yaw, vel): pass
											else: return True
									else:
										start_mid = Math.Vector3(x1, pos.y + 1.1, z1)
										end_mid = Math.Vector3(x2, pos.y + 1.1, z2)
										col_mid = BigWorld.wg_collideSegment(spaceID, start_mid, end_mid, 128)
										if col_mid is not None:
											d_mid = (col_mid[0] - start_mid).length
											if (d_mid - d_bot) < 0.25:
												if _try_destroy_solid_hit(spaceID, start_bot, col_bot[0], yaw, vel): pass
												else: return True
										else:
											# Low object (<1.1m): only the bottom ray caught it. Crush it if
											# it's a destructible (fence / small prop) so the tank drives
											# THROUGH, not over it. Non-destructibles (low rocks) stay drivable.
											_try_destroy_solid_hit(spaceID, start_bot, col_bot[0], yaw, vel)
					except: pass
					return False

				if not _engine_state['init']:
					try:
						td = loaded_models.get('td')
						root_model = loaded_models.get('chassis') or loaded_models.get('hull') or loaded_models.get('turret') or loaded_models.get('gun')
						engine_dict = getattr(td, 'engine', None)
						chassis_dict = getattr(td, 'chassis', None)
						if td and engine_dict and chassis_dict and root_model is not None and root_model.inWorld:
							_engine_state['snd1'] = root_model.playSound(engine_dict['sound'])
							_engine_state['snd2'] = root_model.playSound(chassis_dict['sound'])
							_engine_state['init'] = True
							# Refs on the mock so _sync_burn_and_death can stop them on death
							mock_veh._snd_engine = _engine_state['snd1']
							mock_veh._snd_tracks = _engine_state['snd2']
							LOG_DEBUG('OfflineBattle: Engine sounds attached!', engine_dict['sound'], chassis_dict['sound'])
					except Exception as e:
						LOG_DEBUG('OfflineBattle: Engine sounds failed:', str(e))

				# --- Track animation (one-time): WGVehicleFashion drives the scrolling
				# track materials and wheels, exactly like the original VehicleAppearance ---
				if not loaded_models.get('_fashion_done'):
					try:
						_f_ch = loaded_models.get('chassis')
						_f_td = loaded_models.get('td')
						if _f_ch is not None and _f_td is not None and getattr(_f_ch, 'inWorld', False):
							loaded_models['_fashion_done'] = True
							_fash = BigWorld.WGVehicleFashion()
							try:
								_fash.maxMovement = _f_td.physics['speedLimits'][0]
							except Exception:
								pass
							# Swinging setup is mandatory: without a swinging node ('V' =
							# vehicle root) the fashion refuses to attach / stays inert
							try:
								_f_sw = _f_td.hull['swinging']
								_fash.setPitchSwinging('V', *_f_sw['pitchParams'])
								_fash.setRollSwinging('V', *_f_sw['rollParams'])
								_fash.setShotSwinging('V', _f_sw['sensitivityToImpulse'])
							except Exception as _swe:
								LOG_DEBUG('Fashion swinging setup failed:', str(_swe))
							_f_tr = _f_td.chassis['tracks']
							try:
								_fash.setLods(_f_td.chassis['traces']['lodDist'], _f_td.chassis['wheels']['lodDist'], _f_tr['lodDist'], _f_td.hull['swinging']['lodDist'])
							except Exception:
								pass
							_fash.setTracks(_f_tr['leftMaterial'], _f_tr['rightMaterial'], _f_tr['textureScale'])
							# Road wheels spin with movement: replicate _setupVehicleFashion's
							# addWheelGroup/addWheel. nodes = '<template><i>' from chassis['wheels'].
							try:
								_wcfg = _f_td.chassis['wheels']
								for _grp in _wcfg['groups']:
									_wnodes = ['%s%d' % (_grp[1], _wi) for _wi in range(_grp[3], _grp[3] + _grp[2])]
									_fash.addWheelGroup(_grp[0], _grp[4], _wnodes)
								for _wh in _wcfg['wheels']:
									_fash.addWheel(_wh[0], _wh[2], _wh[1])
								LOG_DEBUG('Fashion road wheels added')
							except Exception as _we:
								LOG_DEBUG('Fashion road wheels failed:', str(_we))
							# EXPERIMENT: real game sources fashion.movementInfo from WGVehicleFilter2;
							# the kinematic mock has none, so attach a settable Vector4 provider and
							# drive it per frame from speed. Log the available classes for diagnosis.
							try:
								LOG_DEBUG('Math Vector4 classes:', [ _n for _n in dir(Math) if 'Vector4' in _n ])
								_fash.movementInfo = Math.Vector4(0.0, 0.0, 0.0, 0.0)
								loaded_models['_fashion_mv'] = _fash
								LOG_DEBUG('Fashion movementInfo set Vector4; readback=', repr(_fash.movementInfo))
							except Exception as _mve:
								LOG_DEBUG('Fashion movementInfo attach failed:', str(_mve))
							_f_ch.wg_fashion = _fash
							# Chassis camo goes through THIS fashion (stashed at model setup);
							# a separate WGBaseFashion would detach the scrolling track material.
							try:
								_ca = loaded_models.get('_camo_args')
								if _ca is not None:
									_fash.setCamouflage(_ca[0], _ca[1], _ca[2], _ca[3], _ca[4], _ca[5], _ca[6], _ca[7])
									LOG_DEBUG('Chassis camo applied via track fashion')
							except Exception as _cae:
								LOG_DEBUG('Chassis camo via fashion failed:', str(_cae))
							loaded_models['_fashion'] = _fash
							LOG_DEBUG('OfflineBattle: track fashion attached (player)')
							try:
								LOG_DEBUG('WGVehicleFashion dir:', [ _n for _n in dir(_fash) if not _n.startswith('__') ])
							except Exception:
								pass
					except Exception as _fe:
						loaded_models['_fashion_done'] = True
						LOG_DEBUG('Track fashion failed:', str(_fe))

				# --- WoT-style Hull Physics ---
				# Determine input direction
				throttle = 0
				steer = 0
				
				# Allow WASD to move the tank even in Arty Mode, because offline edge-panning is broken
				# and the user needs to be able to rotate the hull to bring targets into the gun arc!
				if getattr(player, '_is_dead', False) is True:
					throttle = 0
					steer = 0
				else:
					if BigWorld.isKeyDown(Keys.KEY_W): throttle = 1
					elif BigWorld.isKeyDown(Keys.KEY_S): throttle = -1
					
					if BigWorld.isKeyDown(Keys.KEY_A): steer = -1
					elif BigWorld.isKeyDown(Keys.KEY_D): steer = 1
					
					# Auto-hull rotation if aiming outside limits
					# Only auto-rotate if not manually steering
					if steer == 0:
						steer = _gun_state.get('auto_steer', 0)
				
				# Freeze tank movement if battle hasn't started yet (Prebattle Countdown)
				arena = getattr(BigWorld.player(), 'arena', None)
				if arena is not None and getattr(arena, 'period', 3) < 3:
					throttle = 0
					steer = 0
				
				cur_vel = _veh_velocity[0]
				speed_limit = _phys_speedFwd if throttle >= 0 else _phys_speedBwd
				
				# Engine force: F = P / max(|v|, v_min) — this naturally gives strong
				# initial acceleration that tapers off at high speed (just like WoT)
				engine_force = 0.0
				if throttle != 0:
					min_vel = 1.5  # prevents division by near-zero at standstill
					engine_force = _phys_enginePowerW / max(abs(cur_vel), min_vel)
					# Cap engine force to prevent unrealistic initial thrust on heavy tanks
					max_engine_force = _phys_mass * _phys_gravity * 0.7
					engine_force = min(engine_force, max_engine_force)
					engine_force *= throttle  # direction
				
				# Terrain resistance force (rolling resistance opposes motion):
				# base_track_rr is a typical tracked vehicle rolling resistance coefficient (~0.07)
				base_track_rr = 0.07
				resist_force = _phys_mass * _phys_gravity * _phys_terrainCoeff * base_track_rr
				
				# Apply braking when:
				#  - No throttle (coasting to stop)
				#  - Throttle is opposite to current velocity (active braking)
				braking = False
				if throttle == 0 and abs(cur_vel) > 0.01:
					braking = True
				elif throttle != 0 and ((throttle > 0 and cur_vel < -0.1) or (throttle < 0 and cur_vel > 0.1)):
					braking = True
				
				# Net force calculation
				if braking:
					# Braking force: tracks are locked, so we use specificFriction (sliding friction)
					brake_force = _phys_mass * _phys_gravity * _phys_terrainCoeff * _phys_specificFriction
					if cur_vel > 0:
						net_force = -brake_force + engine_force
					else:
						net_force = brake_force + engine_force
				elif throttle == 0:
					net_force = 0.0
				else:
					# Normal driving: engine minus rolling resistance
					if throttle > 0:
						net_force = engine_force - resist_force
					else:
						net_force = engine_force + resist_force  # engine_force is negative here
				
				# Acceleration (F = ma => a = F/m)
				accel = net_force / _phys_mass
				
				if _veh_airborne[0]:
					# Tracks have no grip in the air: keep horizontal momentum
					accel = 0.0
				elif throttle != 0 or abs(cur_vel) > 0.01:
					# Slope: gravity component along the hull (BigWorld pitch < 0 = nose up).
					# Slows the tank uphill, speeds it up downhill; a parked tank holds position.
					accel += _phys_gravity * math.sin(_drive_pitch(_offh_bspace(), veh_pos[0], veh_pos[2], veh_yaw[0], veh_pos[1]))
				
				# Integrate velocity
				_veh_velocity[0] += accel * dt
				
				# Brakes may stop the hull but never push it through zero into reverse
				if braking and throttle == 0 and cur_vel != 0.0 and (cur_vel > 0.0) != (_veh_velocity[0] > 0.0):
					_veh_velocity[0] = 0.0
				
				# Clamp to speed limits
				if _veh_velocity[0] > _phys_speedFwd:
					_veh_velocity[0] = _phys_speedFwd
				elif _veh_velocity[0] < -_phys_speedBwd:
					_veh_velocity[0] = -_phys_speedBwd
				
				# No throttle: rolling resistance bleeds speed off gently (damp, never a hard
				# parking-brake stop; ~0.06g stays below slope gravity so the tank rolls downhill).
				if throttle == 0 and not braking and _veh_velocity[0] != 0.0:
					_rr = _phys_gravity * 0.06 * dt
					if abs(_veh_velocity[0]) <= _rr:
						_veh_velocity[0] = 0.0
					elif _veh_velocity[0] > 0.0:
						_veh_velocity[0] -= _rr
					else:
						_veh_velocity[0] += _rr
					
				# Track scroll: feed movementInfo from current speed so WGVehicleFashion
				# scrolls the track texture (experimental; real game uses WGVehicleFilter2).
				_mvp = loaded_models.get('_fashion_mv')
				if _mvp is not None:
					try:
						_tls = _veh_velocity[0] - _veh_turn_velocity[0] * 1.5
						_trs = _veh_velocity[0] + _veh_turn_velocity[0] * 1.5
						_mvp.movementInfo = Math.Vector4(0.0, _tls, _trs, 0.0)
					except Exception:
						pass
				# Update engine sounds
				try:
					cur_speed = abs(_veh_velocity[0])
					max_speed = _phys_speedFwd
					# Continuous load blend: discrete 1/2/3 mode values flip rapidly around
					# their thresholds and retrigger the FMOD engine loop (audible resets).
					power_fraction = min(1.0, (cur_speed / max_speed) + (abs(throttle) * 0.3))
					load = 1.0 + (power_fraction * 2.0)
					if _engine_state['snd1']:
						p = _engine_state.get('p_load')
						if p is None:
							p = _engine_state['snd1'].param('load')  # resolve once, not every frame
							_engine_state['p_load'] = p
						if p: p.value = load
					if _engine_state['snd2']:
						p = _engine_state.get('p_speed')
						if p is None:
							p = _engine_state['snd2'].param('speed')
							_engine_state['p_speed'] = p
						if p: p.value = cur_speed / max_speed
				except:
					pass
				# Apply position
				if _veh_velocity[0] != 0.0:
					_p_td = loaded_models.get('td')
					_fell_trees_near(_offh_bspace(), Math.Vector3(veh_pos[0], veh_pos[1], veh_pos[2]), veh_yaw[0], _veh_velocity[0], _p_td)
					if _check_horizontal_collision(_offh_bspace(), Math.Vector3(veh_pos[0], veh_pos[1], veh_pos[2]), veh_yaw[0], _veh_velocity[0], _p_td):
						_veh_velocity[0] = 0.0 # Zastavit při nárazu do zdi
					else:
						veh_pos[0] += math.sin(veh_yaw[0]) * _veh_velocity[0] * dt
						veh_pos[2] += math.cos(veh_yaw[0]) * _veh_velocity[0] * dt
				# Tank-vs-tank: velocity-relative impulse (e=0) + Baumgarte push-apart.
				# Never blocks movement -> no deadlock; heavier tank shoves lighter aside.
				try:
					_psvx = math.sin(veh_yaw[0]) * _veh_velocity[0] + (getattr(player, '_push_x', 0.0) or 0.0)
					_psvz = math.cos(veh_yaw[0]) * _veh_velocity[0] + (getattr(player, '_push_z', 0.0) or 0.0)
					_ptr = _tank_resolve(getattr(player, 'playerVehicleID', -1), veh_pos[0], veh_pos[2], veh_yaw[0], loaded_models.get('td'), 1.0 / max(_phys_mass, 1.0), _psvx, _psvz)
					player._push_x = (getattr(player, '_push_x', 0.0) or 0.0) + _ptr[2]
					player._push_z = (getattr(player, '_push_z', 0.0) or 0.0) + _ptr[3]
					veh_pos[0] += _ptr[0] + player._push_x * dt
					veh_pos[2] += _ptr[1] + player._push_z * dt
					player._push_x *= 0.90
					player._push_z *= 0.90
				except Exception:
					pass
				
				# --- Hull Rotation (WoT-style) ---
				turn_dir = steer
				
				# WoT reduces rotation speed on bad terrain and when moving
				# At full speed, rotation is ~60-80% of stationary rotation
				speed_ratio = abs(_veh_velocity[0]) / max(_phys_speedFwd, 0.1)
				rot_speed_modifier = 1.0 / (1.0 + speed_ratio * 0.5)
				# Terrain also affects rotation
				terrain_rot_modifier = 1.0 / _phys_terrainCoeff
				
				max_rot_speed = _phys_chassisRotSpd * rot_speed_modifier * terrain_rot_modifier
				
				# Smooth rotation ramp-up (tracks don't instantly grip)
				target_turn_vel = turn_dir * max_rot_speed
				turn_diff = target_turn_vel - _veh_turn_velocity[0]
				turn_accel = max_rot_speed * 4.0  # ~0.25s to reach full rotation speed
				
				if abs(turn_diff) < turn_accel * dt:
					_veh_turn_velocity[0] = target_turn_vel
				else:
					_veh_turn_velocity[0] += turn_accel * dt * (1 if turn_diff > 0 else -1)
				
				# Stop rotation smoothly when no input
				if turn_dir == 0 and abs(_veh_turn_velocity[0]) < 0.01:
					_veh_turn_velocity[0] = 0.0
				
				if _veh_turn_velocity[0] != 0.0:
					veh_yaw[0] += _veh_turn_velocity[0] * dt
					while veh_yaw[0] > math.pi: veh_yaw[0] -= 2*math.pi
					while veh_yaw[0] < -math.pi: veh_yaw[0] += 2*math.pi

				# --- Ground contact: stick to terrain on slopes, fall with gravity off ledges ---
				# Ray starts just above the hull (not +100) so bridges/roofs overhead are ignored
				try:
					col = BigWorld.wg_collideSegment(
						_offh_bspace(),
						Math.Vector3(veh_pos[0], veh_pos[1] + 2.0, veh_pos[2]),
						Math.Vector3(veh_pos[0], veh_pos[1] - 1000.0, veh_pos[2]), 128)
					if col is not None:
						# No +0.5 offset, chassis origin is at 0!
						ground_y = col[0].y
						# Downward snap distance that still counts as 'following the slope'
						snap_gap = max(0.8, min(2.5, abs(_veh_velocity[0]) * dt * 2.0 + 0.6))
						# Upward snap only within climbing ability: stops the hull from
						# popping ON TOP of fences/props (crush or stop at them instead)
						max_climb = max(0.6, abs(_veh_velocity[0]) * dt * 2.5)
						if veh_pos[1] < ground_y and (ground_y - veh_pos[1]) > max_climb:
							pass
						elif veh_pos[1] <= ground_y or ((veh_pos[1] - ground_y) <= snap_gap and not _veh_airborne[0]):
							# Soft ground-follow: below the surface snaps up hard (never sink,
							# tracks stay planted); above eases down (no teleport) but is capped
							# 0.12 m over ground so the hull never visibly floats on a downhill.
							if veh_pos[1] < ground_y:
								veh_pos[1] = ground_y
							else:
								veh_pos[1] += (ground_y - veh_pos[1]) * min(1.0, dt * 15.0)
								if veh_pos[1] > ground_y + 0.12:
									veh_pos[1] = ground_y + 0.12
							_veh_vert_vel[0] = 0.0
							_veh_airborne[0] = False
						else:
							# Ledge/cliff: ballistic fall, substepped so a fast drop can't clip/tunnel
							if not _veh_airborne[0]:
								LOG_DEBUG('OfflineBattle: player airborne, %.1fm to ground' % (veh_pos[1] - ground_y))
							_veh_airborne[0] = True
							_fall_n = 1
							if abs(_veh_vert_vel[0] * dt) > 0.5:
								_fall_n = min(8, int(abs(_veh_vert_vel[0] * dt) / 0.5) + 1)
							_fall_sdt = dt / _fall_n
							_fall_i = 0
							while _fall_i < _fall_n:
								_veh_vert_vel[0] -= _phys_gravity * _fall_sdt
								veh_pos[1] += _veh_vert_vel[0] * _fall_sdt
								if veh_pos[1] <= ground_y:
									veh_pos[1] = ground_y
									_veh_vert_vel[0] = 0.0   # kill vertical only; horizontal momentum kept
									_veh_airborne[0] = False
									break
								_fall_i += 1
					else:
						# No terrain below (map-edge cliff): free fall
						if not _veh_airborne[0]:
							LOG_DEBUG('OfflineBattle: player off map-edge, free fall')
						_veh_airborne[0] = True
						_veh_vert_vel[0] -= _phys_gravity * dt
						veh_pos[1] += _veh_vert_vel[0] * dt
				except Exception:
					pass

				# --- Drowning (probed ~3x/s): 10 s under water like the original; the
				# battle UI shows the drown icon + countdown via showVehicleTimer. ---
				try:
					player._offh_dchk = (getattr(player, '_offh_dchk', 9.0) or 9.0) + dt
					if player._offh_dchk >= 0.3:
						_dcel = player._offh_dchk
						player._offh_dchk = 0.0
						_wd = BigWorld.wg_collideWater(Math.Vector3(veh_pos[0], veh_pos[1] + 20.0, veh_pos[2]), Math.Vector3(veh_pos[0], veh_pos[1] - 5.0, veh_pos[2]), False)
						if _wd is not None and _wd >= 0.0 and (20.0 - _wd) > 1.6:
							player._offh_drown_t = getattr(player, '_offh_drown_t', 0.0) + _dcel
							if not getattr(player, '_offh_drown_ui', False):
								player._offh_drown_ui = True
								try:
									from gui import WindowsManager as _dwm
									_dbw = getattr(_dwm.g_windowsManager, 'battleWindow', None)
									if _dbw is not None:
										try:
											_dbw.showVehicleTimer('critical', max(0.0, 10.0 - player._offh_drown_t))
										except TypeError:
											_dbw.showVehicleTimer('critical')
								except Exception:
									pass
							if player._offh_drown_t > 10.0 and (getattr(mock_veh, 'health', 1) or 0) > 0:
								mock_veh.health = 0
								mock_veh.last_killer_id = -1
								LOG_DEBUG('OfflineBattle: player drowned')
						else:
							player._offh_drown_t = 0.0
							if getattr(player, '_offh_drown_ui', False):
								player._offh_drown_ui = False
								try:
									from gui import WindowsManager as _dwm
									_dbw = getattr(_dwm.g_windowsManager, 'battleWindow', None)
									if _dbw is not None:
										try:
											_dbw.hideVehicleTimer()
										except TypeError:
											_dbw.hideVehicleTimer('critical')
								except Exception:
									pass
				except Exception:
					pass

				# --- Dead-state sync: grey out EVERY destroyed tank in the players panel,
				# no matter which path killed it (player shot, bot, fire, ram, fall) ---
				try:
					_greyed = globals().setdefault('_offh_greyed_ids', set())
					_pl2 = BigWorld.player()
					_arena_v = getattr(getattr(_pl2, 'arena', None), 'vehicles', None)
					# perf: sweep runs 4x/s, not every frame
					_ds = globals().get('g_offh_ds_acc', 0.0) + dt
					globals()['g_offh_ds_acc'] = 0.0 if _ds >= 0.25 else _ds
					_fresh = []
					for _kid, _kv in ((globals().get('G_MOCK_VEHICLES', {}) or {}).items() if _ds >= 0.25 else ()):
						if _kid in _greyed:
							continue
						if _kid == getattr(_pl2, 'playerVehicleID', -1):
							_dead = getattr(_pl2, '_is_dead', False)
						else:
							_dead = (not getattr(_kv, 'isAlive', True)) or ((getattr(_kv, 'health', 1) or 0) <= 0)
						if _dead:
							_greyed.add(_kid)
							_fresh.append(_kid)
							if _arena_v is not None and _kid in _arena_v:
								try:
									_arena_v[_kid]['isAlive'] = False
									_arena_v[_kid]['isAvatarReady'] = False  # else panel keeps it 'alive' (vState=2)
								except Exception: pass
					if _fresh:
						try:
							from gui import WindowsManager
							_bw2 = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
							if _bw2 is not None:
								if hasattr(_bw2, '_Battle__updatePlayers'):
									_bw2._Battle__updatePlayers()
								if getattr(_bw2, 'minimap', None):
									for _dk in _fresh:
										try: _bw2.minimap.notifyVehicleStop(_dk)
										except Exception: pass
						except Exception: pass
				except Exception: pass

				# --- Turret & Gun Mouse Aiming ---
				# Safe default: the aiming code below only assigns 'mat' on its happy
				# path; without this the gun-marker block crashes every frame.
				mat = Math.Matrix(mock_veh.matrix)
				try:
					is_sniper = False
					is_arty = False
					aih = getattr(BigWorld.player(), 'inputHandler', None)
					if aih and getattr(aih, '_AvatarInputHandler__isStarted', False):
						ctrl = getattr(aih, 'ctrl', None)
						if ctrl is not None:
							name = ctrl.__class__.__name__
							if name == 'SniperControlMode': is_sniper = True
							if name == 'StrategicControlMode': is_arty = True

					# 1. First compute previous exact gun position
					try:
						td = loaded_models.get('td')
						turretOffs = td.hull['turretPositions'][0] + td.chassis['hullPosition']
						gunOffs = td.turret['gunPosition']
					except:
						turretOffs = Math.Vector3(0, 1.5, 0)
						gunOffs = Math.Vector3(0, 0.4, 1.0)

					turretWorldMatrix = Math.Matrix()
					turretWorldMatrix.setRotateY(turret_yaw[0])
					turretWorldMatrix.translation = turretOffs
					turretWorldMatrix.postMultiply(mock_veh.matrix)
					last_true_gun_pos = turretWorldMatrix.applyPoint(gunOffs)

					# 2. Get exact 3D point the crosshair is looking at
					shot_point = None
					try:
						if aih and getattr(aih, '_AvatarInputHandler__isStarted', False):
							shot_point = aih.getDesiredShotPoint()
					except Exception as e:
						pass
					# (POS-CHECK debug removed: ran every frame and referenced an undefined var)
					
					if shot_point is None:
						cam_mat = Math.Matrix(BigWorld.camera().matrix)
						cam_pos = cam_mat.translation
						cam_dir = cam_mat.applyToAxis(2)
						cam_dir.normalise()
						end_pos = cam_pos + cam_dir.scale(1000.0)
						col = BigWorld.wg_collideSegment(_offh_bspace(), cam_pos, end_pos, 128)
						if col is not None:
							shot_point = col[0]
						else:
							shot_point = end_pos
							# Strategic/SPG looks straight down: if the engine ray misses for a
							# frame, intersect the view ray with the last aim height instead of
							# letting the reticle jump to the ray end (ported arty-view fix).
							if is_arty and abs(cam_dir.y) > 0.0001:
								try:
									_ply = float(_gun_state.get('last_aim_y', 0.0) or 0.0)
									_pt = (_ply - cam_pos.y) / cam_dir.y
									if 0.0 < _pt <= 2000.0:
										shot_point = cam_pos + cam_dir.scale(_pt)
								except Exception:
									pass
						try:
							_gun_state['last_aim_y'] = float(shot_point.y)
						except Exception:
							pass

				# 3. Calculate target yaw and pitch
					# Vector from mathematical gun to the target					
					dx = shot_point.x - last_true_gun_pos.x
					dy = shot_point.y - last_true_gun_pos.y
					dz = shot_point.z - last_true_gun_pos.z
					dist = math.sqrt(dx*dx + dz*dz)
					
					try:
						if _gun_state.get('rmb_down', False) and not getattr(player, '_autoaim_target', None) and 'locked_local_yaw' in _gun_state:
							local_target_yaw = _gun_state['locked_local_yaw']
							target_pitch = _gun_state['locked_local_pitch']
							target_yaw = veh_yaw[0] + local_target_yaw
						else:
							if getattr(player, '_autoaim_target', None) and getattr(player._autoaim_target, 'health', 0) > 0:
								t_pos = Math.Vector3(player._autoaim_target.position)
								t_pos.y += 1.0
								shot_point = t_pos
							from projectile_trajectory import getShotAngles
							mat = BigWorld.player().getOwnVehicleMatrix()
							tYaw, gPitch = getShotAngles(td, mat, (turret_yaw[0], gun_pitch[0]), shot_point)
							local_target_yaw = tYaw
							target_pitch = gPitch
							target_yaw = veh_yaw[0] + local_target_yaw
					except Exception as e:
						# Fallback k jednoduche trigonometrii (nepresne)
						target_yaw = math.atan2(dx, dz)
						local_target_yaw = target_yaw - veh_yaw[0]
						
						if is_arty:
							try:
								shots = td.gun['shots'] if isinstance(td.gun, dict) else getattr(td.gun, 'shots')
								shot = shots[0]
								v = shot['speed'] if isinstance(shot, dict) else getattr(shot, 'speed')
								g = shot['gravity'] if isinstance(shot, dict) else getattr(shot, 'gravity', 9.81)
								g = abs(g)
								if g < 0.1: g = 9.81
								root = v**4 - g * (g * dist**2 + 2 * dy * v**2)
								if root > 0:
									target_pitch = -math.atan((v**2 - math.sqrt(root)) / (g * dist))
								else:
									target_pitch = -math.pi / 4 # 45 degrees max range fallback
							except Exception as ex:
								target_pitch = math.atan2(-dy, dist) # direct fire fallback
						else:
							target_pitch = math.atan2(-dy, dist)
					
					# Normalize angleses
					while local_target_yaw > math.pi: local_target_yaw -= 2*math.pi
					while local_target_yaw < -math.pi: local_target_yaw += 2*math.pi
					while turret_yaw[0] > math.pi: turret_yaw[0] -= 2*math.pi
					while turret_yaw[0] < -math.pi: turret_yaw[0] += 2*math.pi
					
					_gun_state['auto_steer'] = 0
					if not BigWorld.isKeyDown(Keys.KEY_RIGHTMOUSE):
						if _gun_min_yaw is not None and _gun_max_yaw is not None:
							# Check if aiming outside bounds
							if local_target_yaw < _gun_min_yaw - 0.02: _gun_state['auto_steer'] = -1
							elif local_target_yaw > _gun_max_yaw + 0.02: _gun_state['auto_steer'] = 1
					
					# Clamp to max traverse limits (for SPGs and TDs)
					local_target_yaw = max(_gun_min_yaw, min(_gun_max_yaw, local_target_yaw))
					
					diff_yaw = local_target_yaw - turret_yaw[0]
					if diff_yaw > math.pi: diff_yaw -= 2*math.pi
					if diff_yaw < -math.pi: diff_yaw += 2*math.pi
					
					# Actual turret angular speed this tick (rad/s), for the real
					# turretRotation dispersion term (was: remaining-yaw-delta hack).
					_gun_state['turret_speed'] = min(abs(diff_yaw) / max(dt, 0.001), _turret_rot_speed)
					
					# perf: outline scan ~8x/s (was every frame over all bots)
					player._outl_acc = (getattr(player, '_outl_acc', 9.0) or 9.0) + dt
					try:
						gun_dir = shot_point - last_true_gun_pos
						if player._outl_acc >= 0.12 and gun_dir.length > 0.001:
							gun_dir.normalise()
							_mock_vehicles = globals().get('G_MOCK_VEHICLES', {})
							
							import debug_utils
							if not hasattr(player, '_debug_dump_done_5'):
								player._debug_dump_done_5 = True
								debug_utils.LOG_DEBUG('AIH_TICK DUMP keys:', _mock_vehicles.keys())
								for _k, _v in _mock_vehicles.items():
									debug_utils.LOG_DEBUG(' - Veh', _k, getattr(_v, '_bot_team', 'N/A'))
							
							player._outl_acc = 0.0
							closest_bot = None
							min_dist = 9999.0
							for eid, m_veh in _mock_vehicles.iteritems():
								if eid == getattr(player, 'playerVehicleID', -1): continue
								if getattr(m_veh, 'health', 0) <= 0: continue
								b_pos = Math.Vector3(m_veh.position)
								b_vec = b_pos - last_true_gun_pos
								proj_len = b_vec.dot(gun_dir)
								# (per-frame log removed: file I/O for every bot every frame)
								if proj_len > 0:
									proj_pt = last_true_gun_pos + gun_dir.scale(proj_len)
									dist_to_ray = (b_pos - proj_pt).length
									# (per-frame log removed)
									if dist_to_ray < 2.5:
										if proj_len < min_dist:
											min_dist = proj_len
											closest_bot = m_veh
							prev_bot = getattr(player, '_outlined_bot', None)
							if prev_bot and prev_bot != closest_bot:
								try:
									if hasattr(prev_bot, 'bw_entity') and prev_bot.bw_entity:
										BigWorld.wgDelEdgeDetectEntity(prev_bot.bw_entity)
								except Exception as e:
									pass
								player._outlined_bot = None
							if closest_bot and prev_bot != closest_bot:
								color = 2 if getattr(closest_bot, '_bot_team', 2) == getattr(player, '_offhangar_team', 1) else 1
								try:
									if hasattr(closest_bot, 'bw_entity') and closest_bot.bw_entity:
										BigWorld.wgAddEdgeDetectEntity(closest_bot.bw_entity, color)
										LOG_DEBUG('REAL_RAYCAST OUTLINE APPLIED TO BOT', closest_bot.bw_entity.id)
									else:
										LOG_DEBUG('REAL_RAYCAST bot has no bw_entity!')
								except Exception as e:
									LOG_DEBUG('Outline dummy err:', str(e))
								player._outlined_bot = closest_bot
					except Exception as e:
						import debug_utils
						debug_utils.LOG_DEBUG('Outline error:', str(e))
					
					# Countdown: turret + gun frozen until the prebattle timer hits 0 (period 3)
					if getattr(getattr(BigWorld.player(), 'arena', None), 'period', 3) < 3:
						local_target_yaw = turret_yaw[0]; diff_yaw = 0.0; target_pitch = gun_pitch[0]
					_t_step = _turret_rot_speed * dt  # rad this frame (framerate independent)
					if abs(diff_yaw) < _t_step:
						turret_yaw[0] = local_target_yaw
					else:
						turret_yaw[0] += _t_step * (1 if diff_yaw > 0 else -1)
						
					# Update pitch
					# Yaw-dependent pitch limits (extraPitchLimits tanks have e.g. less
					# depression over the engine deck), same as the real VehicleGunRotator
					try:
						if _gun_pitch_desc is not None:
							from gun_rotation_shared import calcPitchLimitsFromDesc as _cpl
							_lim_now = _cpl(turret_yaw[0], _gun_pitch_desc)
							target_pitch = max(_lim_now[0], min(_lim_now[1], target_pitch))
						else:
							target_pitch = max(_gun_min_pitch, min(_gun_max_pitch, target_pitch))
					except Exception:
						target_pitch = max(_gun_min_pitch, min(_gun_max_pitch, target_pitch))
					
					diff_pitch = target_pitch - gun_pitch[0]
					_p_step = _gun_pitch_speed * dt  # vertical aim speed from gun descriptor (rad/s)
					if abs(diff_pitch) < _p_step:
						gun_pitch[0] = target_pitch
					else:
						gun_pitch[0] += _p_step * (1 if diff_pitch > 0 else -1)

					player = BigWorld.player()
					if not hasattr(player, 'addModel'):
						player.addModel = lambda m: _add_model(m)
					if not hasattr(player, 'delModel'):
						def _offh_delmodel(m):
							try: BigWorld.delModel(m)
							except Exception: pass
						player.delModel = _offh_delmodel

					# Mock appearance for SniperCamera to find HP_gunJoint
					if 'gun_node_matrix' not in loaded_models:
						loaded_models['gun_node_matrix'] = Math.Matrix()
					if not hasattr(mock_veh, 'appearance'):
						class FakeAppearance(object):
							def __init__(self):
								class FakeCompound(object):
									def node(self, name):
										if name == 'HP_gunJoint': return loaded_models['gun_node_matrix']
										if name == 'HP_turretJoint': return loaded_models.get('hull').node(name) if loaded_models.get('hull') else None
										return mock_veh.model.node(name)
									@property
									def position(self): return mock_veh.position
									@property
									def matrix(self): return mock_veh.matrix
								self.compoundModel = FakeCompound()
								self.modelsDesc = {'gun': {'model': loaded_models.get('gun')}}
							def changeVisibility(self, modelName, modelVisible, attachmentsVisible):
								is_sniper = not modelVisible
								c_mdl = loaded_models.get('chassis')
								h_mdl = loaded_models.get('hull')
								t_mdl = loaded_models.get('turret')
								g_mdl = loaded_models.get('gun')
								if hasattr(c_mdl, 'visible'): c_mdl.visible = not is_sniper
								if hasattr(h_mdl, 'visible'): h_mdl.visible = not is_sniper
								if hasattr(t_mdl, 'visible'): t_mdl.visible = not is_sniper
								if hasattr(g_mdl, 'visible'): g_mdl.visible = not is_sniper
							def hideIfExistFor(self, vehicle):
								pass
						mock_veh.appearance = FakeAppearance()
					
					# Debug log every 50 ticks (1 sec)
					_tick_counter[0] += 1
					if _tick_counter[0] % 50 == 0:
						try:
							cur_cam = Math.Matrix(BigWorld.camera().matrix)
							c_ptc = -cur_cam.pitch
						except:
							c_ptc = 0.0
						LOG_DEBUG('OfflineBattle.aim: cam_yaw=%.2f, veh_yaw=%.2f, loc_tgt=%.2f, tur_yaw=%.2f, cam_ptc=%.2f, gun_ptc=%.2f' % (
							target_yaw, veh_yaw[0], local_target_yaw, turret_yaw[0], c_ptc, gun_pitch[0]))
						
				except Exception as e:
					LOG_DEBUG('OfflineBattle.aim error:', str(e))


				# --- Update mock vehicle and camera matrix ---
				mock_veh.position = Math.Vector3(veh_pos[0], veh_pos[1], veh_pos[2])
				mock_veh.yaw   = veh_yaw[0]
				
				# DEBUG CHASSIS KEYS
				try:
					if getattr(mock_veh, '_dbg_keys_logged', None) is None:
						_td_dbg = loaded_models.get('td')
						if _td_dbg and hasattr(_td_dbg, 'chassis'):
							try: LOG_DEBUG('CHASSIS BBOX:', _td_dbg.chassis['hitTester'].bbox)
							except: pass
						import AreaDestructibles, inspect, constants
						if hasattr(AreaDestructibles, 'g_destructiblesManager'):
							if getattr(AreaDestructibles.g_destructiblesManager, 'getSpaceID', lambda: -1)() != _offh_bspace():
								AreaDestructibles.g_destructiblesManager.startSpace(_offh_bspace())
							try: LOG_DEBUG('DESTRUCTIBLE_MATKIND MIN/MAX:', constants.DESTRUCTIBLE_MATKIND.MIN, constants.DESTRUCTIBLE_MATKIND.MAX)
							except: pass
							try: LOG_DEBUG('BW collide doc:', BigWorld.collide.__doc__)
							except: pass
							try:
								# Log DestructiblesController methods!
								import AreaDestructibles
								if getattr(AreaDestructibles.g_destructiblesManager, 'getSpaceID', lambda: -1)() != _offh_bspace():
									AreaDestructibles.g_destructiblesManager.startSpace(_offh_bspace())
								chunkID = AreaDestructibles.chunkIDFromPosition(BigWorld.player().position)
								ctrl = AreaDestructibles.g_destructiblesManager.getController(chunkID)
								if ctrl:
									LOG_DEBUG('DestructiblesController dir:', dir(ctrl))
								else:
									LOG_DEBUG('DestructiblesController ctrl is NONE')
							except Exception as e:
								LOG_DEBUG('DestructiblesController EXCEPTION:', str(e))
							try: LOG_DEBUG('encodeDestructibleModule argspec:', inspect.getargspec(AreaDestructibles.encodeDestructibleModule))
							except: pass
							try: LOG_DEBUG('encodeFallenTree argspec:', inspect.getargspec(AreaDestructibles.encodeFallenTree))
							except: pass
							try: LOG_DEBUG('encodeFallenColumn argspec:', inspect.getargspec(AreaDestructibles.encodeFallenColumn))
							except: pass
							try: LOG_DEBUG('wg_getMatInfoNearPoint doc:', BigWorld.wg_getMatInfoNearPoint.__doc__)
							except: pass
							try: LOG_DEBUG('onChunkLoad argspec:', inspect.getargspec(AreaDestructibles.g_destructiblesManager.onChunkLoad))
							except: pass
						mock_veh._dbg_keys_logged = True
				except: pass
				
				# Vypočítat náklon tanku hráče podle terénu
				_p_ypr = _get_terrain_ypr(_offh_bspace(), mock_veh.position, veh_yaw[0])
				# --- Slope slide: static below the friction angle, accelerates above it ---
				# a = g*(sin t - mu*cos t); mu=0.70 -> ~35 deg is the static/slide boundary.
				_ptheta = math.atan(_p_ypr[5])
				_pss = getattr(player, '_slide_spd', 0.0)
				if _veh_airborne[0]:
					_pss = 0.0   # airborne = pure ballistic fall, no slide (same rule everywhere)
				else:
					# static friction to break loose, lower kinetic friction once moving
					_pmu = 0.45 if _pss > 0.05 else 0.60
					_pss += _phys_gravity * (math.sin(_ptheta) - _pmu * math.cos(_ptheta)) * dt
					if _pss < 0.0: _pss = 0.0
					if _pss > 14.0: _pss = 14.0
				player._slide_spd = _pss
				try:
					player._slide_dbg_t = getattr(player, '_slide_dbg_t', 0.0) + dt
					if _p_ypr[5] > 0.35 and player._slide_dbg_t > 1.0:
						player._slide_dbg_t = 0.0
						LOG_DEBUG('SLIDE dbg slope=%.2f deg=%.0f pss=%.2f air=%s vvel=%.2f' % (_p_ypr[5], math.degrees(_ptheta), _pss, _veh_airborne[0], _veh_velocity[0]))
				except: pass
				if not _veh_airborne[0] and _pss > 0.01 and (_p_ypr[3] != 0.0 or _p_ypr[4] != 0.0):
					_slp_x = veh_pos[0] + _p_ypr[3] * _pss * dt
					_slp_z = veh_pos[2] + _p_ypr[4] * _pss * dt
					try:
						_slp_c = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(_slp_x, veh_pos[1] + 8.0, _slp_z), Math.Vector3(_slp_x, veh_pos[1] - 30.0, _slp_z), 128)
					except Exception:
						_slp_c = None
					if _slp_c is not None and (veh_pos[1] - _slp_c[0].y) < 4.0:
						veh_pos[0] = _slp_x
						veh_pos[2] = _slp_z
						veh_pos[1] = _slp_c[0].y
						# Anti-penetration: lift so the uphill hull edge clears the rising bank
						try:
							_up_x = _slp_x - _p_ypr[3] * 3.0
							_up_z = _slp_z - _p_ypr[4] * 3.0
							_upc = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(_up_x, veh_pos[1] + 8.0, _up_z), Math.Vector3(_up_x, veh_pos[1] - 30.0, _up_z), 128)
							if _upc is not None:
								_pexp = veh_pos[1] + 3.0 * _p_ypr[5]
								if _upc[0].y > _pexp:
									veh_pos[1] += (_upc[0].y - _pexp)
						except Exception:
							pass
						_veh_vert_vel[0] = 0.0
						_veh_airborne[0] = False
						mock_veh.position = Math.Vector3(veh_pos[0], veh_pos[1], veh_pos[2])
				# Smooth pitch/roll so bumps and landings don't snap the hull instantly
				_pr_blend = min(1.0, dt * 8.0)
				_pr_p0 = getattr(mock_veh, 'pitch', 0.0)
				_pr_r0 = getattr(mock_veh, 'roll', 0.0)
				_p_ypr = (_p_ypr[0], _pr_p0 + (_p_ypr[1] - _pr_p0) * _pr_blend, _pr_r0 + (_p_ypr[2] - _pr_r0) * _pr_blend)
				mock_veh.pitch = _p_ypr[1]
				mock_veh.roll = _p_ypr[2]
				
				# Update base matrix IN PLACE so AvatarInputHandler doesn't lose the reference
				mock_veh.matrix.setRotateYPR(_p_ypr)
				mock_veh.matrix.translation = mock_veh.position
				
				if hasattr(mock_veh, 'filter'):
					mock_veh.filter.position = mock_veh.position
					mock_veh.filter.yaw = veh_yaw[0]
					
				# Update camera matrix (needs both translation AND yaw for SniperCamera offsets to work)
				# (Arcade camera strips yaw using WGTranslationOnlyMP later)
				new_m = Math.Matrix()
				new_m.setRotateYPR(_p_ypr)
				new_m.translation = mock_veh.position
				veh_matrix.a = new_m

				# Update chassis matrix (position + yaw) - Servo drives the model
				# Always update the chassis matrix, INCLUDING sniper mode. Sniper
				# hiding is done via model.visible=False nowadays (not the old
				# push-underground trick this skip was written for), and freezing
				# the matrix left the chassis/hull/gun models - and everything
				# attached to them: engine sound, gun shot sound, muzzle flash -
				# stuck at the position where the player scoped in, so audio and
				# shot effects played from the wrong place after driving scoped.
				chassis_new = Math.Matrix()
				chassis_new.setRotateYPR(_p_ypr)
				chassis_new.translation = mock_veh.position
				chassis_mp.a = chassis_new

				# Engine sounds are handled in _step_offline_physics


										
						

				# --- Update Gun Mechanics (Dispersion & Reload) ---
				if not _gun_state['initialized']:
					td = loaded_models.get('td')
					if td is not None and hasattr(td, 'gun'):
						try:
							_gun_state['base_dispersion'] = td.gun.get('shotDispersionAngle', 0.1) if isinstance(td.gun, dict) else getattr(td.gun, 'shotDispersionAngle', 0.1)
							if 'shotDispersionFactors' in td.gun if isinstance(td.gun, dict) else hasattr(td.gun, 'shotDispersionFactors'):
								_gun_state['after_shot'] = td.gun['shotDispersionFactors'].get('afterShot', 1.5) if isinstance(td.gun, dict) else td.gun.shotDispersionFactors.get('afterShot', 1.5)
							_gun_state['aim_time'] = td.gun.get('aimingTime', 2.0) if isinstance(td.gun, dict) else getattr(td.gun, 'aimingTime', 2.0)
							if 'clip' in td.gun if isinstance(td.gun, dict) else hasattr(td.gun, 'clip'):
								_clip = td.gun['clip'] if isinstance(td.gun, dict) else td.gun.clip
								_gun_state['clip_size'] = _clip[0]
								_gun_state['clip_reload'] = _clip[1]
							_gun_state['reload'] = td.gun.get('reloadTime', 5.0) if isinstance(td.gun, dict) else getattr(td.gun, 'reloadTime', 5.0)
							
							_gun_state['ammo'] = 45
							if hasattr(td, 'maxAmmo'): _gun_state['ammo'] = td.maxAmmo
							elif isinstance(td.gun, dict) and 'maxAmmo' in td.gun: _gun_state['ammo'] = td.gun['maxAmmo']
							elif hasattr(td.gun, 'maxAmmo'): _gun_state['ammo'] = td.gun.maxAmmo
							elif hasattr(td, 'turret') and hasattr(td.turret, 'maxAmmo'): _gun_state['ammo'] = td.turret.maxAmmo
							
							# Equipment & Crew Modifiers
							has_rammer, has_egld, has_vents, has_vstab, has_rations = False, False, False, False, False
							has_bia, has_snapshot, has_smooth_ride = True, False, False
							
							# Hardcode consumables if none found or to guarantee they exist in offline mode
							_gun_state['consumables'] = [
								{'slot': 3, 'tag': 'repairkit', 'name': 'smallrepairkit', 'icon': '../maps/icons/artefact/smallRepairkit.png', 'used': False},
								{'slot': 4, 'tag': 'medkit', 'name': 'smallmedkit', 'icon': '../maps/icons/artefact/smallMedkit.png', 'used': False},
								{'slot': 5, 'tag': 'extinguisher', 'name': 'handextinguishers', 'icon': '../maps/icons/artefact/handExtinguishers.png', 'used': False}
							]
							
							try:
								from CurrentVehicle import g_currentVehicle
								if g_currentVehicle and hasattr(g_currentVehicle, 'item') and g_currentVehicle.item:
									v_item = g_currentVehicle.item
									
									try:
										import debug_utils
										debug_utils.LOG_DEBUG('DEBUG STATS COMP: td.gun.aimingTime=', getattr(td.gun, 'aimingTime', None), 'v_item.descriptor.gun.aimingTime=', getattr(v_item.descriptor.gun, 'aimingTime', None))
									except: pass
									
									# Parse Equipment
									for dev in getattr(v_item, 'optDevices', []):
										if not dev: continue
										name = getattr(dev, 'name', '') or getattr(getattr(dev, 'descriptor', None), 'name', '') or str(dev)
										name = str(name).lower()
										import debug_utils
										debug_utils.LOG_DEBUG('Parsed Equipment Name:', name)
										if 'rammer' in name: has_rammer = True
										if 'aimdrives' in name: has_egld = True
										if 'ventilation' in name: has_vents = True
										if 'stabilizer' in name: has_vstab = True
									# Parse Consumables from g_currentVehicle if available
									# (We already hardcoded them above, but we can override if needed)
									
									_eqs_list = list(getattr(v_item, 'eqs', []))
									if any(_eqs_list):
										_gun_state['consumables'] = []
									
									for idx, eq in enumerate(_eqs_list):
										if not eq: continue
										name = getattr(eq, 'name', '') or getattr(getattr(eq, 'descriptor', None), 'name', '') or str(eq)
										name = str(name).lower()
										if any(x in name for x in ('ration', 'chocolate', 'cola', 'coffee', 'pudding')): has_rations = True
										icon = getattr(eq, 'icon', None) or getattr(getattr(eq, 'descriptor', None), 'icon', None)
										icon_path = icon[0] if icon and isinstance(icon, tuple) else ''
										if not icon_path:
											if 'medkit' in name: icon_path = '../maps/icons/artefact/smallMedkit.png'
											elif 'repair' in name: icon_path = '../maps/icons/artefact/smallRepairkit.png'
											elif 'extinguisher' in name: icon_path = '../maps/icons/artefact/handExtinguishers.png'
										
										import debug_utils
										debug_utils.LOG_DEBUG('DUMP CONSUMABLE:', name, icon, icon_path)
										tag_name = 'extinguisher' if 'extinguisher' in name else ('medkit' if 'medkit' in name else ('repairkit' if 'repair' in name else ''))
										if tag_name:
											_gun_state['consumables'].append({
												'slot': idx + 3,
												'tag': tag_name,
												'name': name,
												'icon': icon_path,
												'used': False
											})
										
									# Parse Crew Perks
									crew = getattr(v_item, 'crew', [])
									import debug_utils
									debug_utils.LOG_DEBUG('CREW OBJECT IS:', len(crew), crew)
									if not crew: has_bia = False
									for idx, item in enumerate(crew):
										try:
											tman = item[1] if isinstance(item, tuple) and len(item) == 2 else item
											
											if tman is None:
												has_bia = False
												continue
											
											tman_skills = []
											if hasattr(tman, 'skills'):
												for sk in tman.skills:
													name = getattr(sk, 'name', '') or str(sk)
													tman_skills.append(str(name).lower())
											elif hasattr(tman, 'descriptor') and hasattr(tman.descriptor, 'skills'):
												tman_skills = [str(sk).lower() for sk in tman.descriptor.skills]
											
											if 'brotherhood' not in tman_skills: has_bia = False
											if 'smoothturret' in tman_skills or 'snapshot' in tman_skills: has_snapshot = True
											if 'smoothdriving' in tman_skills or 'smoothride' in tman_skills: has_smooth_ride = True
										except Exception as ce:
											import debug_utils
											debug_utils.LOG_DEBUG('Crew member parsing error:', str(ce))
											has_bia = False
							except Exception as e:
								import debug_utils
								debug_utils.LOG_DEBUG('Equipment/Crew parsing error:', str(e))
								has_bia = False
							
							# Calculate crew multiplier (Base 100% crew + Commander 10% bonus)
							crew_skill, commander_skill = 100.0, 100.0
							if has_vents:
								crew_skill += 5.0
								commander_skill += 5.0
							if has_bia:
								crew_skill += 5.0
								commander_skill += 5.0
							if has_rations:
								crew_skill += 10.0
								commander_skill += 10.0
							effective_skill = crew_skill + (commander_skill * 0.1)
							crew_mult = 1.0 / (0.5 + 0.005 * effective_skill)
							
							_gun_state['base_dispersion'] *= crew_mult
							_gun_state['aim_time'] *= crew_mult
							_gun_state['reload'] *= crew_mult
							_gun_state['clip_reload'] *= crew_mult
							
							if has_rammer:
								_gun_state['reload'] *= 0.9
								_gun_state['clip_reload'] *= 0.9
							if has_egld:
								_gun_state['aim_time'] /= 1.1
							_gun_state['has_vstab'] = has_vstab
							_gun_state['has_snapshot'] = has_snapshot
							_gun_state['has_smooth_ride'] = has_smooth_ride
							
						except Exception as e:
							LOG_DEBUG('OfflineBattle: Gun State Init ERROR:', str(e))
						_gun_state['clip'] = _gun_state['clip_size']
						_gun_state['dispersion'] = _gun_state['base_dispersion']
						_gun_state['initialized'] = True
						LOG_DEBUG('OfflineBattle: Gun State initialized from TD: dispersion=%.3f, aim_time=%.2f, reload=%.2f, clip_size=%d' % (
							_gun_state['base_dispersion'], _gun_state['aim_time'], _gun_state['reload'], _gun_state['clip_size']))

				if _gun_state['initialized']:
					try:
						# 1. Dispersion shrinkage
	
						if 'GUI_INIT' not in _gun_state:
							try:
								from gui import WindowsManager
								panel = getattr(WindowsManager.g_windowsManager.battleWindow, 'consumablesPanel', None) if getattr(WindowsManager.g_windowsManager, 'battleWindow', None) else None
								if panel:
									try:
										td = loaded_models.get('td')
										shots = td.gun['shots'] if isinstance(td.gun, dict) else getattr(td.gun, 'shots', [])
										
										# Distribute maxAmmo across available shells
										ammo_pool = _gun_state['ammo']
										try:
											from CurrentVehicle import g_currentVehicle
											v_shells = []
											if g_currentVehicle and g_currentVehicle.item:
												shells = getattr(g_currentVehicle.item, 'shells', [])
												for sh in shells:
													if hasattr(sh, 'count'): v_shells.append(sh.count)
													elif isinstance(sh, tuple) and len(sh) >= 2: v_shells.append(sh[1])
										except:
											v_shells = []
											
										for i, shot in enumerate(shots):
											try: shell = shot['shell']
											except: shell = getattr(shot, 'shell', None)
											try: piercing_val = shot['piercingPower']
											except: piercing_val = getattr(shot, 'piercingPower', 100)
											if isinstance(piercing_val, (tuple, list)): piercing_val = piercing_val[0]
											
											if v_shells and i < len(v_shells):
												qty = v_shells[i]
											else:
												qty = int(ammo_pool * 0.6) if i == 0 else (int(ammo_pool * 0.3) if i == 1 else int(ammo_pool * 0.1))
												if qty == 0 and ammo_pool > 0: qty = 1
											
											_gun_state['ammo_%d' % i] = qty
											panel.addShellSlot(i, qty, _gun_state['clip_size'], _gun_state['clip_size'], shell, piercing_val)
											
										# Find first shell with > 0 ammo
										first_active = 0
										for i in xrange(len(shots)):
											if _gun_state.get('ammo_%d' % i, 0) > 0:
												first_active = i
												break
										_gun_state['shot_index'] = first_active
										
										# Select the first shell as active to show clip UI
										panel.setCurrentShell(first_active)
										panel.setShellQuantityInSlot(first_active, _gun_state['ammo_%d' % first_active], _gun_state['clip'])
									except Exception as ex: LOG_DEBUG('SHELL SLOT FAIL:', str(ex))
									
									try:
										import AvatarInputHandler.aims as aim
										aim.setClipParams(_gun_state['clip_size'], 1)
										aim.setAmmoStock(_gun_state['ammo_%d' % first_active], _gun_state['clip'], False)
										
										# Vynutit reset ukazatele zdraví v GUI!
										from gui import WindowsManager
										bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
										if bw is not None:
											_mh = getattr(td, 'maxHealth', 400)
											if hasattr(bw, 'damagePanel'):
												try: bw.damagePanel._DamagePanel__callFlash('setMaxHealth', [_mh])
												except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
												bw.damagePanel.updateHealth(_mh)
											if hasattr(bw, 'vMarkersManager'):
												pass # bw.vMarkersManager.updateVehicleHealth(player.playerVehicleID, _mh, 1, 0)
									except Exception as e: pass
									
									# Add Consumables to UI
									if not _gun_state.get('consumables_added_to_ui'):
										_gun_state['consumables_added_to_ui'] = True
										import debug_utils
										debug_utils.LOG_DEBUG('ADDING CONSUMABLES TO UI:', _gun_state.get('consumables', []))
										
										class FakeEqDescr(object):
											def __init__(self, tag, icon, name):
												self.tags = set([tag])
												self.icon = [icon]
												self.userString = name
												self.description = ''
										
										for cons in _gun_state.get('consumables', []):
											idx = cons['slot']
											tag = cons['tag']
											icon = cons['icon']
											name = cons['name']
											try:
												panel.addEquipmentSlot(idx, 1, FakeEqDescr(tag, icon, name))
											except Exception as e:
												import debug_utils
												debug_utils.LOG_DEBUG('Failed to addEquipmentSlot:', str(e))
									
									_gun_state['GUI_INIT'] = True
									LOG_DEBUG('OfflineBattle: GUI panel initialized!')
							except Exception as e:
								LOG_DEBUG('OfflineBattle GUI Init Error:', str(e))
						cur_time = BigWorld.time()
						if 'last_time' not in _gun_state: _gun_state['last_time'] = cur_time
						dt = cur_time - _gun_state['last_time']
						_gun_state['last_time'] = cur_time
						
						# Real dispersion model (Avatar.getOwnVehicleShotDispersionAngle):
						#   ideal = base * sqrt(1 + (v*chassisMove)^2 + (vR*chassisRot)^2
						#                          + (wTurret*gunTurretRotation)^2)
						# with PER-TANK chassis/gun factors (already unit-converted to m/s and
						# rad/s by the descriptor parser). The old code called the Avatar
						# method, which never exists on the offline Account, so it ALWAYS fell
						# back to a generic linear 0.015/unit penalty identical for every tank.
						target_disp = _gun_state['base_dispersion']
						try:
							import math
							_d_td = loaded_models.get('td')
							_cm, _cr = _d_td.chassis['shotDispersionFactors']
							_gdf = _d_td.gun['shotDispersionFactors'] if isinstance(_d_td.gun, dict) else _d_td.gun.shotDispersionFactors
							_gt = _gdf['turretRotation']
							v_speed, r_speed = player.getOwnVehicleSpeeds()
							_mv = v_speed * _cm
							_rv = r_speed * _cr
							_tv = _gun_state.get('turret_speed', 0.0) * _gt
							# Equipment: vStab dampens all movement bloom, snap shot the turret
							# term, smooth ride the hull-movement term.
							if _gun_state.get('has_vstab', False):
								_mv *= 0.8; _rv *= 0.8; _tv *= 0.8
							if _gun_state.get('has_snapshot', False):
								_tv *= 0.925
							if _gun_state.get('has_smooth_ride', False):
								_mv *= 0.96
							target_disp = _gun_state['base_dispersion'] * math.sqrt(1.0 + _mv * _mv + _rv * _rv + _tv * _tv)
						except Exception:
							try:
								v_speed, r_speed = player.getOwnVehicleSpeeds()
								target_disp += abs(v_speed) * 0.015 + abs(r_speed) * 0.015
							except Exception:
								pass
						
						if _gun_state['dispersion'] > target_disp:
							import math
							# Real decay: aimingFactor = start * exp((start-now)/aimingTime) - the
							# aim_time IS the time constant; the old 2.5x made aiming 2.5x too fast.
							factor = math.exp(-dt / max(_gun_state['aim_time'], 0.1))
							_gun_state['dispersion'] = target_disp + (_gun_state['dispersion'] - target_disp) * factor
						else:
							_gun_state['dispersion'] = min(_gun_state['dispersion'] + (target_disp - _gun_state['dispersion']) * 0.2, 5.0)

						# 2. Reload logic
						if _gun_state['reloadTime'] > 0:
							_gun_state['reloadTime'] -= dt
							if _gun_state['reloadTime'] <= 0:
								_gun_state['reloadTime'] = 0.0
								if _gun_state['clip'] == 0:
									_gun_state['clip'] = _gun_state['clip_size']
								
								# Reset UI cooldown and refresh ammo count when reload finishes
								try:
									from gui import WindowsManager
									panel = WindowsManager.g_windowsManager.battleWindow.consumablesPanel
									if panel:
										shot_idx = _gun_state.get('shot_index', 0)
										panel.setShellQuantityInSlot(shot_idx, _gun_state['ammo_%d' % shot_idx], _gun_state['clip'])
										panel.setCoolDownTime(shot_idx, 0.0)
									aim = getattr(g_offline_aih, 'aim', None)
									if aim:
										aim.setReloading(0.0, None)
										shot_idx = _gun_state.get('shot_index', 0)
										aim.setAmmoStock(_gun_state['ammo_%d' % shot_idx], _gun_state['clip'], True if _gun_state['clip'] == _gun_state['clip_size'] else False)
									
									try:
										if not hasattr(BigWorld.player(), 'soundNotifications'):
											import gui.IngameSoundNotifications as IngameSoundNotifications
											BigWorld.player().soundNotifications = IngameSoundNotifications.IngameSoundNotifications()
											BigWorld.player().soundNotifications.start()
										BigWorld.player().soundNotifications.play('gun_reloaded')
									except: pass
								except Exception:
									pass
					except Exception as e:
						LOG_DEBUG('OfflineBattle dispersion error:', str(e))

					# 3. Update Crosshair + AIH
					try:
						# Let the engine update the aim crosshair
						# Compute where the gun is actually pointing (offset start pos by 4.0m to avoid hitting our own tank hull!)
						try:
							td = loaded_models.get('td')
							turretOffs = td.hull['turretPositions'][0] + td.chassis['hullPosition']
							gunOffs = td.turret['gunPosition']
						except:
							turretOffs = Math.Vector3(0, 1.5, 0)
							gunOffs = Math.Vector3(0, 0.4, 1.0)

						turretWorldMatrix = Math.Matrix()
						turretWorldMatrix.setRotateY(turret_yaw[0])
						turretWorldMatrix.translation = turretOffs
						turretWorldMatrix.postMultiply(mock_veh.matrix)

						true_gun_pos = turretWorldMatrix.applyPoint(gunOffs)

						gunWorldMatrix = Math.Matrix()
						gunWorldMatrix.setRotateX(gun_pitch[0])
						gunWorldMatrix.translation = gunOffs
						gunWorldMatrix.postMultiply(turretWorldMatrix)
						
						gun_dir = gunWorldMatrix.applyToAxis(2)
						gun_dir.normalise()
						
						if 'gun_node_matrix' in loaded_models:
							# Store ONLY the true_gun_pos (pivot). NO rotation.
							# SniperCamera applies its own pitch/yaw from mouse input,
							# and then automatically applies the tank's configured pivotPos.
							_cam_m = Math.Matrix()  # identity = no rotation
							_cam_m.translation = true_gun_pos
							loaded_models['gun_node_matrix'].set(_cam_m)
						
						# Pass gun pos to rotator for Arty/Arcade raycasts
						if hasattr(player, 'gunRotator'):
							player.gunRotator._gun_pos = true_gun_pos
							player.gunRotator._gun_dir = gun_dir
							
						is_arty = False
						try: is_arty = 'SPG' in td.type.tags
						except: pass
						# Calculate exact terrain intersection for the green marker (perfectly simulates server)
						_end_gun = true_gun_pos + gun_dir.scale(10000.0)
						_col_gun = None
						try:
							_col_gun = BigWorld.wg_collideSegment(_offh_bspace(), true_gun_pos, _end_gun, 128)
						except Exception:
							pass
						gun_target_pos = _col_gun[0] if _col_gun is not None else _end_gun
						
						if hasattr(player, 'gunRotator') and len(player.gunRotator.markerInfo) >= 2:
							mtp = player.gunRotator.markerInfo[0]
							mdir = player.gunRotator.markerInfo[1]
							
							if isinstance(mtp, tuple) and mtp == (0.0, 0.0, 0.0):
								pass # Offline stub, ignore
							elif isinstance(mtp, Math.Vector3) and mtp.lengthSquared == 0.0:
								pass # Offline stub, ignore
							else:
								if isinstance(mtp, tuple):
									gun_target_pos = Math.Vector3(mtp[0], mtp[1], mtp[2])
								else:
									gun_target_pos = mtp
									
								if isinstance(mdir, tuple):
									gun_dir = Math.Vector3(mdir[0], mdir[1], mdir[2])
								else:
									gun_dir = mdir
							
						if _tick_counter[0] % 50 == 0:
							LOG_DEBUG('OfflineBattle.gun: target_pos=', gun_target_pos, 'dir=', gun_dir, 'pos=', true_gun_pos)
							
						# Hide vehicle in sniper mode using model.visible
						if hasattr(g_offline_aih, 'ctrl'):
							is_sniper = g_offline_aih.ctrl.__class__.__name__ == 'SniperControlMode'
							was_sniper = getattr(g_offline_aih, '_was_sniper', None)
							if is_sniper != was_sniper:
								g_offline_aih._was_sniper = is_sniper
								# A muzzle flash played while the models were hidden (fired in
								# sniper) lingers frozen when they become visible again - stop it.
								try:
									_mp = getattr(BigWorld.player(), '_offhangar_muzzle_player', None)
									if _mp is not None:
										_mp.stop()
								except Exception:
									pass
								for _part in ('chassis', 'hull', 'turret', 'gun'):
									_mdl = loaded_models.get(_part)
									if _mdl is not None:
										try: _mdl.visible = not is_sniper
										except: pass
								# Tank is hidden via .visible=False, so no need to push underground.
								# Keeping it at real position ensures 3D sounds (engine, gun) remain audible!

						# Calculate perfectly synchronous math_gun_world for raycast
						math_turret_pos = td.chassis['hullPosition'] + td.hull['turretPositions'][0]
						math_gun_world = Math.Matrix(mat).applyPoint(math_turret_pos)
						yaw_mat = Math.Matrix()
						yaw_mat.setRotateY(turret_yaw[0])
						math_gun_world += Math.Matrix(mat).applyVector(yaw_mat.applyVector(td.turret['gunPosition']))

						_end_gun = math_gun_world + gun_dir.scale(10000.0)
						if not is_arty:
							_col_gun = BigWorld.wg_collideSegment(_offh_bspace(), math_gun_world, _end_gun, 128)
							if _col_gun is not None:
								gun_hit = _col_gun
								dist_to_target = (shot_point - math_gun_world).length
								if gun_hit[1] < dist_to_target:
									dist_to_static = (gun_hit[0] - math_gun_world).length
									if dist_to_target - dist_to_static > 1.0:
										gun_target_pos = math_gun_world + gun_dir.scale(dist_to_target)
									else:
										gun_target_pos = gun_hit[0]
								else:
									gun_target_pos = math_gun_world + gun_dir.scale(dist_to_target)
							else:
								gun_target_pos = math_gun_world + gun_dir.scale(10000.0)
						else:
							gun_target_pos = math_gun_world + gun_dir.scale(10000.0)

						# UPDATE CROSSHAIR
						if hasattr(g_offline_aih, 'ctrl'):
							try:
								if hasattr(player, 'gunRotator'):
									player.gunRotator.dispersionAngle = _gun_state['dispersion']
								
								dist_m = (gun_target_pos - math_gun_world).length
								size_m = _gun_state['dispersion'] * dist_m * 2.0
								
								# Native penetration marker: feed collData so the stock gun
								# marker colours itself green/orange/red by whether the loaded
								# shell pierces the plate under the reticle. Only direct-fire
								# modes own a _FlashGunMarker; others stay None (raycast skipped).
								# pen_indicator is pure math (no models/effects/state) = leak-free.
								_pen_coll = None
								try:
									_pen_cn = g_offline_aih.ctrl.__class__.__name__
									if _pen_cn in ('SniperControlMode', 'ArcadeControlMode'):
										try:
											player.vehicleTypeDescriptor.activeGunShotIndex = _gun_state.get('shot_index', 0)
										except Exception:
											pass
										# Sample armor along the ACTUAL shot ray (muzzle pos +
										# gun dir), not the marker vectors - else the ray grazes
										# the hull and reads a bogus near-infinite armor.
										_pen_start = math_gun_world
										_pen_dir = gun_dir
										try:
											_sp, _sd = player.gunRotator._VehicleGunRotator__getCurShotPosition()
											_pen_start = _sp
											_pen_dir = Math.Vector3(_sd)
											_pen_dir.normalise()
										except Exception:
											pass
										_pen_wd = None
										try:
											if _col_gun is not None:
												_pen_wd = (_col_gun[0] - _pen_start).length
										except Exception:
											_pen_wd = None
										from gui.mods.offhangar import pen_indicator as _peni
										_pen_coll = _peni.build_coll_data(
											globals().get('G_MOCK_VEHICLES', {}) or {},
											getattr(player, 'playerVehicleID', -1),
											getattr(player, 'team', getattr(player, '_offhangar_team', 1)),
											_pen_start, _pen_dir, _pen_wd)
								except Exception as _pie:
									LOG_DEBUG('OfflineBattle pen-colldata error:', str(_pie))
								g_offline_aih.ctrl.updateGunMarker(gun_target_pos, gun_dir, size_m, 0.0, _pen_coll)
							except Exception as e:
								LOG_DEBUG('OfflineBattle updateGunMarker error:', str(e), 'pos:', true_gun_pos, 'dir:', gun_dir)
							try:
								g_offline_aih.ctrl.updateGunMarker2(gun_target_pos, gun_dir, size_m, 0.0, _pen_coll)
							except Exception as e:
								pass
								
							if _gun_state.get('tick_counter', 0) % 60 == 0:
								import debug_utils
								try:
									cam_m_debug = Math.Matrix(BigWorld.camera().matrix)
									debug_utils.LOG_DEBUG("DEBUG DIR", "cam_pos:", cam_m_debug.translation, "gun_pos:", true_gun_pos)
									debug_utils.LOG_DEBUG("DEBUG DIR", "cam_dir:", cam_m_debug.applyToAxis(2), "gun_dir:", gun_dir)
									debug_utils.LOG_DEBUG("DEBUG DIR", "tYaw:", tYaw, "gPitch:", gPitch)
								except: pass
							_gun_state['tick_counter'] = _gun_state.get('tick_counter', 0) + 1
								
							# Synchronize ammo UI when switching control modes
							aim = getattr(g_offline_aih, 'aim', None)
							if aim and aim != _gun_state.get('last_aim'):
								_gun_state['last_aim'] = aim
								try:
									if hasattr(aim, 'setClipParams'): aim.setClipParams(_gun_state['clip_size'], 1)
									if hasattr(aim, 'setAmmoStock'): aim.setAmmoStock(_gun_state['ammo_%d' % _gun_state.get('shot_index', 0)], _gun_state['clip'], False)
									if _gun_state['reloadTime'] > 0 and hasattr(aim, 'setReloading'): aim.setReloading(_gun_state['reloadTime'], None)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
					except Exception as e:
						import traceback
						LOG_DEBUG('OfflineBattle fatal gun error:', traceback.format_exc())
						
				# Update turret rotation (via node matrix)
				turret_mat = loaded_models.get('turret_mat')
				if turret_mat is not None:
					turret_mat.setRotateYPR((turret_yaw[0], 0, 0))

				# Update gun pitch (via node matrix)
				gun_mat = loaded_models.get('gun_mat')
				if gun_mat is not None:
					gun_mat.setRotateYPR((0, gun_pitch[0], 0))

				
						
				# --- Update turret_matrix for camera/AIH ---
				tm = Math.Matrix()
				tm.setRotateYPR((veh_yaw[0] + turret_yaw[0], gun_pitch[0], 0))
				try:
					td = loaded_models.get('td')
					turret_offs = td.hull['turretPositions'][0] + td.chassis['hullPosition']
					tm.translation = mock_veh.matrix.applyPoint(turret_offs)
				except:
					tm.translation = Math.Vector3(veh_pos[0], veh_pos[1] + 2.0, veh_pos[2])
				turret_matrix.set(tm)
				
				tm_local = Math.Matrix()
				tm_local.setRotateYPR((turret_yaw[0], gun_pitch[0], 0))
				turret_matrix_local.set(tm_local)

				# --- PLAYER FIRE LOGIC ---
				try:
					_player_mock = mock_vehicles.get(getattr(player, 'playerVehicleID', -1))
					_sync_burn_and_death(_player_mock, loaded_models.get('hull'), loaded_models.get('td'))
					_sync_engine_exhaust(_player_mock, loaded_models.get('hull'), loaded_models.get('td'), _veh_velocity[0])
					if _player_mock and getattr(_player_mock, 'is_on_fire', False) and getattr(_player_mock, 'health', 0) > 0:
						cur_timer = getattr(_player_mock, '_fire_timer', 0.0)
						if cur_timer is None: cur_timer = 0.0
						_player_mock._fire_timer = float(cur_timer) + 0.02
						if _player_mock._fire_timer >= 1.0:
							_player_mock._fire_timer -= 1.0
							fire_dmg = max(1, int(_player_mock.maxHealth * 0.05))
							_player_mock.health -= fire_dmg
							
							try:
								import gui.WindowsManager
								bw = gui.WindowsManager.g_windowsManager.battleWindow
								import debug_utils
								debug_utils.LOG_DEBUG("PLAYER_FIRE_TICK! bw: ", bw)
								if bw:
									debug_utils.LOG_DEBUG("BW_DIR: ", dir(bw))
									if hasattr(bw, 'damagePanel'):
										debug_utils.LOG_DEBUG("DAMAGE_PANEL_DIR: ", dir(bw.damagePanel))
										bw.damagePanel.updateHealth(_player_mock.health)
							except: pass
							
							if _player_mock.health <= 0:
								_player_mock.health = 0
								player.arena.onVehicleKilled(getattr(_player_mock, 'id', player.playerVehicleID), getattr(_player_mock, 'last_killer_id', -1), 2)
								_player_mock.is_on_fire = False
								try:
									import gui.WindowsManager
									bw = gui.WindowsManager.g_windowsManager.battleWindow
									if hasattr(bw, 'damagePanel'):
										bw.damagePanel._DamagePanel__callFlash('onFireInVehicle', [False])
								except: pass
							
							if hasattr(player, 'vehicle') and player.vehicle:
								player.vehicle.health = _player_mock.health
								try: player.guiSessionProvider.invalidateVehicleState(1, player.playerVehicleID, _player_mock.health, _player_mock.health)
								except: pass
				except: pass

				# --- BOT AI (Advanced Physics) ---
				import math, random
				dt = _frame_dt # real frame delta: bot speed/reload no longer depends on FPS
				for eid, m_veh in mock_vehicles.iteritems():
					if eid != getattr(player, 'playerVehicleID', -1) and getattr(m_veh, 'isAlive', False):
						try:
							my_team = getattr(m_veh, '_bot_team', m_veh.publicInfo.get('team', 2) if getattr(m_veh, 'publicInfo', None) is not None else 2)
							closest_dist = 99999.0
							target_pos = None
							# INIT BOT STATES
							if getattr(m_veh, '_veh_velocity', None) is None: m_veh._veh_velocity = 0.0
							if getattr(m_veh, '_veh_turn_velocity', None) is None: m_veh._veh_turn_velocity = 0.0
							
							# perf: full enemy scan only every ~0.4 s per bot (staggered); between
							# scans the cached target is tracked LIVE by id - aiming stays frame-exact,
							# only the re-pick of a new target is throttled. Dead/gone target -> rescan.
							m_veh._tgt_t = (getattr(m_veh, '_tgt_t', 9.0) or 9.0) + dt
							_tref = getattr(m_veh, '_tgt_ref', None)
							player_team = getattr(player, '_offhangar_team', 1)
							_p_ok = my_team != player_team and getattr(player, 'playerVehicleID', -1) != -1 and getattr(player, 'health', 1) > 0
							if _tref == 'P':
								if not _p_ok:
									_tref = None
							elif _tref is not None:
								_tv = mock_vehicles.get(_tref)
								if _tv is None or not getattr(_tv, 'isAlive', False):
									_tref = None
							if _tref is not None and m_veh._tgt_t < 0.4:
								if _tref == 'P':
									target_pos = veh_pos
								else:
									_tv = mock_vehicles.get(_tref)
									target_pos = (_tv.position.x, _tv.position.y, _tv.position.z)
							else:
								m_veh._tgt_t = (eid % 8) * 0.05
								m_veh._tgt_ref = None
								if _p_ok:
									dx = veh_pos[0] - m_veh.position.x
									dz = veh_pos[2] - m_veh.position.z
									dist = math.sqrt(dx*dx + dz*dz)
									if dist < closest_dist:
										closest_dist = dist
										target_pos = veh_pos
										m_veh._tgt_ref = 'P'
								for oeid, omeh in mock_vehicles.iteritems():
									if oeid == getattr(player, 'playerVehicleID', -1): continue
									if oeid != eid and getattr(omeh, 'isAlive', False):
										oteam = getattr(omeh, '_bot_team', omeh.publicInfo.get('team', 2) if getattr(omeh, 'publicInfo', None) is not None else 2)
										if my_team != oteam:
											dx = omeh.position.x - m_veh.position.x
											dz = omeh.position.z - m_veh.position.z
											dist = math.sqrt(dx*dx + dz*dz)
											if dist < closest_dist:
												closest_dist = dist
												target_pos = (omeh.position.x, omeh.position.y, omeh.position.z)
												m_veh._tgt_ref = oeid
							if target_pos is None:
								# NO ENEMIES! STOP!
								m_veh._veh_velocity = max(0.0, m_veh._veh_velocity - 20.0 * dt)
								m_veh._veh_turn_velocity = 0.0
								target_pos = (m_veh.position.x, m_veh.position.y, m_veh.position.z)
							dx = target_pos[0] - m_veh.position.x
							dz = target_pos[2] - m_veh.position.z
							dist = math.sqrt(dx*dx + dz*dz)
							_dc = (getattr(m_veh, '_dbg_ctr', 0) or 0)
							if _dc % 200 == 0:
								LOG_DEBUG('BOT_AI eid=%s vel=%.2f dist=%.1f tgt=%s escape=%s' % (str(eid), m_veh._veh_velocity, dist, str(target_pos is not None), str(getattr(m_veh, '_wall_escape', 0))))

							_td = getattr(m_veh, 'typeDescriptor', None) or loaded_models.get('td')
							
							# READ PHYSICS
							bot_mass = 30000.0
							bot_enginePowerW = 500000.0
							bot_speedFwd = 10.0
							bot_speedBwd = 5.0
							bot_terrainCoeff = 1.0
							bot_specificFriction = 0.8
							bot_chassisRotSpd = 0.5
							
							try:
								if _td:
									if 'weight' in _td.physics: bot_mass = float(_td.physics['weight'])
									if 'enginePower' in _td.physics: bot_enginePowerW = float(_td.physics['enginePower'])
									if 'speedLimits' in _td.physics:
										bot_speedFwd = float(_td.physics['speedLimits'][0])
										bot_speedBwd = float(_td.physics['speedLimits'][1])
									if 'terrainResistance' in _td.physics: bot_terrainCoeff = float(_td.physics['terrainResistance'][0])
									if 'specificFriction' in _td.physics: bot_specificFriction = float(_td.physics['specificFriction'])
									if hasattr(_td, 'chassis') and 'rotationSpeed' in _td.chassis:
										# chassis['rotationSpeed'] je v rad/s (ne stupně)
										raw_rot = float(_td.chassis['rotationSpeed'])
										# Pokud je hodnota > 2*pi, je ve stupních – konvertovat
										bot_chassisRotSpd = math.radians(raw_rot) if raw_rot > 6.3 else raw_rot
									elif 'rotationSpeedLimit' in _td.physics:
										# rotationSpeedLimit je již v rad/s
										bot_chassisRotSpd = float(_td.physics['rotationSpeedLimit'])
							except: pass
							
							# VIRTUAL DRIVER
							throttle = 0.0
							turn_dir = 0

							# Preliminary yaw to target (needed by feelers before blending)
							_raw_target_yaw = math.atan2(dx, dz)
							_raw_diff_yaw = _raw_target_yaw - m_veh.yaw
							while _raw_diff_yaw > math.pi:  _raw_diff_yaw -= 2*math.pi
							while _raw_diff_yaw < -math.pi: _raw_diff_yaw += 2*math.pi

							# --- STUCK DETECTOR ---
							# Track last position; if not moved >0.5m in 100 ticks (2 sec), force reverse escape
							_last_p = getattr(m_veh, '_last_pos', None)
							_cur_escape = getattr(m_veh, '_wall_escape', None) or 0
							_stuck_ctr = getattr(m_veh, '_stuck_ctr', 0) or 0
							
							if _cur_escape > 0:
								_stuck_ctr = 0
								m_veh._last_pos = (m_veh.position.x, m_veh.position.z)
							else:
								_stuck_ctr += 1
								if _stuck_ctr >= 100:
									if _last_p is not None:
										_moved = math.sqrt((m_veh.position.x-_last_p[0])**2 + (m_veh.position.z-_last_p[1])**2)
										if _moved < 0.5:
											m_veh._wall_escape = 60
											m_veh._wall_turn = 1 if _raw_diff_yaw > 0 else -1
									m_veh._last_pos = (m_veh.position.x, m_veh.position.z)
									_stuck_ctr = 0
							m_veh._stuck_ctr = _stuck_ctr
							
							_escape = getattr(m_veh, '_wall_escape', None) or 0
							if _escape > 0:
								m_veh._wall_escape = _escape - 1
								# Reversing escape: drive backwards and turn
								throttle = -0.7
								turn_dir = getattr(m_veh, '_wall_turn', 1)
								diff_yaw = _raw_diff_yaw
								target_yaw = _raw_target_yaw
							else:
								# --- SEPARATION: repulsion from nearby bots ---
								sep_x = 0.0
								sep_z = 0.0
								for _seid, _smeh in mock_vehicles.iteritems():
									if _seid == eid: continue
									_sdx = m_veh.position.x - _smeh.position.x
									_sdz = m_veh.position.z - _smeh.position.z
									_sd = math.sqrt(_sdx*_sdx + _sdz*_sdz)
									if 0.5 < _sd < 12.0:
										_w = (12.0 - _sd) / 12.0
										sep_x += (_sdx / _sd) * _w
										sep_z += (_sdz / _sd) * _w

								# --- ADVANCED MULTI-RAY SENSORS (Local Avoidance) ---
								_feeler_steer_yaw = None
								if True:
									_ray_angles = [0.0]
									_step = 0.25
									for i in range(1, 6): # up to 1.25 rad (~71 degrees)
										if _raw_diff_yaw > 0:
											_ray_angles.extend([i * _step, -i * _step])
										else:
											_ray_angles.extend([-i * _step, i * _step])
									
									# Two passes: first try a wide safe margin (2.2m), if boxed in, try a tighter margin (1.6m)
									for _hw in (2.2, 1.6):
										_center_blocked = False
										_best_clear_angle = None
										
										for _fyo in _ray_angles:
											_fy = m_veh.yaw + _fyo
											_hit = False
											
											# Width-aware sensors: Left track, Center, Right track
											_cos_fy = math.cos(_fy)
											_sin_fy = math.sin(_fy)
											
											# Dual-height rays: catch low rocks (0.7m) and tall buildings (1.5m)
											_ray_profiles = [(0.7, 7.0), (1.5, 12.0)]
											
											for _h, _dist in _ray_profiles:
												if _hit: break
												
												# 1. Terrain elevation check (Cliffs and High Hills)
												_dest_x = m_veh.position.x + _sin_fy * _dist
												_dest_z = m_veh.position.z + _cos_fy * _dist
												_dest_y = m_veh.position.y
												
												try:
													_g_hit = BigWorld.wg_collideSegment(_offh_bspace(), 
														Math.Vector3(_dest_x, m_veh.position.y + 4.0, _dest_z), 
														Math.Vector3(_dest_x, m_veh.position.y - 15.0, _dest_z), 128)
													if _g_hit:
														_dest_y = _g_hit[0].y
													else:
														_hit = True # Abyss / out of bounds
												except: pass
												
												if _hit: break
												
												_y_diff = _dest_y - m_veh.position.y
												if _y_diff > _dist * 0.45 or _y_diff < -_dist * 0.7:
													_hit = True
													break
													
												# 2. Obstacle check (parallel to slope)
												for _ox in (-_hw, 0.0, _hw):
													_sx = m_veh.position.x + _cos_fy * _ox
													_sz = m_veh.position.z - _sin_fy * _ox
													try:
														_fs = Math.Vector3(_sx, m_veh.position.y + _h, _sz)
														_fe = Math.Vector3(_sx + _sin_fy*_dist, _dest_y + _h, _sz + _cos_fy*_dist)
														if BigWorld.wg_collideSegment(_offh_bspace(), _fs, _fe, 128):
															_hit = True
															break
													except: pass
											
											if _fyo == 0.0:
												if _hit: 
													_center_blocked = True
												else:
													break # Center is clear
											else:
												if not _hit:
													_best_clear_angle = _fyo
													break
													
										if not _center_blocked:
											break # Center is clear on this margin
										if _best_clear_angle is not None:
											_feeler_steer_yaw = m_veh.yaw + _best_clear_angle
											break # Found a clear path
											
									# If even tight margin fails, we just keep current steering and let stuck detector handle reversing if we crash
								
								# Hysteresis: keep steering into the clear path for a moment
								if _feeler_steer_yaw is not None:
									m_veh._feeler_timer = 15
									m_veh._feeler_mem = _feeler_steer_yaw
								else:
									_ft = getattr(m_veh, '_feeler_timer', 0) or 0
									if _ft > 0:
										m_veh._feeler_timer = _ft - 1
										_feeler_steer_yaw = getattr(m_veh, '_feeler_mem', None)
								
								if _feeler_steer_yaw is not None:
									target_yaw = _feeler_steer_yaw
								else:
									# Blend target dir + separation
									_ndx = dx / dist if dist > 0.1 else 0.0
									_ndz = dz / dist if dist > 0.1 else 0.0
									_rdx = _ndx + sep_x * 1.5
									_rdz = _ndz + sep_z * 1.5
									target_yaw = math.atan2(_rdx, _rdz)
								diff_yaw = target_yaw - m_veh.yaw
								while diff_yaw > math.pi:  diff_yaw -= 2*math.pi
								while diff_yaw < -math.pi: diff_yaw += 2*math.pi

								if dist > 15.0:
									if abs(diff_yaw) < 0.5: throttle = 1.0
									elif abs(diff_yaw) > 2.0: throttle = -0.5
									else: throttle = 0.5

								if diff_yaw > 0.05: turn_dir = 1
								elif diff_yaw < -0.05: turn_dir = -1

							m_veh._dbg_ctr = (getattr(m_veh, '_dbg_ctr', 0) or 0) + 1
							
							# IMMOBILIZATION CHECK
							_dev_hp = getattr(m_veh, 'devices_hp', None)
							if getattr(m_veh, 'is_tracked', False) or (_dev_hp is not None and _dev_hp.get('engineHealth', 1) <= 0):
								throttle = 0.0
								turn_dir = 0.0
								
							# FIRE LOGIC (Damage Over Time)
							_sync_burn_and_death(m_veh, getattr(m_veh, '_hull_model', None), getattr(m_veh, 'typeDescriptor', None))
							_sync_engine_exhaust(m_veh, getattr(m_veh, '_hull_model', None), getattr(m_veh, 'typeDescriptor', None), getattr(m_veh, '_veh_velocity', 0.0) or 0.0)
							if getattr(m_veh, 'is_on_fire', False) and m_veh.health > 0:
								cur_timer = getattr(m_veh, '_fire_timer', 0.0)
								if cur_timer is None: cur_timer = 0.0
								m_veh._fire_timer = float(cur_timer) + float(dt if dt is not None else 0.02)
								if m_veh._fire_timer >= 1.0: # Tick every 1 second
									m_veh._fire_timer -= 1.0
									fire_dmg = max(1, int(m_veh.maxHealth * 0.05)) # 5% max HP per sec
									m_veh.health -= fire_dmg
									
									try:
										import BigWorld
										from gui import WindowsManager
										bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
										
										if m_veh.health <= 0:
											m_veh.health = 0
											BigWorld.player().arena.onVehicleKilled(m_veh.id, (getattr(m_veh, 'last_killer_id', None) or -1), 2)
										elif bw and hasattr(bw, 'vMarkersManager'):
											player_id = getattr(BigWorld.player(), 'playerVehicleID', -1)
											if m_veh.id == player_id:
												player = BigWorld.player()
												if hasattr(player, 'vehicle') and player.vehicle:
													player.vehicle.health = m_veh.health
													try: player.guiSessionProvider.invalidateVehicleState(1, player_id, m_veh.health, m_veh.health)
													except: pass
											else:
												marker = getattr(m_veh, 'marker', None)
												if marker is not None:
													bw.vMarkersManager.onVehicleHealthChanged(marker, m_veh.health, 1, 0)
													try: bw.vMarkersManager.showVehicleDamageInfo(marker, fire_dmg, 0, 0, 1)
													except: pass
													LOG_DEBUG('Fire HP updated via marker, HP=%d' % m_veh.health)
									except: pass

							# Pre-battle countdown: the line-up holds position (like the original)
							if getattr(getattr(player, 'arena', None), 'period', 3) < 3:
								throttle = 0.0
								turn_dir = 0
								m_veh._veh_velocity = 0.0
								m_veh._veh_turn_velocity = 0.0

							# ACCELERATION & MOVEMENT
							bot_gravity = 9.81
							cur_vel = m_veh._veh_velocity
							engine_force = 0.0
							if throttle != 0:
								engine_force = bot_enginePowerW / max(abs(cur_vel), 1.5)
								max_engine_force = bot_mass * bot_gravity * 0.7
								engine_force = min(engine_force, max_engine_force) * throttle
								
							base_track_rr = 0.07
							resist_force = bot_mass * bot_gravity * bot_terrainCoeff * base_track_rr
							
							braking = False
							if throttle == 0 and abs(cur_vel) > 0.01: braking = True
							elif throttle != 0 and ((throttle > 0 and cur_vel < -0.1) or (throttle < 0 and cur_vel > 0.1)): braking = True
							
							if braking:
								brake_force = bot_mass * bot_gravity * bot_terrainCoeff * bot_specificFriction
								if cur_vel > 0: net_force = -brake_force + engine_force
								else: net_force = brake_force + engine_force
							elif throttle == 0: net_force = 0.0
							else:
								if throttle > 0: net_force = engine_force - resist_force
								else: net_force = engine_force + resist_force
								
							accel = net_force / bot_mass
							if getattr(m_veh, '_airborne', False):
								accel = 0.0
							elif throttle != 0 or abs(cur_vel) > 0.01:
								# Slope: gravity along the hull (pitch < 0 = nose up)
								# perf: slope probe (2 rays) refreshed ~7x/s per bot instead of every frame
								m_veh._dp_acc = (getattr(m_veh, '_dp_acc', 9.0) or 9.0) + dt
								if m_veh._dp_acc >= 0.15:
									m_veh._dp_acc = 0.0
									m_veh._dp_v = _drive_pitch(_offh_bspace(), m_veh.position.x, m_veh.position.z, m_veh.yaw, m_veh.position.y)
								accel += bot_gravity * math.sin(getattr(m_veh, '_dp_v', 0.0) or 0.0)
							m_veh._veh_velocity += accel * dt
							if braking and throttle == 0 and cur_vel != 0.0 and (cur_vel > 0.0) != (m_veh._veh_velocity > 0.0):
								m_veh._veh_velocity = 0.0
							if m_veh._veh_velocity > bot_speedFwd: m_veh._veh_velocity = bot_speedFwd
							elif m_veh._veh_velocity < -bot_speedBwd: m_veh._veh_velocity = -bot_speedBwd
							
							# No throttle: rolling resistance bleeds speed off (damp, not a hard stop)
							if throttle == 0 and not braking and m_veh._veh_velocity != 0.0:
								_brr = bot_gravity * 0.06 * dt
								if abs(m_veh._veh_velocity) <= _brr: m_veh._veh_velocity = 0.0
								elif m_veh._veh_velocity > 0.0: m_veh._veh_velocity -= _brr
								else: m_veh._veh_velocity += _brr
							
							try:
								if not getattr(m_veh, '_snd_init', False):
									_engine_d = getattr(_td, 'engine', None) if _td else None
									_chassis_d = getattr(_td, 'chassis', None) if _td else None
									if hasattr(_td, 'engine') and isinstance(_td.engine, dict): _engine_d = _td.engine
									if hasattr(_td, 'chassis') and isinstance(_td.chassis, dict): _chassis_d = _td.chassis
									if _engine_d and hasattr(m_veh, '_chassis_model') and getattr(m_veh._chassis_model, 'inWorld', False): 
										m_veh._snd_engine = m_veh._chassis_model.playSound(_engine_d['sound'])
									if _chassis_d and hasattr(m_veh, '_chassis_model') and getattr(m_veh._chassis_model, 'inWorld', False): 
										m_veh._snd_tracks = m_veh._chassis_model.playSound(_chassis_d['sound'])
									if getattr(m_veh, '_chassis_model', None) and m_veh._chassis_model.inWorld: m_veh._snd_init = True
									if m_veh._snd_init and getattr(m_veh, '_snd_tracks', None):
										# VehicleAppearance zeroes these for all non-player vehicles;
										# left at event defaults they can add wrong terrain flavour.
										for _pn in ('ground', 'stone', 'wood', 'snow', 'sand', 'water', 'hardness', 'friction', 'roughness', 'flying'):
											try:
												_pp = m_veh._snd_tracks.param(_pn)
												if _pp is not None: _pp.value = 0.0
											except Exception: pass
								
								cur_speed = abs(m_veh._veh_velocity)
								# Continuous load blend (see player path: discrete values retrigger FMOD)
								power_fraction = min(1.0, (cur_speed / bot_speedFwd) + (abs(throttle) * 0.3))
								load = 1.0 + (power_fraction * 2.0)
								
								if getattr(m_veh, '_snd_engine', None):
									p = getattr(m_veh, '_p_load', None)
									if p is None:
										p = m_veh._snd_engine.param('load')  # resolve once per bot
										m_veh._p_load = p
									if p: p.value = load
								if getattr(m_veh, '_snd_tracks', None):
									p = getattr(m_veh, '_p_spd', None)
									if p is None:
										p = m_veh._snd_tracks.param('speed')
										m_veh._p_spd = p
									if p: p.value = cur_speed / bot_speedFwd
							except Exception as _e: pass
							
							# COLLISION - always checked when moving
							if m_veh._veh_velocity != 0.0:
								_hit_wall = False
								m_veh._cw_fc = (getattr(m_veh, '_cw_fc', 0) or 0) + 1
								if abs(m_veh._veh_velocity) > 0.5:
									try:
										_fell_trees_near(_offh_bspace(), m_veh.position, m_veh.yaw, m_veh._veh_velocity, _td)
									except: pass
								# perf: wall scan alternates frames per bot (<0.5 m travel between checks)
								if abs(m_veh._veh_velocity) > 0.5 and ((m_veh._cw_fc + eid) & 1) == 0:
									try:
										_hit_wall = _check_horizontal_collision(_offh_bspace(), m_veh.position, m_veh.yaw, m_veh._veh_velocity, _td)
									except: pass
								_bnx = m_veh.position.x + math.sin(m_veh.yaw) * m_veh._veh_velocity * dt
								_bnz = m_veh.position.z + math.cos(m_veh.yaw) * m_veh._veh_velocity * dt
								if _hit_wall:
									m_veh._veh_velocity *= 0.2
								else:
									m_veh.position = Math.Vector3(_bnx, m_veh.position.y, _bnz)
								# Tank-vs-tank: velocity-relative impulse (e=0) + Baumgarte push-apart
								try:
									_bsvx = math.sin(m_veh.yaw) * m_veh._veh_velocity + (getattr(m_veh, '_push_x', 0.0) or 0.0)
									_bsvz = math.cos(m_veh.yaw) * m_veh._veh_velocity + (getattr(m_veh, '_push_z', 0.0) or 0.0)
									_btr = _tank_resolve(eid, m_veh.position.x, m_veh.position.z, m_veh.yaw, _td, 1.0 / max(bot_mass, 1.0), _bsvx, _bsvz)
									_bpx = (getattr(m_veh, '_push_x', 0.0) or 0.0) + _btr[2]
									_bpz = (getattr(m_veh, '_push_z', 0.0) or 0.0) + _btr[3]
									m_veh.position = Math.Vector3(m_veh.position.x + _btr[0] + _bpx * dt, m_veh.position.y, m_veh.position.z + _btr[1] + _bpz * dt)
									m_veh._push_x = _bpx * 0.90
									m_veh._push_z = _bpz * 0.90
								except: pass
							
							# ROTATION
							speed_ratio = abs(m_veh._veh_velocity) / max(bot_speedFwd, 0.1)
							rot_speed_modifier = 1.0 / (1.0 + speed_ratio * 0.5)
							terrain_rot_modifier = 1.0 / bot_terrainCoeff
							max_rot_speed = bot_chassisRotSpd * rot_speed_modifier * terrain_rot_modifier
							
							target_turn_vel = turn_dir * max_rot_speed
							turn_diff = target_turn_vel - m_veh._veh_turn_velocity
							turn_accel = max_rot_speed * 4.0
							
							if abs(turn_diff) < turn_accel * dt: m_veh._veh_turn_velocity = target_turn_vel
							else: m_veh._veh_turn_velocity += turn_accel * dt * (1 if turn_diff > 0 else -1)
							
							if turn_dir == 0 and abs(m_veh._veh_turn_velocity) < 0.01: m_veh._veh_turn_velocity = 0.0
							
							if m_veh._veh_turn_velocity != 0.0:
								m_veh.yaw += m_veh._veh_turn_velocity * dt
								while m_veh.yaw > math.pi: m_veh.yaw -= 2*math.pi
								while m_veh.yaw < -math.pi: m_veh.yaw += 2*math.pi
							
							# TERRAIN SNAP (ray starts just above the hull so bridges overhead are ignored)
							try:
								ground_hit = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(m_veh.position.x, m_veh.position.y + 2.0, m_veh.position.z), Math.Vector3(m_veh.position.x, m_veh.position.y - 1000.0, m_veh.position.z), 128)
								if ground_hit:
									_bg_y = ground_hit[0].y
									_b_snap = max(0.8, min(2.5, abs(m_veh._veh_velocity) * dt * 2.0 + 0.6))
									_b_climb = max(0.6, abs(m_veh._veh_velocity) * dt * 2.5)
									if m_veh.position.y < _bg_y and (_bg_y - m_veh.position.y) > _b_climb:
										pass
									elif m_veh.position.y <= _bg_y or ((m_veh.position.y - _bg_y) <= _b_snap and not getattr(m_veh, '_airborne', False)):
										# Soft ground-follow: below snaps up hard, above eases down (cap 0.12 m)
										if m_veh.position.y < _bg_y:
											_bfy = _bg_y
										else:
											_bfy = m_veh.position.y + (_bg_y - m_veh.position.y) * min(1.0, dt * 15.0)
											if _bfy > _bg_y + 0.12:
												_bfy = _bg_y + 0.12
										m_veh.position = Math.Vector3(m_veh.position.x, _bfy, m_veh.position.z)
										m_veh._vert_vel = 0.0
										m_veh._airborne = False
									else:
										m_veh._airborne = True
										_bvv = (getattr(m_veh, '_vert_vel', 0.0) or 0.0)
										_bfall_n = 1
										if abs(_bvv * dt) > 0.5:
											_bfall_n = min(8, int(abs(_bvv * dt) / 0.5) + 1)
										_bfall_sdt = dt / _bfall_n
										_by = m_veh.position.y
										_bfall_i = 0
										while _bfall_i < _bfall_n:
											_bvv -= bot_gravity * _bfall_sdt
											_by += _bvv * _bfall_sdt
											if _by <= _bg_y:
												_by = _bg_y
												_bvv = 0.0
												m_veh._airborne = False
												break
											_bfall_i += 1
										m_veh._vert_vel = _bvv
										m_veh.position = Math.Vector3(m_veh.position.x, _by, m_veh.position.z)
							except: pass
							
							# perf: 4-ray tilt sampling alternates frames per bot; yaw stays live,
							# the pitch/roll smoothing below hides the halved sample rate
							m_veh._ypr_fc = (getattr(m_veh, '_ypr_fc', 0) or 0) + 1
							if getattr(m_veh, '_ypr_c', None) is None or ((m_veh._ypr_fc + eid) & (1 if getattr(m_veh, '_spot_visible', True) else 3)) == 0:
								m_veh._ypr_c = _get_terrain_ypr(_offh_bspace(), m_veh.position, m_veh.yaw)
							_b_ypr = (m_veh.yaw, m_veh._ypr_c[1], m_veh._ypr_c[2], m_veh._ypr_c[3], m_veh._ypr_c[4], m_veh._ypr_c[5])
							# --- Slope slide (bot): static below friction angle, accelerates above ---
							_btheta = math.atan(_b_ypr[5])
							_bss = getattr(m_veh, '_slide_spd', 0.0) or 0.0
							if getattr(m_veh, '_airborne', False):
								_bss = 0.0   # airborne = pure ballistic fall, no slide
							else:
								_bmu = 0.45 if _bss > 0.05 else 0.60
								_bss += bot_gravity * (math.sin(_btheta) - _bmu * math.cos(_btheta)) * dt
								if _bss < 0.0: _bss = 0.0
								if _bss > 14.0: _bss = 14.0
							m_veh._slide_spd = _bss
							if not getattr(m_veh, '_airborne', False) and _bss > 0.01 and (_b_ypr[3] != 0.0 or _b_ypr[4] != 0.0):
								_slb_x = m_veh.position.x + _b_ypr[3] * _bss * dt
								_slb_z = m_veh.position.z + _b_ypr[4] * _bss * dt
								try:
									_slb_c = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(_slb_x, m_veh.position.y + 8.0, _slb_z), Math.Vector3(_slb_x, m_veh.position.y - 30.0, _slb_z), 128)
								except Exception:
									_slb_c = None
								if _slb_c is not None and (m_veh.position.y - _slb_c[0].y) < 4.0:
									m_veh.position = Math.Vector3(_slb_x, _slb_c[0].y, _slb_z)
									m_veh._vert_vel = 0.0
									m_veh._airborne = False
							# Smooth pitch/roll so bots don't jitter on rough terrain
							_b_blend = min(1.0, dt * 8.0)
							_b_p0 = getattr(m_veh, 'pitch', 0.0) or 0.0
							_b_r0 = getattr(m_veh, 'roll', 0.0) or 0.0
							m_veh.pitch = _b_p0 + (_b_ypr[1] - _b_p0) * _b_blend
							m_veh.roll = _b_r0 + (_b_ypr[2] - _b_r0) * _b_blend
							_b_ypr = (_b_ypr[0], m_veh.pitch, m_veh.roll)
							
							m_veh.matrix.setRotateYPR(_b_ypr)
							m_veh.matrix.translation = m_veh.position
							# --- Spotting: unspotted ENEMY tanks are hidden like the real game.
							# Simulation keeps running; only rendering/markers/minimap are culled.
							try:
								_sen = globals().get('g_offh_spotting')
								if _sen is None:
									try:
										from _constants import CONFIG_OPTIONS as _SCFG
										_sen = bool(_SCFG.get('spotting_enabled', True))
									except Exception:
										_sen = True
									globals()['g_offh_spotting'] = _sen
								if _sen and getattr(m_veh, 'isAlive', True) and getattr(m_veh, '_bot_team', 2) != (getattr(player, '_offhangar_team', 1) or 1):
									m_veh._spot_chk = (getattr(m_veh, '_spot_chk', 9.0) or 9.0) + dt
									if m_veh._spot_chk >= 0.5:
										m_veh._spot_chk = (eid % 10) * 0.05  # stagger re-checks across bots
										_svr = globals().get('g_offh_viewrange', 0.0)
										if not _svr:
											try:
												_svr = float(loaded_models['td'].turret.get('circularVisionRadius', 400.0))
											except Exception:
												_svr = 400.0
											globals()['g_offh_viewrange'] = _svr
										_sdx = m_veh.position.x - veh_pos[0]
										_sdz = m_veh.position.z - veh_pos[2]
										_sd2 = _sdx * _sdx + _sdz * _sdz
										_seen = False
										if _sd2 <= 2500.0:
											_seen = True  # 50 m proximity spot
										elif _sd2 <= _svr * _svr:
											_slos = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(veh_pos[0], veh_pos[1] + 2.5, veh_pos[2]), Math.Vector3(m_veh.position.x, m_veh.position.y + 1.5, m_veh.position.z), 128)
											_seen = _slos is None
										if not _seen:
											# Team vision: living allied bots relay spots to the player (radio).
											# Cheap distance pass over all allies, then ONE ray to the nearest.
											_tvb = None
											_tvd = 1e18
											_tpid = getattr(player, 'playerVehicleID', -1)
											for _tvm in (globals().get('G_MOCK_VEHICLES', {}) or {}).values():
												if _tvm is m_veh or getattr(_tvm, 'id', -1) == _tpid:
													continue
												if not getattr(_tvm, 'isAlive', True):
													continue
												if (getattr(_tvm, '_bot_team', 2) or 2) != (getattr(player, '_offhangar_team', 1) or 1):
													continue
												_tdx = m_veh.position.x - _tvm.position.x
												_tdz = m_veh.position.z - _tvm.position.z
												_td2 = _tdx * _tdx + _tdz * _tdz
												if _td2 <= 2500.0:
													_seen = True  # 50 m proximity spot by an ally
													_tvb = None
													break
												if _td2 <= _svr * _svr and _td2 < _tvd:
													_tvd = _td2
													_tvb = _tvm
											if (not _seen) and _tvb is not None:
												_tlos = BigWorld.wg_collideSegment(_offh_bspace(), Math.Vector3(_tvb.position.x, _tvb.position.y + 2.5, _tvb.position.z), Math.Vector3(m_veh.position.x, m_veh.position.y + 1.5, m_veh.position.z), 128)
												_seen = _tlos is None
										if _seen:
											m_veh._spot_until = BigWorld.time() + 5.0  # spot memory
									_svis = BigWorld.time() < ((getattr(m_veh, '_spot_until', 0.0) or 0.0))
									if _svis != getattr(m_veh, '_spot_visible', True):
										m_veh._spot_visible = _svis
										_sch = getattr(m_veh, '_chassis_model', None)
										if _sch is not None:
											try:
												_sch.visible = _svis
												_sch.visibleAttachments = _svis
											except Exception:
												pass
										try:
											from gui import WindowsManager as _WMs
											_bws = getattr(_WMs.g_windowsManager, 'battleWindow', None)
											if _bws is not None:
												_vmm = getattr(_bws, 'vMarkersManager', None)
												if _vmm is not None:
													if _svis:
														if getattr(m_veh, 'marker', None) in (None, -1):
															m_veh.marker = _vmm.createMarker(m_veh.proxy)
													else:
														if getattr(m_veh, 'marker', None) not in (None, -1):
															try:
																_vmm.destroyMarker(m_veh.marker)
															except Exception:
																pass
															m_veh.marker = None
												_smm = getattr(_bws, 'minimap', None)
												if _smm is not None:
													if _svis:
														_smm.notifyVehicleStart(eid)
													else:
														_smm.notifyVehicleStop(eid)
										except Exception:
											pass
							except Exception:
								pass
							# Track scroll (bot): y=left, z=right, traverse via turn rate
							try:
								_bfa = getattr(m_veh, '_fashion', None)
								if _bfa is not None:
									_bfa.movementInfo = Math.Vector4(0.0, m_veh._veh_velocity - m_veh._veh_turn_velocity * 1.5, m_veh._veh_velocity + m_veh._veh_turn_velocity * 1.5, 0.0)
							except Exception: pass
							# Drowning (bot, probed ~3x/s for perf): deep water destroys after ~5 s
							try:
								m_veh._dwn_chk = (getattr(m_veh, '_dwn_chk', 9.0) or 9.0) + dt
								if m_veh._dwn_chk >= 0.3:
									_bdel = m_veh._dwn_chk
									m_veh._dwn_chk = 0.0
									_bwd = BigWorld.wg_collideWater(Math.Vector3(m_veh.position.x, m_veh.position.y + 20.0, m_veh.position.z), Math.Vector3(m_veh.position.x, m_veh.position.y - 5.0, m_veh.position.z), False)
									if _bwd is not None and _bwd >= 0.0 and (20.0 - _bwd) > 1.6:
										m_veh._drown_t = (getattr(m_veh, '_drown_t', 0.0) or 0.0) + _bdel
										if m_veh._drown_t > 10.0 and (getattr(m_veh, 'health', 1) or 0) > 0:
											m_veh.health = 0
											m_veh.isAlive = False
											try: player.arena.onVehicleKilled(eid, -1, 0)
											except Exception: pass
									else:
										m_veh._drown_t = 0.0
							except Exception: pass
							
							try:
								if getattr(m_veh, '_spot_visible', True) and getattr(m_veh, 'bw_entity', None) is not None and getattr(m_veh.bw_entity, 'filter', None) is not None:
									m_veh.bw_entity.filter.set(BigWorld.time(), _offh_bspace(), m_veh.bw_entity.id, m_veh.position, (m_veh.matrix.roll, m_veh.matrix.pitch, m_veh.matrix.yaw), 0)
							except: pass
							
							if hasattr(m_veh, '_chassis_model'):
								if not getattr(m_veh, '_servo_added', False):
									try:
										m_veh._chassis_model.addMotor(BigWorld.Servo(m_veh.matrix))
										m_veh._servo_added = True
									except: pass
									
							# Otaceni veze nezavisle
							if hasattr(m_veh, '_t_mat'):
								# Věž by měla vždy mířit na hráče (cíl), nezávisle na tom, kam se vyhýbá trup
								t_yaw = _raw_target_yaw - m_veh.yaw
								while t_yaw > math.pi: t_yaw -= 2*math.pi
								while t_yaw < -math.pi: t_yaw += 2*math.pi
								
								# Načíst limity otáčení věže/děla z dat vozidla (pro TD a arty)
								bot_gun_min_yaw = -math.pi
								bot_gun_max_yaw =  math.pi
								try:
									if _td:
										yl = None
										if hasattr(_td, 'gun') and isinstance(_td.gun, dict):
											yl = _td.gun.get('turretYawLimits', None)
										if yl is None and hasattr(_td, 'turret') and isinstance(_td.turret, dict):
											yl = _td.turret.get('yawLimits', None)
										if yl is not None:
											bot_gun_min_yaw = float(yl[0])
											bot_gun_max_yaw = float(yl[1])
											# Konverze stupňů -> radiány (hodnoty > 10 jsou ve stupních)
											if abs(bot_gun_min_yaw) > 10.0 or abs(bot_gun_max_yaw) > 10.0:
												bot_gun_min_yaw = math.radians(bot_gun_min_yaw)
												bot_gun_max_yaw = math.radians(bot_gun_max_yaw)
								except: pass
								
								has_limited_traverse = not (bot_gun_min_yaw <= -math.pi + 0.1 and bot_gun_max_yaw >= math.pi - 0.1)
								
								# TD nesmí přebíjet řízení trupu kvůli míření, pokud se právě vyhýbá překážce!
								is_avoiding_obstacle = getattr(m_veh, '_feeler_timer', 0) > 0 or (_feeler_steer_yaw is not None if '_feeler_steer_yaw' in locals() else False)
								
								if has_limited_traverse and not is_avoiding_obstacle:
									# TD/Arty: pokud je cíl mimo limity, bot musí otočit celý trup
									if t_yaw < bot_gun_min_yaw - 0.05:
										# Cíl vlevo od limitu – otočit trup doleva
										m_veh._veh_turn_velocity = -bot_chassisRotSpd
									elif t_yaw > bot_gun_max_yaw + 0.05:
										# Cíl vpravo od limitu – otočit trup doprava
										m_veh._veh_turn_velocity = bot_chassisRotSpd
									
								# Omezit věž na limity vždy
								if has_limited_traverse:
									t_yaw = max(bot_gun_min_yaw, min(bot_gun_max_yaw, t_yaw))
								
								if getattr(m_veh, '_turret_yaw', None) is None: m_veh._turret_yaw = 0.0
								t_diff = t_yaw - m_veh._turret_yaw
								rot_speed = 0.5
								try:
									if _td: rot_speed = _td.turret['rotationSpeed']
								except: pass
								rot_step = rot_speed * dt
								
								if t_diff > rot_step: m_veh._turret_yaw += rot_step
								elif t_diff < -rot_step: m_veh._turret_yaw -= rot_step
								else: m_veh._turret_yaw = t_yaw
								
								m_veh._t_mat.setRotateYPR((m_veh._turret_yaw, 0, 0))
									
							# Strelba bota na hrace
							if getattr(getattr(player, 'arena', None), 'period', 3) < 3:
								continue # no shooting before the countdown hits 0
							if getattr(m_veh, '_ai_shoot_timer', None) is None:
								m_veh._ai_shoot_timer = 0
								m_veh._ai_clip_size = 1
								m_veh._ai_clip = 1
								m_veh._ai_reload_intra = 0.0
								m_veh._ai_reload_full = 3.0
								try:
									_g = getattr(_td, 'gun', {}) if _td else {}
									if isinstance(_g, dict):
										if 'reloadTime' in _g: m_veh._ai_reload_full = float(_g['reloadTime'])
										if 'clip' in _g and len(_g['clip']) == 2:
											m_veh._ai_clip_size = int(_g['clip'][0])
											m_veh._ai_reload_intra = float(_g['clip'][1])
											m_veh._ai_clip = m_veh._ai_clip_size
								except: pass
								
							m_veh._ai_shoot_timer += dt
							
							# Zjistit absolutní úhel, kam míří dělo
							abs_gun_yaw = m_veh.yaw + getattr(m_veh, '_turret_yaw', 0.0)
							gun_diff = target_yaw - abs_gun_yaw
							while gun_diff > math.pi: gun_diff -= 2*math.pi
							while gun_diff < -math.pi: gun_diff += 2*math.pi
							
							bot_reload = m_veh._ai_reload_intra if (m_veh._ai_clip_size > 1 and m_veh._ai_clip > 0 and m_veh._ai_clip < m_veh._ai_clip_size) else m_veh._ai_reload_full
							
							# Vystřelí jen když míří na hráče (tolerance +- 0.15 rad = ~8.5 stupně)
							if m_veh._ai_shoot_timer > bot_reload and dist < 150.0 and abs(gun_diff) < 0.15:
								m_veh._ai_shoot_timer = 0
								if m_veh._ai_clip_size > 1:
									m_veh._ai_clip -= 1
									if m_veh._ai_clip <= 0:
										m_veh._ai_clip = m_veh._ai_clip_size
								try:
									if g_projectile_mover and _td:
										from items import vehicles
										_shots = _td.gun['shots'] if hasattr(_td, 'gun') and 'shots' in _td.gun else []
										if not _shots and isinstance(_td.gun, dict): _shots = _td.gun.get('shots', [])
										if _shots:
											_shot = _shots[0]
											_effectsDescr = vehicles.g_cache.shotEffects[_shot['shell']['effectsIndex']]
											_gravity = _shot['gravity']
											_speed = _shot['speed']
											
											target_y = target_pos[1] if target_pos else veh_pos[1]
											dir_v = Math.Vector3(dx, (target_y+1.0) - (m_veh.position.y+1.5), dz)
											dir_v.normalise()
											# Apply Bot Dispersion (approx 0.03 rad circle)
											sigma = 0.03 / 3.0
											dir_v.x += random.gauss(0, sigma)
											dir_v.y += random.gauss(0, sigma)
											dir_v.z += random.gauss(0, sigma)
											dir_v.normalise()
											
											_vel = dir_v.scale(_speed)
											
											start_p = Math.Vector3(m_veh.position.x, m_veh.position.y + 1.5, m_veh.position.z)
											_cam_pos = BigWorld.camera().position if BigWorld.camera() else start_p
											g_projectile_mover.add(random.randint(10000, 99999), _effectsDescr, _gravity, start_p, _vel, start_p, True, _cam_pos)
											# Barrel recoil animation on the firing bot's gun
											_trigger_gun_recoil(getattr(m_veh, '_gun_recoil', None))
											try:
												_b_td2 = getattr(m_veh, 'typeDescriptor', None)
												_trigger_shot_impulse(getattr(m_veh, '_swinging', None), Math.Vector3(-dir_v.x, -dir_v.y, -dir_v.z), _b_td2.gun['impulse'] if _b_td2 else 0.0)
											except Exception:
												pass
											_mflash_played = _play_muzzle_flash(m_veh, getattr(m_veh, '_gun_model', None), getattr(m_veh, 'typeDescriptor', None), is_player=False)
											if not _mflash_played:
												# The old inline lookup checked gun['effects']['shotSound'], but
												# gun['effects'] is a (stages, effects, _) tuple in this build, so
												# it always fell through to the 20-45mm sound for every bot.
												_fallback_gun_sound(getattr(m_veh, 'typeDescriptor', None), getattr(m_veh, '_chassis_model', None))
											
											player_mock = mock_vehicles.get(getattr(player, 'playerVehicleID', -1))
											if player_mock:
												try: player_mock.position = veh_pos
												except: pass
											
											end_p = start_p + dir_v.scale(500.0)
											
											# Kontrola kolize se světem (terén, budovy)
											world_hit_dist = 9999.0
											try:
												world_hit = BigWorld.wg_collideSegment(_offh_bspace(), start_p, end_p, 128)
												if world_hit is not None:
													hit_pt = world_hit[0]
													world_hit_dist = (hit_pt - start_p).length
											except: pass
											
											# Kontrola kolize se všemi vozidly (včetně vraků)
											veh_hit_dist = 9999.0
											hit_veh = None
											hit_col = None
											
											for oeid, omeh in mock_vehicles.iteritems():
												if oeid != eid: # Nezasáhnout sám sebe
													try: omeh.position = omeh.model.position
													except: pass
													col = omeh.collideSegment(start_p, end_p)
													if col is not None and col[0] < veh_hit_dist:
														veh_hit_dist = col[0]
														hit_veh = omeh
														hit_col = col
											
											# Pokud trefil nějaké vozidlo a bylo blíž než překážka
											if hit_veh and veh_hit_dist < world_hit_dist:
												# Trefil hráče?
												my_team = m_veh.publicInfo.get('team', 2) if getattr(m_veh, 'publicInfo', None) is not None else 2
												player_team = getattr(player, '_offhangar_team', 1)
												if hit_veh == player_mock and getattr(player_mock, 'health', 0) > 0 and my_team != player_team:
													_dist, _hitAngleCos, _armor = hit_col[:3]
													pierce = _shot.get('piercingPower', (100.0, 100.0))[0]
													pierce_rng = pierce * random.uniform(0.75, 1.25)
													angle_cos = max(0.087, abs(_hitAngleCos))
													eff_armor = _armor / angle_cos
													
													LOG_DEBUG('BOT HIT PLAYER! base=%.1f eff=%.1f pierce=%.1f' % (_armor, eff_armor, pierce_rng))
													
													auto_bounce = False
													if angle_cos < 0.342 and 'HE' not in _shot['shell']['name']:
														if _shot['shell'].get('caliber', 100) <= _armor * 3:
															auto_bounce = True

													# Visible impact effect on the player's tank (sparks/bounce/ricochet)
													try:
														_hit_res = 0 if auto_bounce else (2 if (pierce_rng >= eff_armor or 'HE' in _shot['shell']['name']) else 1)
														_wpos = start_p + dir_v.scale(hit_col[0])
														_play_vehicle_hit_effect(_shot['shell'], _wpos, dir_v, _hit_res, is_player_target=True)
														# Persistent shell-hole decal on the player's tank
														_p_td = loaded_models.get('td')
														_cn = _comp_name_from_hits(_p_td, hit_col[3] if len(hit_col) > 3 else [])
														_add_impact_decal(_target_sticker_map(player_mock), _cn, _wpos, dir_v, _hit_res)
													except Exception:
														pass

													dmg = 0
													# DIRECTION AND FLASH FOR ALL HITS
													try:
														px = player_mock.position
														import math
														import BigWorld
														
														# Left/Right is now CORRECT, but Front/Back is inverted.
														# Keep X inverted, and INVERT Z as well.
														dx = -(m_veh.position[0] - px[0])
														dz = -(m_veh.position[2] - px[2])
														hitDirYaw = math.atan2(dx, dz)
														
														if hasattr(player, 'inputHandler') and player.inputHandler:
															_aim = getattr(player.inputHandler, 'aim', None)
															if _aim and hasattr(_aim, 'showHit'):
																isDamage = not auto_bounce and (pierce_rng >= eff_armor or 'HE' in _shot['shell']['name'])
																_aim.showHit(hitDirYaw, isDamage)
														
														if isDamage:
															fba = Math.Vector4Animation()
															fba.keyframes = [(0.0, Math.Vector4(1.0, 0.0, 0.0, 0.7)), (0.3, Math.Vector4(1.0, 0.0, 0.0, 0.7)), (1.5, Math.Vector4(1.0, 0.0, 0.0, 0.0))]
															fba.duration = 1.5
															BigWorld.flashBangAnimation(fba)
															def remove_fba(f=fba):
																try: BigWorld.removeFlashBangAnimation(f)
																except: pass
															BigWorld.callback(1.4, remove_fba)
													except Exception as e:
														LOG_DEBUG('HitDir calc err:', e)
														
													if auto_bounce or (pierce_rng < eff_armor and 'HE' not in _shot['shell']['name']):
														LOG_DEBUG('BOT RICOCHET!')
														try:
															_fm = BigWorld.player().newFakeModel()
															BigWorld.addModel(_fm)
															_fm.position = BigWorld.camera().position
															snd = _fm.getSound('/hits/hits/tank_hit_armor_ricochet')
															if snd: snd.play()
															def _rem_fm(f=_fm):
																try: BigWorld.delModel(f)
																except: pass
															BigWorld.callback(3.0, _rem_fm)
														except Exception as ex:
															LOG_DEBUG('Ricochet FM err:', ex)
														try:
															if hasattr(player.inputHandler, 'ctrl') and player.inputHandler.ctrl:
																cam = getattr(player.inputHandler.ctrl, 'camera', None)
																_dir = Math.Vector3(dx, 0, dz)
																_dir.normalise()
																if cam and hasattr(cam, 'applyImpulse'):
																	cam.applyImpulse(_dir, 0.5)
																elif cam and hasattr(cam, 'impulseOscillator') and cam.impulseOscillator:
																	cam.impulseOscillator.applyImpulse(_dir * 0.5)
														except: pass
													else:
														_dmg_base = _shot['shell']['damage'][0]
														dmg = _dmg_base * random.uniform(0.75, 1.25)
														try:
															dmg = _apply_module_damage(player_mock, hit_col[3], m_veh.position, player_mock.position, dmg, _shot['shell'], m_veh.id)
														except Exception as ex:
															import traceback
															LOG_DEBUG("PLAYER MODULE DAMAGE ERROR:", traceback.format_exc() if 'traceback' in globals() else str(ex))
														player_mock.health -= int(dmg)
														try:
															_fm = BigWorld.player().newFakeModel()
															BigWorld.addModel(_fm)
															_fm.position = BigWorld.camera().position
															snd = _fm.getSound('/hits/hits/tank_hit_armor_crit')
															if snd: snd.play()
															def _rem_fm(f=_fm):
																try: BigWorld.delModel(f)
																except: pass
															BigWorld.callback(3.0, _rem_fm)
														except Exception as ex:
															LOG_DEBUG('Pierce FM err:', ex)
														try:
															if hasattr(player.inputHandler, 'ctrl') and player.inputHandler.ctrl:
																cam = getattr(player.inputHandler.ctrl, 'camera', None)
																_dir = Math.Vector3(dx, 0, dz)
																_dir.normalise()
																if cam and hasattr(cam, 'applyImpulse'):
																	cam.applyImpulse(_dir, 1.0)
																elif cam and hasattr(cam, 'impulseOscillator') and cam.impulseOscillator:
																	cam.impulseOscillator.applyImpulse(_dir * 1.0)
														except: pass
														if player_mock.health <= 0:
															player_mock.health = 0
														# Update player vehicle HP physically
														if hasattr(player, 'vehicle') and player.vehicle:
															player.vehicle.health = player_mock.health
														# Update GUI
														try:
															import gui.WindowsManager
															bw = gui.WindowsManager.g_windowsManager.battleWindow
															if hasattr(bw, 'damagePanel'):
																bw.damagePanel.updateHealth(player_mock.health)
															if hasattr(bw, 'vMarkersManager'):
																pass # bw.vMarkersManager.updateVehicleHealth(player.playerVehicleID, player_mock.health, 1, 0)
														except: pass
														if player_mock.health <= 0:
															player_mock.health = 0
														
														# Update player vehicle HP physically
														if hasattr(player, 'vehicle') and player.vehicle:
															player.vehicle.health = player_mock.health
															
														# Update GUI
														try:
															import gui.WindowsManager
															bw = gui.WindowsManager.g_windowsManager.battleWindow
															if hasattr(bw, 'damagePanel'):
																bw.damagePanel.updateHealth(player_mock.health)
															if hasattr(bw, 'vMarkersManager'):
																pass # bw.vMarkersManager.updateVehicleHealth(player.playerVehicleID, player_mock.health, 1, 0)
														except: pass
												else:
													my_team = m_veh.publicInfo.get('team', 2) if getattr(m_veh, 'publicInfo', None) is not None else 2
													target_team = hit_veh.publicInfo.get('team', 2) if getattr(hit_veh, 'publicInfo', None) is not None else (getattr(player, '_offhangar_team', 1) if getattr(player, 'playerVehicleID', -1) == hit_veh.id else 2)
													if getattr(hit_veh, 'health', 0) > 0 and my_team != target_team:
														# ARMOR PENETRATION LOGIC FOR BOT vs BOT
														_dmg_base = _shot['shell']['damage'][0]
														pierce_rng = _shot.get('piercingPower', (100.0, 100.0))[0] * random.uniform(0.75, 1.25)
														
														_dist, _hitAngleCos, _armor = hit_col[:3]
														angle_cos = max(0.087, abs(_hitAngleCos))
														eff_armor = _armor / angle_cos
														
														auto_bounce = False
														if angle_cos < 0.342 and 'HE' not in _shot['shell']['name']:
															if _shot['shell'].get('caliber', 100) <= _armor * 3:
																auto_bounce = True
														
														is_damage = not auto_bounce and (pierce_rng >= eff_armor or 'HE' in _shot['shell']['name'])

														# Visible impact effect + shell-hole decal on the hit bot
														try:
															_hit_res = 0 if auto_bounce else (2 if is_damage else 1)
															_wpos = start_p + dir_v.scale(hit_col[0])
															_play_vehicle_hit_effect(_shot['shell'], _wpos, dir_v, _hit_res, target_mock=hit_veh)
															_cn = _comp_name_from_hits(getattr(hit_veh, 'typeDescriptor', None), hit_col[3] if len(hit_col) > 3 else [])
															_add_impact_decal(_target_sticker_map(hit_veh), _cn, _wpos, dir_v, _hit_res)
														except Exception:
															pass

														if is_damage:
															LOG_DEBUG('BOT HIT ENEMY BOT: PENETRATION!')
															_dmg = int(_dmg_base * random.uniform(0.75, 1.25))
															try:
																_dmg = int(_apply_module_damage(hit_veh, hit_col[3], m_veh.position, hit_veh.position, _dmg, _shot['shell'], m_veh.id))
															except Exception as ex:
																import traceback
																LOG_DEBUG("BOT MODULE DAMAGE ERROR:", traceback.format_exc() if 'traceback' in globals() else str(ex))
															hit_veh.health -= _dmg
															hit_veh.damage_from_bots = getattr(hit_veh, 'damage_from_bots', 0) + _dmg
															hit_veh.last_killer_id = m_veh.id
															try:
																player.arena.onVehicleStatisticsUpdate(hit_veh.id)
																from gui import WindowsManager
																bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
																if bw and hasattr(bw, 'vMarkersManager'):
																	marker = getattr(hit_veh, 'marker', None)
																	if marker is not None:
																		bw.vMarkersManager.onVehicleHealthChanged(marker, hit_veh.health, m_veh.id, 0)
																		try: bw.vMarkersManager.showVehicleDamageInfo(marker, _dmg, 0, 0, 0)
																		except: pass
																	try: bw.minimap.notifyVehicleStop(hit_veh.id) if hit_veh.health <= 0 else None
																	except: pass
															except: pass
														else:
															LOG_DEBUG('BOT HIT ENEMY BOT: RICOCHET/NON-PEN!')
														if hit_veh.health <= 0:
															hit_veh.isAlive = False
															try:
																from gui import WindowsManager
																bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
																if bw and hasattr(bw, '_Battle__arena'):
																	bw._Battle__arena.vehicles[hit_veh.id]['isAlive'] = False
																	bw._Battle__updatePlayers()
															except: pass
															LOG_DEBUG('BOT KILLED ENEMY BOT!')
															try:
																try: hit_veh.appearance.changeVisibility('', False, False)
																except: pass
																try:
																	if getattr(hit_veh, '_wreck_done', False):
																		raise StopIteration  # wreck already handled by another kill path
																	hit_veh._wreck_done = True
																	_dtd = hit_veh.typeDescriptor
																	_d_ch = BigWorld.Model(_dtd.chassis['models']['destroyed'])
																	_d_hu = BigWorld.Model(_dtd.hull['models']['destroyed'])
																	_d_tu = BigWorld.Model(_dtd.turret['models']['destroyed'])
																	_d_gu = BigWorld.Model(_dtd.gun['models']['destroyed'])
																	_old_ch = hit_veh._chassis_model
																	_old_pos = _old_ch.position
																	_old_yaw = _old_ch.yaw
																	_old_ch_ref = _old_ch
																	def _swap_destroyed_model_bot(_d_ch=_d_ch, _d_hu=_d_hu, _d_tu=_d_tu, _d_gu=_d_gu, _old_ch_ref=_old_ch_ref, _old_pos=_old_pos, _old_yaw=_old_yaw, m_veh=hit_veh):
																		if not getattr(_d_ch, 'loaded', True) or not getattr(_d_hu, 'loaded', True) or not getattr(_d_tu, 'loaded', True) or not getattr(_d_gu, 'loaded', True):
																			BigWorld.callback(0.1, _swap_destroyed_model_bot)
																			return
																		try: _old_ch_ref.visible = False
																		except: pass
																		try: _old_ch_ref.visibleAttachments = False
																		except: pass
																		try:
																			if getattr(m_veh, 'bw_entity', None) is not None:
																				m_veh.bw_entity.model = None  # chassis is entity-owned: delModel alone fails
																		except: pass
																		try: BigWorld.delModel(_old_ch_ref)
																		except: pass
																		# Wreck must rest on the ground (mid-air kill would leave a floating
																		# wreck). _wpos: NEVER rebind _old_pos - in the player-kill path this
																		# code sits in a nested function where _old_pos is only a closure var;
																		# assigning it made it local -> UnboundLocalError -> vanishing wrecks.
																		_wpos = _old_pos
																		try:
																			import BigWorld as _bwx, Math as _mx
																			_gw = _bwx.wg_collideSegment(_offh_bspace(), _mx.Vector3(_wpos.x, _wpos.y + 2.0, _wpos.z), _mx.Vector3(_wpos.x, _wpos.y - 500.0, _wpos.z), 128)
																			if _gw is not None and _wpos.y > _gw[0].y + 0.5:
																				_wpos = _mx.Vector3(_wpos.x, _gw[0].y, _wpos.z)
																		except Exception:
																			pass
																		_d_ch.position = _wpos
																		_d_ch.yaw = _old_yaw
																		_h_mat = Math.Matrix(); _h_mat.setIdentity()
																		_t_mat = Math.Matrix(); _t_mat.setIdentity()
																		_g_mat = Math.Matrix(); _g_mat.setIdentity()
																		try: _d_ch.node('V').attach(_d_hu)
																		except: pass
																		try: 
																			m_veh._d_t_node = _d_hu.node('HP_turretJoint', _t_mat)
																			m_veh._d_t_node.attach(_d_tu)
																		except: pass
																		try: 
																			m_veh._d_g_node = _d_tu.node('HP_gunJoint', _g_mat)
																			m_veh._d_g_node.attach(_d_gu)
																		except: pass
																		try: _add_model(_d_ch)
																		except: pass
																	BigWorld.callback(0.1, _swap_destroyed_model_bot)
																except Exception as e:
																	LOG_DEBUG('Swap bot destroyed model error:', e)
																
																if hasattr(player.arena, 'statistics'):
																	if eid not in player.arena.statistics: player.arena.statistics[eid] = {'frags': 0}
																	_atk_team = getattr(m_veh, '_bot_team', m_veh.publicInfo.get('team', 2) if getattr(m_veh, 'publicInfo', None) is not None else 2)
																	_vic_team = getattr(hit_veh, '_bot_team', hit_veh.publicInfo.get('team', 2) if getattr(hit_veh, 'publicInfo', None) is not None else 2)
																	_frag_diff_bot = -1 if _atk_team == _vic_team else 1
																	player.arena.vehicles[eid]['frags'] = player.arena.vehicles[eid].get('frags', 0) + _frag_diff_bot
																	player.arena.statistics[eid]['frags'] = player.arena.statistics[eid].get('frags', 0) + _frag_diff_bot
																player.arena.onVehicleKilled(hit_veh.id, eid, 0)
																try:
																	if hasattr(player, 'onVehicleKilled'): player.onVehicleKilled(hit_veh.id, eid, 0)
																except: pass
																for v_id in player.arena.vehicles:
																	if v_id not in player.arena.statistics: player.arena.statistics[v_id] = {'frags': 0}
																player.arena.onVehicleStatisticsUpdate(eid)
																if hasattr(bw, '_Battle__updatePlayers'):
																	try: bw._Battle__updatePlayers()
																	except: pass
																if hasattr(bw, '_Battle__fragCorrelation'):
																	p_team = getattr(player, '_offhangar_team', 1)
																	allied = sum(v.get('frags', 0) for i,v in player.arena.vehicles.items() if i in player.arena.statistics and v.get('team') == p_team)
																	enemy = sum(v.get('frags', 0) for i,v in player.arena.vehicles.items() if i in player.arena.statistics and v.get('team') != p_team)
																	try: bw._Battle__fragCorrelation.updateFrags(allied, enemy)
																	except: pass
																if hasattr(bw, '_Battle__pMsgsPanel'):
																	try: bw._Battle__pMsgsPanel.showMessage('PlayerKilled', {'killer': (m_veh.publicInfo.get('name', 'Bot') if getattr(m_veh, 'publicInfo', None) else 'Bot'), 'victim': (hit_veh.publicInfo.get('name', 'Bot') if getattr(hit_veh, 'publicInfo', None) else 'Bot')})
																	except: pass
															except: pass
													else:
														LOG_DEBUG('BOT MISSED PLAYER - Hit another vehicle (corpse/ally) first at dist %.1f' % veh_hit_dist)
											elif world_hit_dist < 9999.0:
												LOG_DEBUG('BOT MISSED PLAYER - Hit obstacle (terrain/building) first at dist %.1f' % world_hit_dist)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
						except Exception as e:
							import traceback
							LOG_DEBUG('Bot AI Exception:', traceback.format_exc())
							
				# PLAYER DEATH CHECK
				try:
					player_mock = mock_vehicles.get(getattr(player, 'playerVehicleID', -1))
					if player_mock and player_mock.health <= 0 and getattr(player, '_is_dead', False) is not True:
						player._is_dead = True
						LOG_DEBUG('Player is dead. Spawning destroyed model and ending battle.')
						try:
							killer_id = getattr(player_mock, 'last_killer_id', -1)
							p_id = player.playerVehicleID
							if killer_id != -1 and killer_id in player.arena.vehicles and hasattr(player.arena, 'onVehicleKilled'):
								player.arena.vehicles[killer_id]['frags'] = player.arena.vehicles[killer_id].get('frags', 0) + 1
								if hasattr(player.arena, 'statistics'):
									if killer_id not in player.arena.statistics: player.arena.statistics[killer_id] = {'frags': 0}
									player.arena.statistics[killer_id]['frags'] = player.arena.statistics[killer_id].get('frags', 0) + 1
								player.arena.onVehicleKilled(p_id, killer_id, 0)
								player.arena.onVehicleStatisticsUpdate(killer_id)
								
								from gui import WindowsManager
								bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
								if bw and hasattr(bw, '_Battle__fragCorrelation'):
									p_team = getattr(player, 'team', 1)
									allied = sum(v.get('frags', 0) for v in player.arena.vehicles.values() if v.get('team') == p_team)
									enemy = sum(v.get('frags', 0) for v in player.arena.vehicles.values() if v.get('team') != p_team)
									bw._Battle__fragCorrelation.updateFrags(allied, enemy)
									try:
										if hasattr(bw, '_Battle__pMsgsPanel'):
											bw._Battle__pMsgsPanel.showMessage('PlayerKilled', {'killer': player.arena.vehicles[killer_id].get('name', 'Bot'), 'victim': player.arena.vehicles[p_id].get('name', 'Player')})
										if hasattr(bw, '_Battle__setPlayerInfo'):
											try:
												pass
											except Exception as e:
												import inspect
												LOG_DEBUG('setPlayerInfo error:', str(e), inspect.getargspec(bw._Battle__setPlayerInfo))
												try:
													import sys
													LOG_DEBUG('battle attributes again', dir(bw))
												except: pass
									except: pass
						except Exception as _e:
							LOG_DEBUG('Frag update error:', _e)
						
						# Swap model - hide live models, show destroyed ones
						try:
							_dtd = getattr(player_mock, 'typeDescriptor', None) or loaded_models.get('td')
							_d_ch = BigWorld.Model(_dtd.chassis['models']['destroyed'])
							_d_hu = BigWorld.Model(_dtd.hull['models']['destroyed'])
							_d_tu = BigWorld.Model(_dtd.turret['models']['destroyed'])
							_d_gu = BigWorld.Model(_dtd.gun['models']['destroyed'])
							
							def _swap_player_destroyed(_d_ch=_d_ch, _d_hu=_d_hu, _d_tu=_d_tu, _d_gu=_d_gu):
								try:
									# Force load
									_add_model(_d_ch)
									_add_model(_d_hu)
									_add_model(_d_tu)
									_add_model(_d_gu)
									
									def _attach_when_ready():
										if not getattr(_d_ch, 'loaded', True) or not getattr(_d_hu, 'loaded', True) or not getattr(_d_tu, 'loaded', True) or not getattr(_d_gu, 'loaded', True):
											BigWorld.callback(0.1, _attach_when_ready)
											return
										try: BigWorld.delModel(_d_hu)
										except: pass
										try: BigWorld.delModel(_d_tu)
										except: pass
										try: BigWorld.delModel(_d_gu)
										except: pass
										
										_live_chassis = loaded_models.get('chassis') or loaded_models.get('hull')
										if _live_chassis is not None:
											try:
												for _mot in list(_live_chassis.motors):
													_live_chassis.delMotor(_mot)
											except: pass
											try: _live_chassis.visible = False
											except: pass
											try: BigWorld.delModel(_live_chassis)
											except: pass
										
										try: _d_ch.node('V').attach(_d_hu)
										except: pass
										try: _d_hu.node('HP_turretJoint').attach(_d_tu)
										except: pass
										try: _d_tu.node('HP_gunJoint').attach(_d_gu)
										except: pass
										
										_d_ch.position = Math.Vector3(mock_veh.position)
										try: _d_ch.addMotor(BigWorld.Servo(chassis_mp))
										except: pass
										try:
											mock_veh._collision_obstacle = BigWorld.PyModelObstacle(
												_ptd.hull['models']['destroyed'],
												_ptd.turret['models']['destroyed'],
												chassis_mp,
												False
											)
										except: pass
										LOG_DEBUG('Player destroyed model placed OK')
									_attach_when_ready()
								except Exception as _e:
									import traceback
									LOG_DEBUG('Player model swap failed:', traceback.format_exc())
							
							BigWorld.callback(0.1, _swap_player_destroyed)
						except Exception as _e: LOG_DEBUG('Player death model err:', str(_e))
						
						# Exit battle in 5 seconds - use game.fini() which is the proper hook
						def _exit_battle():
							try:
								if _exit_done[0]:
									LOG_DEBUG('Player death exit skipped: another exit path already ran')
									return
								_exit_done[0] = True
								LOG_DEBUG('Player death: triggering exit to hangar')
								_battle_finished[0] = True
								try:
									import SoundGroups as _SG
									if getattr(_SG, 'g_instance', None) is not None:
										_SG.g_instance.enableArenaSounds(False)
										_SG.g_instance.enableLobbySounds(True)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
								
								# Safely stop all control_modes ticks before they can crash
								try:
									if not hasattr(player, 'soundNotifications'):
										try:
											from gui.Scaleform import IngameSoundNotifications
											player.soundNotifications = IngameSoundNotifications.IngameSoundNotifications()
											player.soundNotifications.start()
										except Exception as e:
											try:
												from gui import IngameSoundNotifications
												player.soundNotifications = IngameSoundNotifications.IngameSoundNotifications()
												player.soundNotifications.start()
											except Exception as e: pass
								except: pass
								
								try:
									_aih = getattr(player, 'inputHandler', None)
									if _aih is not None:
										try: _aih._AvatarInputHandler__isStarted = False
										except: pass
										for _cm in getattr(_aih, '_AvatarInputHandler__ctrls', {}).values():
											try: _cm.destroy()
											except: pass
										try:
											import game
											if hasattr(_aih, '_AvatarInputHandler__onRecreateDevice'):
												game.g_guiResetters.remove(_aih._AvatarInputHandler__onRecreateDevice)
										except: pass
										try: player.inputHandler = None
										except: pass
								except Exception as e:
									import traceback
									LOG_DEBUG('Failed to stop AIH:', traceback.format_exc())
								
								import gui.mods.offhangar._constants as _c
								from gui import WindowsManager
								
								try:
									if hasattr(WindowsManager.g_windowsManager, 'destroyBattle'):
										WindowsManager.g_windowsManager.destroyBattle()
									else:
										WindowsManager.g_windowsManager.hideAll()
								except Exception:
									pass
									
								try:
									global g_offline_models
									# Clear FIRST: delModel's pending error raises at loop
									# exhaustion; a post-loop clear was being skipped, so the
									# player's WRECK models leaked into the next battle (the
									# 'thrown back into the same round with my dead tank' bug).
									_gm_list = list(g_offline_models)
									g_offline_models = []
									for m in _gm_list:
										_offh_del_model(m)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
								
								# Free everything the battle allocated BEFORE camera/draw go down:
								# chunk unloading after delSpaceGeometryMapping only completes
								# while the engine still draws (memlog: the sweep-first 'quit'
								# path returned ~700 MB, this post-draw-off path returned none).
								try:
									_offh_battle_sweep('exit')
								except Exception as e:
									LOG_DEBUG('Sweep err:', str(e))
								
								try:
									global g_projectile_mover
									if g_projectile_mover is not None:
										g_projectile_mover.destroy()
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
								
								# Free everything the battle allocated BEFORE camera/draw go down:
								# chunk unloading after delSpaceGeometryMapping only completes
								# while the engine still draws (memlog: the sweep-first 'quit'
								# path returned ~700 MB, this post-draw-off path returned none).
								try:
									_offh_battle_sweep('exit')
								except Exception as e:
									LOG_DEBUG('Sweep err:', str(e))
								
								try:
									BigWorld.camera(None)
									BigWorld.worldDrawEnabled(False)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
								
								try:
									import gui.ClientHangarSpace
									LOG_DEBUG('ClientHangarSpace module dir:', dir(gui.ClientHangarSpace))
									LOG_DEBUG('ClientHangarSpace class dir:', dir(gui.ClientHangarSpace.ClientHangarSpace))
								except Exception as e:
									LOG_DEBUG('ClientHangarSpace error:', e)
								
								try:
									BigWorld.worldDrawEnabled(True)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
									
								try:
									from gui import WindowsManager
									
									if hasattr(WindowsManager.g_windowsManager, 'showLobby'):
										WindowsManager.g_windowsManager.showLobby()
										LOG_DEBUG('Triggered showLobby() for full UI and camera reload!')
										
									from gui.Scaleform.utils.HangarSpace import g_hangarSpace
									if g_hangarSpace is not None:
										try:
											g_hangarSpace.destroy()
										except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
										# WG 'no man's land' purge: hangar destroyed, nothing active, before re-init.
										_offh_safe_purge()
										g_hangarSpace.init(True)
										g_hangarSpace.refreshVehicle()
										LOG_DEBUG('Restored HangarSpace via global instance!')
									else:
										LOG_DEBUG('Global g_hangarSpace is None!')
										
								except Exception as e:
									import traceback
									LOG_DEBUG('HangarSpace restore error:', traceback.format_exc())

								# The battle-exit resync can leave a stale 'download/...'
								# entry in the global Waiting overlay (its completion
								# callback is lost in the lobby transition). The overlay
								# then resurfaces over the next opened view - e.g. the
								# Research screen - as an infinite spinner, although the
								# view underneath loaded fine. Flush once things settle.
								def _flush_stale_waiting():
									try:
										from gui.Scaleform.Waiting import Waiting
										Waiting.close()
										LOG_DEBUG('OfflineBattle: flushed stale Waiting overlay')
									except Exception:
										pass
								try:
									BigWorld.callback(3.0, _flush_stale_waiting)
								except Exception:
									pass
								
								try:
									BigWorld.worldDrawEnabled(True)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
									
								# Set the allow flag and trigger native exit
								for _e in BigWorld.entities.values():
									if _e.__class__.__name__ in ('PlayerAccount', 'Account'):
										_e._offline_allow_become_non_player = True
										if hasattr(_e, '_offhangar_orig_stats') and _e._offhangar_orig_stats is not None:
											_e.stats = _e._offhangar_orig_stats
										try: _e.showGUI(_c.OFFLINE_GUI_CTX)
										except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
							except Exception as e:
								import traceback
								LOG_DEBUG('Player exit battle err:', traceback.format_exc())
						
						BigWorld.callback(3.0, _exit_battle)
				except Exception as e: LOG_DEBUG('Player death check err:', str(e))

				BigWorld.callback(0.0, _aih_tick)
			except Exception as e:
				import traceback
				LOG_DEBUG('AIH_TICK CRASH:', traceback.format_exc())
				BigWorld.callback(0.0, _aih_tick)
		BigWorld.callback(0.0, _aih_tick)

		# Patch SniperCamera.__cameraUpdate to sync camera source position every frame
		try:
			import AvatarInputHandler.cameras as _cams
			_orig_cam_update = getattr(_cams.SniperCamera, '_orig_cam_update', None)
			if not _orig_cam_update:
				_orig_cam_update = _cams.SniperCamera._SniperCamera__cameraUpdate
				_cams.SniperCamera._orig_cam_update = _orig_cam_update
			_mv_ref = mock_veh
			_vm_ref = veh_matrix
			def _patched_cam_update(cam_self, *a, **kw):
				_orig_cam_update(cam_self, *a, **kw)
				try:
					cam = getattr(cam_self, '_SniperCamera__cam', None)
					if cam is not None and hasattr(cam, 'source'):
						if 'gun_node_matrix' in loaded_models:
							cam.source = loaded_models['gun_node_matrix']
						else:
							mp = Math.WGTranslationOnlyMP()
							mp.source = _vm_ref
							cam.source = mp
				except Exception:
					pass
			_cams.SniperCamera._SniperCamera__cameraUpdate = _patched_cam_update
			_cams.SniperCamera._offhangar_patched = True
			LOG_DEBUG('OfflineBattle.SniperCamera.__cameraUpdate patched')
		except Exception:
			LOG_CURRENT_EXCEPTION()

		# Patch control_modes and cameras ticks to stop gracefully after player is gone
		try:
			import AvatarInputHandler.control_modes as _ctrl
			import AvatarInputHandler.cameras as _cams2
			
			if hasattr(_ctrl.ArcadeControlMode, '_ArcadeControlMode__tick') and not hasattr(_ctrl.ArcadeControlMode, '_offhangar_patched'):
				# Patch ArcadeControlMode.__tick
				_orig_ctrl_tick = getattr(_ctrl.ArcadeControlMode, '_ArcadeControlMode__tick')
				def _safe_ctrl_tick(self_cm, *a, **kw):
					if BigWorld.player() is None:
						return  # Stop ticking after battle ends
					return _orig_ctrl_tick(self_cm, *a, **kw)
				_ctrl.ArcadeControlMode._ArcadeControlMode__tick = _safe_ctrl_tick
				_ctrl.ArcadeControlMode._offhangar_patched = True
				
			if hasattr(_cams2, 'ArcadeCamera') and hasattr(_cams2.ArcadeCamera, '_ArcadeCamera__cameraUpdate') and not hasattr(_cams2.ArcadeCamera, '_offhangar_patched'):
				# Patch ArcadeCamera.__cameraUpdate
				_orig_arc_cam = getattr(_cams2.ArcadeCamera, '_ArcadeCamera__cameraUpdate')
				def _safe_arc_cam(self_ac, *a, **kw):
					if BigWorld.player() is None:
						# The original reschedules itself as its FIRST statement, so a
						# plain early return here kills camera pivot updates permanently
						# after one transient None-player tick. Keep the chain alive.
						try:
							self_ac._ArcadeCamera__cameraUpdateCallbackId = BigWorld.callback(0.5, lambda: _safe_arc_cam(self_ac))
						except Exception:
							pass
						return
					return _orig_arc_cam(self_ac, *a, **kw)
				_cams2.ArcadeCamera._ArcadeCamera__cameraUpdate = _safe_arc_cam
				_cams2.ArcadeCamera._offhangar_patched = True
			
			LOG_DEBUG('OfflineBattle.control_modes/cameras ticks patched for safe exit')
		except Exception:
			LOG_CURRENT_EXCEPTION()

		_install_input_chain_debug()
		g_offline_aih = AvatarInputHandler.AvatarInputHandler()
		player.inputHandler = g_offline_aih
		try:
			g_offline_aih.start()
		except Exception as e:
			import traceback
			LOG_DEBUG('AvatarInputHandler.start ERROR:', traceback.format_exc())
		
		# After AIH.start(), forcibly redirect camera to our spawn position.
		# AIH may set cam.target to (0,0,0) from a defaulted entity matrix.
		# We override it directly using CursorCamera.
		def _force_camera_to_model():
			try:
				import BigWorld, Math
				cam = BigWorld.camera()
				if cam is not None and hasattr(cam, 'target'):
					# Set cam.target to a translation-only provider tracking veh_matrix.
					# This prevents the camera from turning when the tank hull turns.
					mp = Math.WGTranslationOnlyMP()
					mp.source = veh_matrix
					cam.target = mp
					LOG_DEBUG('OfflineBattle.force_camera: set target to', veh_pos[0], veh_pos[1], veh_pos[2])
				else:
					LOG_DEBUG('OfflineBattle.force_camera: cam=', cam, 'has target=', hasattr(cam, 'target') if cam else False)
			except Exception as e:
				import traceback
				LOG_DEBUG('OfflineBattle.force_camera ERROR:', traceback.format_exc())
		BigWorld.callback(0.1, _force_camera_to_model)
		BigWorld.callback(0.5, _force_camera_to_model)
		BigWorld.callback(1.0, _force_camera_to_model)


		from gui import WindowsManager
		from gui.Scaleform.Waiting import Waiting
		try:
			player = BigWorld.player()
			
			import gui.Scaleform.Battle
			import Avatar
			class _FakeAvatarMod(object):
				PlayerAvatar = type(player)
			
			if hasattr(gui.Scaleform.Battle, 'Avatar'):
				gui.Scaleform.Battle.orig_Avatar = gui.Scaleform.Battle.Avatar
			gui.Scaleform.Battle.Avatar = _FakeAvatarMod
			
			if hasattr(Avatar, 'PlayerAvatar'):
				Avatar.orig_PlayerAvatar = Avatar.PlayerAvatar
			Avatar.PlayerAvatar = type(player)
			
			if not hasattr(player, 'denunciationsLeft'):
				player.denunciationsLeft = 0
				
			if not hasattr(player, 'onSpaceLoaded'):
				class _DummyEvent(object):
					def __iadd__(self, *a, **k): return self
					def __isub__(self, *a, **k): return self
					def __call__(self, *a, **k): return True
					def isActive(self): return True
				player.onSpaceLoaded = _DummyEvent()
			
			if not hasattr(player, 'playerVehicleID'):
				player.playerVehicleID = 0
				
			import types
			if hasattr(player, 'getOwnVehicleShotDispersionAngle'):
				# Rebind EVERY battle: the old name-based guard kept the FIRST
				# battle's _gun_state closure forever, so later tanks fired with
				# battle 1's dispersion. Keep the true original on the player.
				_orig_get_disp = getattr(player, '_offh_orig_get_disp', None)
				if _orig_get_disp is None:
					_orig_get_disp = player.getOwnVehicleShotDispersionAngle
					player._offh_orig_get_disp = _orig_get_disp
				def _mock_getOwnVehicleShotDispersionAngle(self, turretRotationSpeed, withShot=0):
					orig = _orig_get_disp(turretRotationSpeed, withShot)
					return (_gun_state.get('dispersion', orig[0]), orig[1])
				player.getOwnVehicleShotDispersionAngle = types.MethodType(_mock_getOwnVehicleShotDispersionAngle, player)
			
			# VŽDY resetuj životní funkce při nové bitvě
			player.isVehicleAlive = True
			player._is_dead = False
			player._crosshair_init_done = False
			if hasattr(player, 'vehicle') and player.vehicle is not None:
				try: player.vehicle.typeDescriptor = td
				except Exception: pass
				player.vehicle.health = getattr(td, 'maxHealth', 400)
				player.vehicle.isAlive = True
				
			if not hasattr(player, 'name'):
				player.name = 'Player'
			if not hasattr(player, 'team'):
				player.team = 1
			
			

			


			def _apply_module_damage(target_mock, all_hits, start_pos, end_pos, dmg, _shell, attacker_id):
				import BigWorld, Math, random
				if getattr(target_mock, 'id', -1) == getattr(BigWorld.player(), 'playerVehicleID', -1):
					return dmg # Disable module damage for player
				if getattr(target_mock, 'devices_hp', None) is None:
					target_mock.devices_hp = {}
				
				_shell_dmg = dmg
				if _shell and 'deviceDamage' in _shell:
					_device_dmg = _shell['deviceDamage'][0] if type(_shell['deviceDamage']) is tuple else _shell['deviceDamage']
					_shell_dmg = random.uniform(_device_dmg * 0.75, _device_dmg * 1.25)
				
				is_player_attacker = (attacker_id == getattr(BigWorld.player(), 'playerVehicleID', -1))
				target_mock.last_sound = 'armor_pierced_by_player' if is_player_attacker else 'armor_pierced'
				
				has_internal = any(getattr(h[2], 'vehicleDamageFactor', 1.0) == 0.0 and getattr(getattr(h[2], 'extra', None), 'name', '') not in ('leftTrackHealth', 'rightTrackHealth', 'gunHealth') for h in all_hits if h[2])
				if not has_internal:
					w2v = Math.Matrix(target_mock.matrix)
					w2v.invert()
					veh_start = w2v.applyPoint(start_pos)
					veh_end = w2v.applyPoint(end_pos)
					vec = veh_end - veh_start
					vec_norm = Math.Vector3(vec)
					vec_norm.normalise()
					
					for h in list(all_hits):
						h_dist, h_angle, h_mat, h_comp = h
						if h_mat is not None and getattr(h_mat, 'vehicleDamageFactor', 1.0) > 0.0:
							v_pos = veh_start + vec_norm * (h_dist + 0.5)
							td = getattr(target_mock, 'typeDescriptor', getattr(BigWorld.player(), 'vehicleTypeDescriptor', None))
							ctype = 'hull' if h_comp is getattr(td, 'hull', None) else ('turret' if h_comp is getattr(td, 'turret', None) else '')
							f_name = None
							if ctype == 'hull':
								if v_pos.z < -0.5: f_name = 'engineHealth'
								else: f_name = 'ammoBayHealth'
							elif ctype == 'turret':
								f_name = 'ammoBayHealth'
							
							if f_name:
								f_extra = td.extrasDict.get(f_name) if td else None
								if f_extra:
									class FakeMat:
										vehicleDamageFactor = 0.0
										extra = f_extra
									all_hits.append((h_dist + 0.5, h_angle, FakeMat(), h_comp))
									break
				for h in all_hits:
					h_dist, h_angle, h_mat, h_comp = h
					if h_mat is not None and getattr(h_mat, 'vehicleDamageFactor', 1.0) == 0.0:
						_extra = getattr(h_mat, 'extra', None)
						if _extra is not None:
							_name = getattr(_extra, 'name', 'Unknown')
							if _name not in ('leftTrackHealth', 'rightTrackHealth', 'gunHealth'):
								saving_throw = 0.33
								if 'ammo' in _name.lower(): saving_throw = 0.15
								elif 'engine' in _name.lower(): saving_throw = 0.45
								elif 'fuel' in _name.lower(): saving_throw = 0.45
								elif 'track' in _name.lower(): saving_throw = 1.0

								if random.random() < saving_throw:
									max_hp = getattr(_extra, 'maxHealth', 100)
									current_hp = target_mock.devices_hp.get(_name, max_hp)
									current_hp -= _shell_dmg
									target_mock.devices_hp[_name] = current_hp
									
									target_mock.last_sound = 'armor_pierced_crit_by_player' if is_player_attacker else 'armor_pierced_crit'
									
									# Update Player HUD Damage Panel
									if not is_player_attacker and getattr(target_mock, 'id', getattr(BigWorld.player(), 'playerVehicleID', -1)) == getattr(BigWorld.player(), 'playerVehicleID', -1):
										try:
											player = BigWorld.player()
											dev_state = 'destroyed' if current_hp <= 0 else 'critical'
											ui_name = _name.replace('Health', '')
											if ui_name == 'leftTrack' or ui_name == 'rightTrack': ui_name = 'track'
											try: player.guiSessionProvider.invalidateVehicleState(2, player.playerVehicleID, ui_name, dev_state)
											except: pass
											
											import gui.WindowsManager
											bw = gui.WindowsManager.g_windowsManager.battleWindow
											if hasattr(bw, 'damagePanel'):
												import debug_utils
												debug_utils.LOG_DEBUG('DAMAGE_PANEL_DIR: ', dir(bw.damagePanel))
												bw.damagePanel.updateDeviceState(ui_name, dev_state)
										except Exception as e:
											import debug_utils
											debug_utils.LOG_DEBUG('UPDATE_DEVICE_ERR: ', e)

									if 'ammo' in _name.lower() and current_hp <= 0:
										dmg = target_mock.health + 10
										target_mock._is_killed = True
										target_mock._ammo_rack_death = True  # picks the 'explosion' death effect
										target_mock.last_sound = 'enemy_killed_by_player' if is_player_attacker else 'enemy_killed'
										if is_player_attacker:
											try:
												if hasattr(BigWorld.player(), 'soundNotifications') and BigWorld.player().soundNotifications is not None:
													BigWorld.player().soundNotifications.play('enemy_killed_by_player')
											except: pass
										try:
											BigWorld.player().arena.onVehicleKilled(target_mock.id, attacker_id, 1)
										except: pass
										break
									
									if ('engine' in _name.lower() or 'fuel' in _name.lower()) and current_hp <= 0:
										if not getattr(target_mock, 'is_on_fire', False):
											target_mock.is_on_fire = True
											import debug_utils
											debug_utils.LOG_DEBUG("FIRE IGNITED ON: ", getattr(target_mock, 'id', 'PLAYER'))
											if not is_player_attacker and getattr(target_mock, 'id', getattr(BigWorld.player(), 'playerVehicleID', -1)) == getattr(BigWorld.player(), 'playerVehicleID', -1):
												try:
													import gui.WindowsManager
													bw = gui.WindowsManager.g_windowsManager.battleWindow
													if hasattr(bw, 'damagePanel'):
														bw.damagePanel._DamagePanel__callFlash('onFireInVehicle', [True])
												except Exception as e:
													debug_utils.LOG_DEBUG("FIRE UI UPDATE ERR: ", e)
									
									if 'track' in _name.lower() and current_hp <= 0:
										if not getattr(target_mock, 'is_tracked', False):
											target_mock.is_tracked = True
				return dmg

			def _mock_shoot():
				import BigWorld, Math, math, random
				if getattr(BigWorld.player(), '_is_dead', False) is True: return
				# No shooting during the pre-battle countdown (like the original)
				try:
					if getattr(BigWorld.player().arena, 'period', 3) < 3: return
				except Exception:
					pass
				try:
					# --- RELOAD LOGIC ---
					if not _gun_state['initialized']: return
					if _gun_state['reloadTime'] > 0: return
					idx = _gun_state.get('shot_index', 0)
					ammo_key = 'ammo_%d' % idx
					if _gun_state.get(ammo_key, 1) <= 0: return
					
					_gun_state[ammo_key] -= 1
					_gun_state['clip'] -= 1
					import math
					jump = _gun_state['base_dispersion'] * _gun_state['after_shot']
					_gun_state['dispersion'] = math.sqrt(_gun_state['dispersion']**2 + jump**2)
					max_disp = _gun_state['base_dispersion'] * 15.0
					if _gun_state['dispersion'] > max_disp:
						_gun_state['dispersion'] = max_disp
					
					if _gun_state['clip'] > 0:
						_gun_state['reloadTime'] = _gun_state['clip_reload']
					else:
						_gun_state['reloadTime'] = _gun_state['reload']
						
					if hasattr(BigWorld.player(), 'gunRotator'):
						BigWorld.player().gunRotator.dispersionAngle = _gun_state['dispersion']
						
					player = BigWorld.player()
					player._offhangar_shots_fired = getattr(player, '_offhangar_shots_fired', 0) + 1
						
					# UPDATE RELOAD UI
					try:
						from gui import WindowsManager
						panel = WindowsManager.g_windowsManager.battleWindow.consumablesPanel
						if panel:
							shot_idx = _gun_state.get('shot_index', 0)
							panel.setShellQuantityInSlot(shot_idx, _gun_state['ammo_%d' % shot_idx], _gun_state['clip'])
							try: panel.setCoolDownTime(shot_idx, 0.0)
							except Exception as e: LOG_DEBUG('setCoolDownTime reset error:', str(e))
							try: panel.setCoolDownTime(shot_idx, _gun_state['reloadTime'])
							except Exception as e: LOG_DEBUG('setCoolDownTime error:', str(e))
						aim = getattr(g_offline_aih, 'aim', None)
						if aim:
							try: aim.setReloading(0.0, None)
							except: pass
							try: aim.setReloading(_gun_state['reloadTime'], None)
							except Exception as e: LOG_DEBUG('setReloading error:', str(e))
							shot_idx = _gun_state.get('shot_index', 0)
							aim.setAmmoStock(_gun_state['ammo_%d' % shot_idx], _gun_state['clip'], False)
					except Exception as e:
						LOG_DEBUG('Normal shoot UI error:', str(e))
					
					try:
						player._Avatar__shotWaitingTimerID = None
					except: pass
					
					# --- RAYCAST HIT DETECTION ---
					start_pos, dir_vec = player.gunRotator._VehicleGunRotator__getCurShotPosition()
					dir_vec.normalise()
					
					# Apply Player Dispersion based on actual aiming circle
					# (config.json "perfect_accuracy": true disables all scatter - testing aid)
					disp_angle = getattr(player.gunRotator, 'dispersionAngle', _gun_state.get('dispersion', 0.02))
					from _constants import CONFIG_OPTIONS as _CFG_ACC
					sigma = 0.0 if _CFG_ACC.get('perfect_accuracy', False) else disp_angle / 3.0
					dir_vec.x += random.gauss(0, sigma)
					dir_vec.y += random.gauss(0, sigma)
					dir_vec.z += random.gauss(0, sigma)
					dir_vec.normalise()
					
					# Pre-bind so the ground-impact detonation below can reference these
					# even when no tracer/shot resolved this frame (else NameError).
					_sid = None
					_effectsDescr = None
					_w_col = None
					# --- TRACER ---
					try:
						if g_projectile_mover:
							from items import vehicles
							_our_td = loaded_models.get('td')
							_our_shots = _our_td.gun.get('shots', []) if _our_td else []
							_si = _gun_state.get('shot_index', 0)
							_si = min(_si, len(_our_shots) - 1) if _our_shots else 0
							_shot = _our_shots[_si] if _our_shots else None
							
							if _shot:
								_effectsDescr = vehicles.g_cache.shotEffects[_shot['shell']['effectsIndex']]
								_gravity = _shot['gravity']
								_speed = _shot['speed']
								_vel = dir_vec.scale(_speed)
								import random
								_sid = random.randint(10000, 99999)
								_cam_pos = BigWorld.camera().position if BigWorld.camera() else start_pos
								LOG_DEBUG('Spawning tracer! shotID=%s start_pos=%s vel=%s speed=%s' % (_sid, start_pos, _vel, _speed))
								g_projectile_mover.add(_sid, _effectsDescr, _gravity, start_pos, _vel, start_pos, True, _cam_pos)
					except Exception as e:
						import traceback
						LOG_DEBUG('Tracer spawn error:', traceback.format_exc())
					
					hit_dist = 99999.0
					enemy_mock = None
					enemy_hit_info = None
					end_pos = start_pos + dir_vec.scale(5000.0)
					
					# World collision: shells stop at solid walls/terrain but break fences/trees
					world_dist = 99999.0
					try:
						_w_col = BigWorld.wg_collideSegment(_offh_bspace(), start_pos, end_pos, 128)
						if _w_col is not None:
							world_dist = (_w_col[0] - start_pos).length
							_destr_fn = loaded_models.get('_destr_fn')
							if _destr_fn is not None:
								_shot_yaw = math.atan2(dir_vec.x, dir_vec.z)
								_mi = None
								try:
									_mi = BigWorld.wg_getMatInfoNearPoint(_offh_bspace(), start_pos, _w_col[0] + dir_vec.scale(0.3), _w_col[0], lambda *a: False)
								except Exception:
									_mi = None
								if _mi is not None and _destr_fn(_offh_bspace(), _mi, _shot_yaw, 12.0):
									# Destructible broken by the shell: re-cast past the debris
									_w_col2 = BigWorld.wg_collideSegment(_offh_bspace(), _w_col[0] + dir_vec.scale(0.6), end_pos, 128)
									world_dist = ((_w_col2[0] - start_pos).length + 0.6) if _w_col2 is not None else 99999.0
					except Exception as _we:
						LOG_DEBUG('Shot world-collision error:', str(_we))
					
					for eid, m_veh in mock_vehicles.iteritems():
						if eid != player.playerVehicleID and getattr(m_veh, 'isAlive', False):
							# Sync stored position with model for future checks
							try: m_veh.position = m_veh.model.position
							except: pass
							col = m_veh.collideSegment(start_pos, end_pos)
							if col is not None and col[0] < hit_dist:
								hit_dist = col[0]
								enemy_mock = m_veh
								enemy_hit_info = col
					
					# A solid wall in front of the target blocks the shell
					if enemy_mock is not None and hit_dist > world_dist + 0.5:
						LOG_DEBUG('Shot blocked by world at %.1f m (tank was at %.1f m)' % (world_dist, hit_dist))
						enemy_mock = None
						enemy_hit_info = None
					
					# Ground/wall impact: offline nothing calls ProjectileMover.explode(),
					# so the tracer would fly to the map edge with no effect. Detonate it
					# at the terrain hit so shooting the ground/stone/water shows the stock
					# dust/splash burst + crater decal (deferred to shell arrival). terrain-
					# Effects are fire-and-forget (auto-expire) + the channel is destroyed
					# in the sweep -> no leak.
					if enemy_mock is None and g_projectile_mover and _sid is not None and _effectsDescr is not None and _w_col is not None and world_dist < 4900.0:
						try:
							_gmat = _terrain_hit_material(_offh_bspace(), _w_col[0], dir_vec)
							# Fall back to ground if this shell has no effect for the
							# detected surface (shotEffects always defines groundHit).
							if (_gmat + 'Hit') not in _effectsDescr:
								_gmat = 'ground'
							if (_gmat + 'Hit') in _effectsDescr:
								g_projectile_mover.explode(_sid, _effectsDescr, _gmat, _w_col[0], dir_vec)
						except Exception as _gee:
							LOG_DEBUG('Ground impact effect error:', str(_gee))
					if enemy_mock and enemy_hit_info:
						# Calculate real damage from gun.shots[i].shell descriptor
						try:
							_td = loaded_models.get('td')
							_gun = _td.gun
							_shots = _gun.get('shots', [])
							_sidx = _gun_state.get('shot_index', 0)
							_sidx = min(_sidx, len(_shots) - 1) if _shots else 0
							_shell = _shots[_sidx].get('shell') if _shots else None
							
							dmg = 0
							if _shell and 'damage' in _shell:
								_dmg_data = _shell['damage']
								if hasattr(_dmg_data, '__len__') and len(_dmg_data) >= 1: avg = float(_dmg_data[0])
								else: avg = float(_dmg_data)
								dmg = int(random.uniform(avg * 0.75, avg * 1.25))
								
								# ARMOR PENETRATION LOGIC (Real HitBox)
								pierce = _shots[_sidx].get('piercingPower', (100.0, 100.0))[0]
								pierce_rng = pierce * random.uniform(0.75, 1.25)
								
								_dist, _hitAngleCos, _armor = enemy_hit_info[:3]
								all_hits = enemy_hit_info[3] if len(enemy_hit_info) > 3 else []
								
								# Minimum angle cos to avoid infinity (85 degrees max)
								angle_cos = max(0.087, abs(_hitAngleCos))
								eff_armor = _armor / angle_cos
								
								LOG_DEBUG('REAL ARMOR: base=%.1f eff=%.1f pierce=%.1f angle_cos=%.2f' % (_armor, eff_armor, pierce_rng, angle_cos))
								
								auto_bounce = False
								# 70 degree auto-bounce rule (cos(70) ~ 0.342), except for HE
								if angle_cos < 0.342 and 'HE' not in _shell['name']:
									# Overmatch rule: if caliber > 3 * armor, no auto-bounce
									caliber = _shell.get('caliber', 100) # Default to 100mm if unknown
									if caliber <= _armor * 3:
										auto_bounce = True

								_hit_res = 2  # penetration by default
								if auto_bounce:
									dmg = 0
									_hit_res = 0  # ricochet
									LOG_DEBUG('REAL RICOCHET (Auto-Bounce >70 deg)!')
									import SoundGroups
									pass # removed playSound2D
								elif pierce_rng < eff_armor and 'HE' not in _shell['name']:
									dmg = 0
									_hit_res = 1  # non-penetration
									LOG_DEBUG('REAL RICOCHET / NON-PENETRATION!')
									import SoundGroups
									pass # removed playSound2D
								# Visible impact effect + shell-hole decal on the target -
								# the ProjectileMover only shows impacts on static geometry,
								# never on the mock tanks.
								try:
									_wpos = start_pos + dir_vec.scale(enemy_hit_info[0])
									_play_vehicle_hit_effect(_shell, _wpos, dir_vec, _hit_res, target_mock=enemy_mock)
									_cn = _comp_name_from_hits(getattr(enemy_mock, 'typeDescriptor', None), enemy_hit_info[3] if len(enemy_hit_info) > 3 else [])
									_add_impact_decal(_target_sticker_map(enemy_mock), _cn, _wpos, dir_vec, _hit_res)
								except Exception:
									pass
							else:
								dmg = random.randint(250, 450)
						except Exception as e:
							import traceback
							LOG_DEBUG('Damage calc error:', traceback.format_exc())
							dmg = random.randint(250, 450)
						
						if dmg > 0:
							try:
								dmg = _apply_module_damage(enemy_mock, all_hits, start_pos, end_pos, dmg, _shell, getattr(player, 'playerVehicleID', -1))
								
								try:
									snd_str = getattr(enemy_mock, 'last_sound', 'armor_pierced_by_player')
								except: pass
							except Exception as ex:
								import traceback
								LOG_DEBUG("MODULE DAMAGE ERROR:", traceback.format_exc())

							actual_dmg = min(dmg, max(0, enemy_mock.health))
							enemy_mock.health -= dmg
							enemy_mock.damage_from_player = getattr(enemy_mock, 'damage_from_player', 0) + actual_dmg
							enemy_mock.hits_from_player = getattr(enemy_mock, 'hits_from_player', 0) + 1
							LOG_DEBUG('HIT! Damage:', dmg, 'Enemy HP:', enemy_mock.health)
							
							try:
								sound_str = 'enemy_killed_by_player' if enemy_mock.health <= 0 else getattr(enemy_mock, 'last_sound', 'armor_pierced_by_player')
								if hasattr(player, 'soundNotifications') and player.soundNotifications is not None:
									player.soundNotifications.play(sound_str)
								else:
									if not hasattr(g_offline_aih, '_snd_notif'):
										try:
											from gui.IngameSoundNotifications import IngameSoundNotifications
											g_offline_aih._snd_notif = IngameSoundNotifications()
											g_offline_aih._snd_notif.start()
										except: pass
									if hasattr(g_offline_aih, '_snd_notif'):
										g_offline_aih._snd_notif.play(sound_str)
							except Exception as e:
								LOG_DEBUG('Hit sound error:', str(e))
						
						# Update vehicle marker health
						try:
							hp_percent = max(0, int((float(enemy_mock.health) / float(enemy_mock.maxHealth)) * 100.0))
							player.arena.onVehicleStatisticsUpdate(enemy_mock.id)
							from gui import WindowsManager
							bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
							if bw and hasattr(bw, 'vMarkersManager'):
								marker = getattr(enemy_mock, 'marker', None)
								if marker is not None:
									bw.vMarkersManager.onVehicleHealthChanged(marker, enemy_mock.health, 1, 0)
									try: bw.vMarkersManager.showVehicleDamageInfo(marker, dmg, 0, 0, 1)
									except: pass
									LOG_DEBUG('HP updated via marker, HP=%d' % enemy_mock.health)
								else:
									LOG_DEBUG('No marker on enemy_mock!')
							if bw and hasattr(bw, 'minimap'):
								try: bw.minimap.notifyVehicleStop(enemy_mock.id) if enemy_mock.health <= 0 else None
								except: pass
							try: player.showVehicleDamageInfo(enemy_mock.id, 0, 0, dmg)
							except: pass
						except Exception as e:
							LOG_DEBUG('Hit GUI error:', str(e))
						
						if enemy_mock.health <= 0:
							enemy_mock.isAlive = False
							try:
								from gui import WindowsManager
								bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
								if bw and hasattr(bw, '_Battle__arena'):
									bw._Battle__arena.vehicles[enemy_mock.id]['isAlive'] = False
									bw._Battle__updatePlayers()
							except: pass
							LOG_DEBUG('ENEMY DESTROYED!')
							try:
								p_id = getattr(player, 'playerVehicleID', -1)
								if p_id != -1 and p_id in player.arena.vehicles and hasattr(player.arena, 'onVehicleKilled'):
									_pteam = getattr(player, '_offhangar_team', 1)
									_vteam = getattr(enemy_mock, '_bot_team', enemy_mock.publicInfo.get('team', 2) if getattr(enemy_mock, 'publicInfo', None) is not None else 2)
									_frag_diff = -1 if _pteam == _vteam else 1
									player.arena.vehicles[p_id]['frags'] = player.arena.vehicles[p_id].get('frags', 0) + _frag_diff
									if _frag_diff == -1:
										player.arena.vehicles[p_id]['isTeamKiller'] = True
										player.isTeamKiller = True
										LOG_DEBUG('ARENA DIR: %s' % dir(player.arena))
										try: player.arena.onTeamKiller(p_id)
										except Exception as e: LOG_DEBUG('onTeamKiller error:', str(e))
										try:
											from gui import WindowsManager
											bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
											if bw and hasattr(bw, '_Battle__vehicles'):
												try:
													if hasattr(bw, '_Battle__arena'):
														bw._Battle__arena.vehicles[p_id]['isTeamKiller'] = True
														LOG_DEBUG('Updated bw._Battle__arena for p_id')
													bw._Battle__updatePlayers()
													if hasattr(bw, '_Battle__onTeamKiller'):
														bw._Battle__onTeamKiller(p_id)
												except Exception as e: LOG_DEBUG('Update __arena error:', str(e))
										except Exception as e: LOG_DEBUG('BW VEHS ERROR:', str(e))
										try: player.arena.onVehicleUpdated(p_id)
										except: pass
										try: player.arena.onVehicleAdded(p_id)
										except: pass
									if hasattr(player.arena, 'statistics'):
										if p_id not in player.arena.statistics: player.arena.statistics[p_id] = {'frags': 0}
										player.arena.statistics[p_id]['frags'] = player.arena.statistics[p_id].get('frags', 0) + _frag_diff
									player.arena.onVehicleKilled(enemy_mock.id, p_id, 0)
									for v_id in player.arena.vehicles:
										if v_id not in player.arena.statistics: player.arena.statistics[v_id] = {'frags': 0}
									player.arena.onVehicleStatisticsUpdate(p_id)
									if hasattr(bw, '_Battle__updatePlayers'):
										try: bw._Battle__updatePlayers()
										except Exception as e: LOG_DEBUG('updatePlayers error:', e)
									LOG_DEBUG('FRAGS AFTER:', player.arena.vehicles[p_id].get('frags'))
									LOG_DEBUG('ARENA HAS STATS:', hasattr(player.arena, 'statistics'))
									from gui import WindowsManager
									bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
									if bw and hasattr(bw, '_Battle__fragCorrelation'):
										p_team = getattr(player, 'team', 1)
										allied = sum(v.get('frags', 0) for v in player.arena.vehicles.values() if v.get('team') == p_team)
										enemy = sum(v.get('frags', 0) for v in player.arena.vehicles.values() if v.get('team') != p_team)
										bw._Battle__fragCorrelation.updateFrags(allied, enemy)
										try:
											if hasattr(bw, '_Battle__pMsgsPanel'):
												bw._Battle__pMsgsPanel.showMessage('PlayerKilled', {'killer': player.arena.vehicles[p_id].get('name', 'Player'), 'victim': enemy_mock.publicInfo.get('name', 'Bot')})
											if hasattr(bw, '_Battle__setPlayerInfo'):
												try:
													pass
												except Exception as e:
													import inspect
												LOG_DEBUG('setPlayerInfo error:', str(e), inspect.getargspec(bw._Battle__setPlayerInfo))
												try:
													import sys
													LOG_DEBUG('battle attributes again', dir(bw))
												except: pass
										except: pass
							except Exception as _e:
								LOG_DEBUG('Frag update error:', _e)
							
							# --- SWAP TO DESTROYED MODEL ---
							try:
								if getattr(enemy_mock, '_wreck_done', False):
									raise StopIteration  # wreck already handled by another kill path
								enemy_mock._wreck_done = True
								_dtd = enemy_mock.typeDescriptor
								_d_ch = BigWorld.Model(_dtd.chassis['models']['destroyed'])
								_d_hu = BigWorld.Model(_dtd.hull['models']['destroyed'])
								_d_tu = BigWorld.Model(_dtd.turret['models']['destroyed'])
								_d_gu = BigWorld.Model(_dtd.gun['models']['destroyed'])
								_old_ch = enemy_mock._chassis_model
								_old_pos = _old_ch.position
								_old_yaw = _old_ch.yaw
								_old_ch_ref = _old_ch
								def _swap_destroyed_model(_d_ch=_d_ch, _d_hu=_d_hu, _d_tu=_d_tu, _d_gu=_d_gu, _old_ch_ref=_old_ch_ref, _old_pos=_old_pos, _old_yaw=_old_yaw):
									_add_model(_d_ch)
									_add_model(_d_hu)
									_add_model(_d_tu)
									_add_model(_d_gu)
									def _attach_when_ready():
										if not getattr(_d_ch, 'loaded', True) or not getattr(_d_hu, 'loaded', True) or not getattr(_d_tu, 'loaded', True) or not getattr(_d_gu, 'loaded', True):
											BigWorld.callback(0.1, _attach_when_ready)
											return
										try: BigWorld.delModel(_d_hu)
										except: pass
										try: BigWorld.delModel(_d_tu)
										except: pass
										try: BigWorld.delModel(_d_gu)
										except: pass
										try: _old_ch_ref.visible = False
										except: pass
										try: _old_ch_ref.visibleAttachments = False
										except: pass
										try: BigWorld.delModel(_old_ch_ref)
										except: pass
										
										if getattr(m_veh, 'bw_entity', None) is not None:
											try: m_veh.bw_entity.model = None
											except:
												try: m_veh.bw_entity.model = BigWorld.Model('')
												except: pass
										
										# Wreck must rest on the ground (mid-air kill would leave a floating
										# wreck). _wpos: NEVER rebind _old_pos - in the player-kill path this
										# code sits in a nested function where _old_pos is only a closure var;
										# assigning it made it local -> UnboundLocalError -> vanishing wrecks.
										_wpos = _old_pos
										try:
											import BigWorld as _bwx, Math as _mx
											_gw = _bwx.wg_collideSegment(_offh_bspace(), _mx.Vector3(_wpos.x, _wpos.y + 2.0, _wpos.z), _mx.Vector3(_wpos.x, _wpos.y - 500.0, _wpos.z), 128)
											if _gw is not None and _wpos.y > _gw[0].y + 0.5:
												_wpos = _mx.Vector3(_wpos.x, _gw[0].y, _wpos.z)
										except Exception:
											pass
										_d_ch.position = _wpos
										_d_ch.yaw = _old_yaw
										_t_mat = Math.Matrix(); _t_mat.setIdentity()
										_g_mat = Math.Matrix(); _g_mat.setIdentity()
										try: _d_ch.node('V').attach(_d_hu)
										except: pass
										try: 
											m_veh._d_t_node = _d_hu.node('HP_turretJoint', _t_mat)
											m_veh._d_t_node.attach(_d_tu)
										except: pass
										try: 
											m_veh._d_g_node = _d_tu.node('HP_gunJoint', _g_mat)
											m_veh._d_g_node.attach(_d_gu)
										except: pass
										try:
											m_veh._collision_obstacle = BigWorld.PyModelObstacle(
												_dtd.hull['models']['destroyed'],
												_dtd.turret['models']['destroyed'],
												m_veh.matrix,
												False
											)
										except: pass
										LOG_DEBUG('Destroyed model swapped OK')
									_attach_when_ready()
								BigWorld.callback(0.0, _swap_destroyed_model)
							except Exception as _de:
								LOG_DEBUG('Destroyed model swap error:', str(_de))
					
					# --- GUNSHOT SOUND & EFFECTS ---
					try:
						if not hasattr(BigWorld.player(), 'soundNotifications'):
							import gui.IngameSoundNotifications as IngameSoundNotifications
							BigWorld.player().soundNotifications = IngameSoundNotifications.IngameSoundNotifications()
							BigWorld.player().soundNotifications.start()
						
						td = loaded_models.get('td')
						# Barrel recoil animation on the player's gun
						_trigger_gun_recoil(getattr(BigWorld.player(), '_offhangar_gun_recoil', None))
						# Hull rock-back: impulse backward along the shot direction
						try:
							_trigger_shot_impulse(getattr(BigWorld.player(), '_offhangar_swinging', None), Math.Vector3(-dir_vec.x, -dir_vec.y, -dir_vec.z), td.gun['impulse'] if td else 0.0)
						except Exception:
							pass
						_mflash_played = False
						if td is not None:
							_mflash_played = _play_muzzle_flash(BigWorld.player(), loaded_models.get('gun'), td, is_player=True)
						# The gun's effects list plays the real per-gun shot sound (like the
						# live game); the forced caliber-bucket sound doubled it with a
						# generic one. Bucket kept only as a fallback.
						if not _mflash_played:
							_fallback_gun_sound(td, loaded_models.get('chassis') or loaded_models.get('hull') or loaded_models.get('turret') or loaded_models.get('gun'))
					except Exception as e: pass
						
					LOG_DEBUG('OfflineBattle: SHOOT HIT LOGIC RUN!')
				except Exception as e:
					import traceback
					LOG_DEBUG('Shoot ERROR:', traceback.format_exc())


			# --- ENEMY CLONE SPAWNER (Key O) ---
			def _find_safe_spawn(want_pos):
				# Find a free, flat ground spot near want_pos:
				# not inside the player/other tanks, not against walls, not on roofs/steep slopes
				import math as _m
				import BigWorld, Math
				_pl = BigWorld.player()
				_sid = _pl.spaceID
				
				def _ground_at(x, z, y_hint):
					# Probe ground just above the expected height (not from +1000: avoids roofs)
					try:
						c = BigWorld.wg_collideSegment(_sid, Math.Vector3(x, y_hint + 3.0, z), Math.Vector3(x, y_hint - 150.0, z), 128)
						if c is not None:
							return c[0].y
					except Exception:
						pass
					return None
				
				def _is_free(x, y, z):
					# 1) Keep distance: >=10 m to the player, >=8 m to other tanks/wrecks
					try:
						if (x - veh_pos[0]) ** 2 + (z - veh_pos[2]) ** 2 < 100.0:
							return False
					except Exception:
						pass
					try:
						for _sv in mock_vehicles.values():
							_svp = getattr(_sv, 'position', None)
							if _svp is not None and (x - _svp.x) ** 2 + (z - _svp.z) ** 2 < 64.0:
								return False
					except Exception:
						pass
					# 2) Clearance: 8 horizontal rays at hull height (no walls right next to us)
					for _i in range(8):
						_a = _i * _m.pi / 4.0
						try:
							if BigWorld.wg_collideSegment(_sid, Math.Vector3(x, y + 1.2, z), Math.Vector3(x + _m.sin(_a) * 3.5, y + 1.2, z + _m.cos(_a) * 3.5), 128) is not None:
								return False
						except Exception:
							pass
					# 3) No steep slope / roof edge: ground probes 2.5 m around
					for _dx, _dz in ((2.5, 0.0), (-2.5, 0.0), (0.0, 2.5), (0.0, -2.5)):
						_gy = _ground_at(x + _dx, z + _dz, y)
						if _gy is None or abs(_gy - y) > 1.5:
							return False
					return True
				
				# Candidates: the desired point itself, then rings (8 directions) up to 30 m
				_cands = [(want_pos.x, want_pos.z)]
				for _r in (4.0, 8.0, 13.0, 20.0, 30.0):
					for _i in range(8):
						_a = _i * _m.pi / 4.0
						_cands.append((want_pos.x + _m.sin(_a) * _r, want_pos.z + _m.cos(_a) * _r))
				for _cx, _cz in _cands:
					_gy = _ground_at(_cx, _cz, want_pos.y)
					if _gy is None:
						continue
					if _is_free(_cx, _gy, _cz):
						return Math.Vector3(_cx, _gy, _cz)
				# Fallback 1: force the desired point down to the ground (long ray)
				try:
					c = BigWorld.wg_collideSegment(_sid, Math.Vector3(want_pos.x, want_pos.y + 300.0, want_pos.z), Math.Vector3(want_pos.x, want_pos.y - 1000.0, want_pos.z), 128)
					if c is not None:
						return Math.Vector3(want_pos.x, c[0].y, want_pos.z)
				except Exception:
					pass
				# Fallback 2: 15 m in front of the player
				try:
					_fx = veh_pos[0] + _m.sin(veh_yaw[0]) * 15.0
					_fz = veh_pos[2] + _m.cos(veh_yaw[0]) * 15.0
					_gy = _ground_at(_fx, _fz, veh_pos[1])
					if _gy is not None:
						return Math.Vector3(_fx, _gy, _fz)
				except Exception:
					pass
				return Math.Vector3(want_pos)
			_orig_handleKeyEvent = g_offline_aih.handleKeyEvent
			_spawn_count = [0]
			def _mock_handleKeyEvent(event):
				import BigWorld, Keys, Math
				player = BigWorld.player()
				
				if event.key == Keys.KEY_RIGHTMOUSE:
					if event.isKeyDown():
						_gun_state['rmb_down'] = True
						bot = getattr(player, '_outlined_bot', None)
						prev_target = getattr(player, '_autoaim_target', None)
						if bot is not None:
							team = getattr(bot, '_bot_team', 2)
							player_team = getattr(player, '_offhangar_team', 1)
							if team != player_team and getattr(bot, 'health', 0) > 0:
								if prev_target == bot:
									player._autoaim_target = None
								else:
									player._autoaim_target = bot
							else:
								player._autoaim_target = None
						else:
							player._autoaim_target = None
							
						curr_target = getattr(player, '_autoaim_target', None)
						if prev_target != curr_target:
							import debug_utils
							debug_utils.LOG_DEBUG('Autoaim state changed:', prev_target, '->', curr_target)
							try:
								sound_str = 'target_captured' if curr_target is not None else 'target_unlocked'
								if hasattr(player, 'soundNotifications') and player.soundNotifications is not None:
									player.soundNotifications.play(sound_str)
								else:
									if not hasattr(g_offline_aih, '_snd_notif'):
										try:
											from gui.IngameSoundNotifications import IngameSoundNotifications
											g_offline_aih._snd_notif = IngameSoundNotifications()
											g_offline_aih._snd_notif.start()
										except: pass
									if hasattr(g_offline_aih, '_snd_notif'):
										g_offline_aih._snd_notif.play(sound_str)
										debug_utils.LOG_DEBUG('Played sound via IngameSoundNotifications')
							except Exception as e:
								debug_utils.LOG_DEBUG('Sound error:', str(e))
						
						if getattr(player, '_autoaim_target', None) is None:
							_gun_state['locked_local_yaw'] = turret_yaw[0]
							_gun_state['locked_local_pitch'] = gun_pitch[0]
					else:
						_gun_state['rmb_down'] = False
						
				if event.isKeyDown() and event.key in [Keys.KEY_1, Keys.KEY_2, Keys.KEY_3]:
					try:
						idx = event.key - Keys.KEY_1
						from gui import WindowsManager
						bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
						panel = getattr(bw, 'consumablesPanel', None) if bw else None
						if panel and ('ammo_%d' % idx) in _gun_state:
							if _gun_state.get('shot_index', 0) != idx:
								_gun_state['shot_index'] = idx
								_gun_state['clip'] = min(_gun_state['clip_size'], _gun_state['ammo_%d' % idx])
								_gun_state['reloadTime'] = _gun_state['reload'] # Full reload on switch
								panel.setCurrentShell(idx)
								panel.setShellQuantityInSlot(idx, _gun_state['ammo_%d' % idx], _gun_state['clip'])
								try: panel.setCoolDownTime(idx, 0.0)
								except Exception as e:
									import debug_utils; debug_utils.LOG_DEBUG('setCoolDownTime reset error switch:', str(e))
								try: panel.setCoolDownTime(idx, _gun_state['reloadTime'])
								except Exception as e:
									import debug_utils; debug_utils.LOG_DEBUG('setCoolDownTime error switch:', str(e))
								try:
									aim = getattr(g_offline_aih, 'aim', None)
									if aim:
										try: aim.setReloading(0.0, None)
										except: pass
										aim.setReloading(_gun_state['reloadTime'], None)
										aim.setAmmoStock(_gun_state['ammo_%d' % idx], _gun_state['clip'], False)
								except Exception as e:
									import debug_utils; debug_utils.LOG_DEBUG('aim error switch:', str(e))
					except Exception as e:
						import debug_utils
						debug_utils.LOG_DEBUG('Key ammo switch error:', str(e))
						
				if event.isKeyDown() and event.key in [Keys.KEY_4, Keys.KEY_5, Keys.KEY_6]:
					try:
						import BigWorld
						player = BigWorld.player()
						idx_map = {Keys.KEY_4: 3, Keys.KEY_5: 4, Keys.KEY_6: 5}
						slot_idx = idx_map[event.key]
						for cons in _gun_state.get('consumables', []):
							if cons['slot'] == slot_idx and not cons['used']:
								tag = cons['tag']
								used = False
								if tag == 'extinguisher' and getattr(_player_mock, 'is_on_fire', False):
									_player_mock.is_on_fire = False
									import gui.WindowsManager
									bw = gui.WindowsManager.g_windowsManager.battleWindow
									if hasattr(bw, 'damagePanel'):
										bw.damagePanel._DamagePanel__callFlash('onFireInVehicle', [False])
									used = True
								elif tag == 'repairkit':
									# Repair all modules
									_player_mock.is_tracked = False
									try:
										import gui.WindowsManager
										bw = gui.WindowsManager.g_windowsManager.battleWindow
										if hasattr(bw, 'damagePanel'):
											for ui_name in ('engine', 'ammoBay', 'fuelTank', 'radio', 'leftTrack', 'rightTrack', 'track', 'gun', 'turretRotator', 'surveyingDevice'):
												try: bw.damagePanel.updateDeviceState(ui_name, 'normal')
												except: pass
									except: pass
									used = True
								elif tag == 'medkit':
									# Heal all crew
									try:
										import gui.WindowsManager
										bw = gui.WindowsManager.g_windowsManager.battleWindow
										if hasattr(bw, 'damagePanel'):
											for ui_name in ('commander', 'driver', 'radioman1', 'radioman2', 'gunner1', 'gunner2', 'loader1', 'loader2'):
												try: bw.damagePanel.updateDeviceState(ui_name, 'normal')
												except: pass
									except: pass
									used = True
								
								if used:
									cons['used'] = True
									try:
										import gui.WindowsManager
										panel = gui.WindowsManager.g_windowsManager.battleWindow.consumablesPanel
										if panel:
											panel.setItemQuantityInSlot(slot_idx, 0)
											panel.setCoolDownTime(slot_idx, -1)
									except: pass
								break
					except Exception as e:
						import debug_utils
						debug_utils.LOG_DEBUG('Consumable hotkey error:', str(e))

				if event.isKeyDown() and event.key == Keys.KEY_K:
					try:
						import BigWorld
						player = BigWorld.player()
						if hasattr(player, 'arena'):
							p_team = getattr(player, '_offhangar_team', getattr(player, 'team', 1))
							p_name = getattr(player, 'name', 'Player')
							p_dbid = getattr(player, 'databaseID', 1)
							_td = None
							try: _td = loaded_models.get('td')
							except: pass
							if not _td: _td = getattr(player, 'vehicleTypeDescriptor', None)
							
							p_cd = getattr(getattr(_td, 'type', None), 'compactDescr', 0)
							
							LOG_DEBUG('BATTLE RESULTS LOCAL P_CD IS:', p_cd)
							
							import debug_utils
							debug_utils.LOG_DEBUG('BATTLE RESULTS P_CD IS:', p_cd)
							
							if p_cd == 0 and hasattr(player, 'arena') and player.playerVehicleID in player.arena.vehicles:
								_vinfo = player.arena.vehicles[player.playerVehicleID]
								_vtype = _vinfo.get('vehicleType', None)
								if _vtype:
									p_cd = getattr(getattr(_vtype, 'type', None), 'compactDescr', 0)
									debug_utils.LOG_DEBUG('BATTLE RESULTS FALLBACK P_CD IS:', p_cd)
							
							allied = sum(v.get('frags', 0) for v in player.arena.vehicles.values() if v.get('team', 2) == p_team)
							enemy = sum(v.get('frags', 0) for v in player.arena.vehicles.values() if v.get('team', 2) != p_team)
							
							def _show_res():
								try:
									from gui.SystemMessages import SM_TYPE, pushMessage
									pushMessage('Offline battle finished. Returning to Hangar...'.encode('utf-8'), SM_TYPE.Information)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
								
								try:
									import MusicController
									if hasattr(MusicController, 'g_musicController') and MusicController.g_musicController:
										_mc = MusicController.g_musicController
										try: _mc.stop()
										except: pass
										evt = None
										if allied > enemy:
											evt = getattr(MusicController, 'MUSIC_EVENT_COMBAT_VICTORY', getattr(MusicController, 'MUSIC_EVENT_VICTORY', 'music_victory'))
										elif allied < enemy:
											evt = getattr(MusicController, 'MUSIC_EVENT_COMBAT_LOSE', getattr(MusicController, 'MUSIC_EVENT_LOSE', 'music_lose'))
										else:
											evt = getattr(MusicController, 'MUSIC_EVENT_COMBAT_DRAW', getattr(MusicController, 'MUSIC_EVENT_DRAW', 'music_draw'))
										try: _mc.play(evt)
										except: pass
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY MUSIC:', e); import traceback; LOG_DEBUG(traceback.format_exc())
								
								try:
									import battle_results_shared
									mock_arena_id = 999
									
									v_id = getattr(player, 'playerVehicleID', 1)
									p_max_health = getattr(getattr(player, 'vehicleTypeDescriptor', None), 'maxHealth', 1000)
									p_health = getattr(getattr(player, 'vehicle', None), 'health', p_max_health)
									
									_player_mock = globals().get('G_MOCK_VEHICLES', {}).get(getattr(player, 'playerVehicleID', -1))
									_p_killer_id = getattr(_player_mock, 'last_killer_id', 255) if p_health <= 0 else 0
									
									total_dmg_dealt = 0
									total_frags = 0
									total_hits = 0
									players_dict = {p_dbid: {'name': p_name, 'clanDBID': 0, 'clanAbbrev': '', 'prebattleID': 0, 'team': p_team, 'igrType': 0}}
									vehicles_dict = {v_id: {'health': p_health, 'credits': 10000, 'xp': 1000, 'shots': 10, 'hits': 8, 'he_hits': 0, 'pierced': 8, 'damageDealt': 0, 'damageAssisted': 0, 'damageReceived': max(0, p_max_health - p_health), 'shotsReceived': 0, 'spotted': 0, 'damaged': 0, 'kills': 0, 'tdamageDealt': 0, 'tkills': 0, 'isTeamKiller': False, 'capturePoints': 0, 'droppedCapturePoints': 0, 'mileage': 100, 'lifeTime': 300, 'killerID': _p_killer_id, 'achievements': [], 'repair': 0, 'freeXP': 50, 'details': {}, 'accountDBID': p_dbid, 'team': p_team, 'typeCompDescr': p_cd, 'gold': 0}}
									personal_details = {}
									
									for vid, vinfo in getattr(player.arena, 'vehicles', {}).items():
										if vid == v_id: continue
										bot_team = vinfo.get('team', 2)
										
										_mock_vehicles = globals().get('G_MOCK_VEHICLES', {})
										if vid in _mock_vehicles:
											bot_team = getattr(_mock_vehicles[vid], '_bot_team', bot_team)
										bot_name = vinfo.get('name', 'Bot')
										# Force bot DBID to be its vehicle ID so it never overlaps the player's DBID!
										bot_dbid = vid
										td = vinfo.get('vehicleType', None)
										
										_mock_vehicles = globals().get('G_MOCK_VEHICLES', {})
										if vid in _mock_vehicles:
											_true_td = getattr(_mock_vehicles[vid], 'typeDescriptor', None)
											if _true_td: td = _true_td
										
										td_type = getattr(td, 'type', None)
										bot_cd = getattr(td_type, 'compactDescr', 0)
										
										players_dict[bot_dbid] = {'name': bot_name, 'clanDBID': 0, 'clanAbbrev': '', 'prebattleID': 0, 'team': bot_team, 'igrType': 0}
										
										is_killed = not vinfo.get('isAlive', True)
										bot_hp = getattr(td, 'maxHealth', 1000)
										bot_max_hp = bot_hp
										
										_mock_vehicles = globals().get('G_MOCK_VEHICLES', {})
										if vid in _mock_vehicles:
											bot_hp = max(0, getattr(_mock_vehicles[vid], 'health', 0))
											bot_max_hp = getattr(_mock_vehicles[vid], 'maxHealth', bot_max_hp)
											if bot_hp <= 0: is_killed = True
										
										if not 'mock_vehicles' in locals() and not '_mock_vehicles' in locals():
											bot_hp = 0 if is_killed else bot_max_hp
											
										# Retrieve damage tracking from mock_vehicles
										_dmg_from_player = 0
										_dmg_from_bots = 0
										_hits_from_player = 0
										_mock_vehicles = globals().get('G_MOCK_VEHICLES', {})
										if vid in _mock_vehicles:
											_dmg_from_player = getattr(_mock_vehicles[vid], 'damage_from_player', 0)
											_dmg_from_bots = getattr(_mock_vehicles[vid], 'damage_from_bots', 0)
											_hits_from_player = getattr(_mock_vehicles[vid], 'hits_from_player', 0)
										
										# Removed dangerous fallback! Only explicitly tracked damage counts.
										dmg_received = bot_max_hp - bot_hp
										
										player_killed_this = is_killed and _dmg_from_player > 0 and _dmg_from_player >= (dmg_received / 2.0)
										if player_killed_this and bot_team == p_team: player_killed_this = False
										
										total_dmg_dealt += _dmg_from_player
										total_hits += _hits_from_player
										if player_killed_this: total_frags += 1
										
										killer_id = v_id if player_killed_this else (getattr(_mock_vehicles.get(vid, None), 'last_killer_id', 255) if is_killed else 0)
										
										# Simulate some random shots and hits if the bot dealt damage
										_bot_shots = max(1, int(_dmg_from_bots / 200.0)) if _dmg_from_bots > 0 else 1
										vehicles_dict[vid] = {'health': bot_hp, 'credits': 100, 'xp': 100, 'shots': _bot_shots, 'hits': _bot_shots, 'he_hits': 0, 'pierced': _bot_shots, 'damageDealt': _dmg_from_bots, 'damageAssisted': 0, 'damageReceived': dmg_received, 'shotsReceived': max(1, int(dmg_received / 300.0)) if dmg_received > 0 else 0, 'spotted': 0, 'damaged': 0, 'kills': 0, 'tdamageDealt': 0, 'tkills': 0, 'isTeamKiller': False, 'capturePoints': 0, 'droppedCapturePoints': 0, 'mileage': 100, 'lifeTime': 300, 'killerID': killer_id, 'achievements': [], 'repair': 0, 'freeXP': 5, 'details': {}, 'accountDBID': bot_dbid, 'team': bot_team, 'typeCompDescr': bot_cd, 'gold': 0}
										
										if _dmg_from_player > 0 or bot_team != p_team:
											personal_details[vid] = {'spotted': 1 if bot_team != p_team else 0, 'killed': 1 if player_killed_this else 0, 'hits': _hits_from_player, 'he_hits': 0, 'pierced': _hits_from_player, 'damageDealt': _dmg_from_player, 'damageAssisted': 0, 'crits': 1 if player_killed_this else 0, 'fire': 0}
											
									vehicles_dict[v_id]['damageDealt'] = total_dmg_dealt
									vehicles_dict[v_id]['kills'] = 0 # Will be populated by the loop below
									vehicles_dict[v_id]['hits'] = total_hits
									vehicles_dict[v_id]['pierced'] = total_hits
									vehicles_dict[v_id]['shots'] = max(10, total_hits + 2)
									vehicles_dict[v_id]['spotted'] = len(personal_details)
									vehicles_dict[v_id]['damaged'] = len(personal_details)
									
									for v_iter_id, v_iter_data in vehicles_dict.items():
										k_id = v_iter_data.get('killerID', 0)
										if k_id and k_id in vehicles_dict and k_id != v_iter_id:
											vehicles_dict[k_id]['kills'] = vehicles_dict[k_id].get('kills', 0) + 1
									
									mock_res = {
										'arenaUniqueID': mock_arena_id,
										'personal': {'health': p_health, 'credits': 10000, 'xp': 1000, 'shots': globals().get('G_OFFHANGAR_SHOTS_FIRED', max(0, total_hits)), 'hits': total_hits, 'he_hits': 0, 'pierced': total_hits, 'damageDealt': total_dmg_dealt, 'damageAssisted': 0, 'damageReceived': 0, 'shotsReceived': 0, 'spotted': len(personal_details), 'damaged': len(personal_details), 'kills': total_frags, 'tdamageDealt': 0, 'tkills': 0, 'isTeamKiller': False, 'capturePoints': 0, 'droppedCapturePoints': 0, 'mileage': 100, 'lifeTime': 300, 'killerID': _p_killer_id, 'achievements': [], 'repair': 0, 'freeXP': 50, 'details': personal_details, 'accountDBID': p_dbid, 'team': p_team, 'typeCompDescr': p_cd, 'gold': 0, 'xpPenalty': 0, 'creditsPenalty': 0, 'creditsContributionIn': 0, 'creditsContributionOut': 0, 'tmenXP': 0, 'eventCredits': 0, 'eventGold': 0, 'eventXP': 0, 'eventFreeXP': 0, 'eventTMenXP': 0, 'autoRepairCost': 0, 'autoLoadCost': (0, 0), 'autoEquipCost': (0, 0), 'isPremium': True, 'premiumXPFactor10': 15, 'premiumCreditsFactor10': 15, 'dailyXPFactor10': 10, 'aogasFactor10': 10, 'markOfMastery': 0, 'dossierPopUps': []},
										'common': {'arenaTypeID': getattr(player.arena, 'arenaTypeID', 1), 'arenaCreateTime': __import__('time').time(), 'winnerTeam': p_team if allied > enemy else (0 if allied==enemy else (3-p_team)), 'finishReason': 1, 'duration': 300, 'bonusType': 1, 'guiType': 1, 'vehLockMode': 0},
										'players': players_dict,
										'vehicles': vehicles_dict
									}
									
									if hasattr(battle_results_shared, 'VEH_FULL_RESULTS'):
										for k in battle_results_shared.VEH_FULL_RESULTS:
											if k not in mock_res['personal']: mock_res['personal'][k] = [] if 'list' in k or k == 'achievements' else (0 if k != 'details' else {})
									if hasattr(battle_results_shared, 'VEH_BASE_RESULTS'):
										for k in battle_results_shared.VEH_BASE_RESULTS:
											for v in mock_res['vehicles']:
												if k not in mock_res['vehicles'][v]: mock_res['vehicles'][v][k] = [] if 'list' in k or k == 'achievements' else (0 if k != 'details' else {})
									
									def _mock_get(arenaUniqueID, callback):
										import BigWorld
										BigWorld.callback(0.1, lambda: callback(1, mock_res))
									
									player_brc = getattr(player, 'battleResultsCache', None)
									if player_brc:
										orig_br_get = player_brc.get
										player_brc.get = _mock_get
									
									from gui import WindowsManager
									window = getattr(WindowsManager.g_windowsManager, 'window', None)
									if hasattr(window, 'onBattleResultsReceived'): window.onBattleResultsReceived(True, mock_arena_id)
									elif hasattr(window, 'battleResults') and hasattr(window.battleResults, 'show'): window.battleResults.show(mock_arena_id)
									elif hasattr(window, 'battleResults') and hasattr(window.battleResults, '_BattleResultsManager__showBattleResults'): window.battleResults._BattleResultsManager__showBattleResults(mock_arena_id)
								except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
							
							BigWorld.callback(4.0, _show_res)
							player.leaveArena()
					except Exception: pass

				if event.isKeyDown() and event.key in (Keys.KEY_O, Keys.KEY_P, Keys.KEY_L):
					try:
						player = BigWorld.player()
						start_pos, dir_vec = player.gunRotator._VehicleGunRotator__getCurShotPosition()
						dir_vec.normalise()
						hit = BigWorld.wg_collideSegment(_offh_bspace(), start_pos, start_pos + dir_vec.scale(500.0), 128)
						target_pos = hit[0] if hit else start_pos + dir_vec.scale(50.0)
						
						# Auto-spawner forces a spawn location (original map spawn points)
						_forced_pos = getattr(player, '_forced_spawn_pos', None)
						if _forced_pos is not None:
							target_pos = Math.Vector3(_forced_pos[0], _forced_pos[1], _forced_pos[2])
						
						# Find a safe free ground spot near the aim point
						# (not inside player/tanks/walls, not on roofs, never floating in the air)
						target_pos = _find_safe_spawn(target_pos)
						
						td = None
						bot_name = 'Bot ' + str(_spawn_count[0])
						bot_team = 1 if event.key == Keys.KEY_L else 2
						# Auto-spawner overrides team/facing. Read them synchronously here:
						# the model-load callback below runs async and must not race the next spawn.
						_forced_team = getattr(player, '_forced_spawn_team', None)
						if _forced_team in (1, 2): bot_team = _forced_team
						_forced_yaw_local = getattr(player, '_forced_spawn_yaw', None)
						if bot_team == 1: bot_name = 'Ally ' + str(_spawn_count[0])
						if event.key == Keys.KEY_O:
							td = loaded_models.get('td')
							bot_name = 'Clone ' + str(_spawn_count[0])
						elif event.key in (Keys.KEY_P, Keys.KEY_L):
							try:
								import random
								from items import vehicles
								import nations
								cur_tier = loaded_models['td'].type.level
								candidates = []
								for nation in nations.AVAILABLE_NAMES:
									nationID = nations.INDICES[nation]
									for v in vehicles.g_list.getList(nationID).itervalues():
										if abs(v['level'] - cur_tier) <= 2:
											candidates.append(v['name'])
								LOG_DEBUG('KEY P pressed! cur_tier=%d candidates=%d' % (cur_tier, len(candidates)))
								if candidates:
									chosen = random.choice(candidates)
									# Auto-spawner pre-picks vehicles (sorted by class for the line-up)
									_fv = getattr(player, '_forced_spawn_vehname', None)
									if _fv: chosen = _fv
									td = vehicles.VehicleDescr(typeName=chosen)
									bot_name = ('Ally ' if bot_team == 1 else 'Enemy ') + chosen.split(':')[-1] + ' ' + str(_spawn_count[0])
							except Exception as e:
								import traceback
								LOG_DEBUG('Random spawn error:', str(e), traceback.format_exc())
								td = loaded_models.get('td')
						
						if not td: return True

						# OOM guard: each bot is a full tank (models + textures +
						# per-component VehicleStickers + recoil). Spawning far past a
						# normal battle exhausts the 32-bit client and it crashes
						# NATIVELY mid-spawn (no Python traceback). Cap the live count
						# (player + bots); raise max_total_bots in config.json to allow more.
						try:
							from _constants import CONFIG_OPTIONS as _CFG_CAP
							_bot_cap = int(_CFG_CAP.get('max_total_bots', 50))
						except Exception:
							_bot_cap = 50
						if _bot_cap > 0 and len(globals().get('G_MOCK_VEHICLES', {}) or {}) >= _bot_cap:
							LOG_DEBUG('Bot spawn capped at %d live (raise max_total_bots in config.json)' % _bot_cap)
							return True

						try:
							for hitTester in td.getHitTesters():
								hitTester.loadBspModel()
						except Exception as e:
							LOG_DEBUG("Error loading hitTesters for bot:", str(e))
						
						e_id = 1000 + _spawn_count[0]
						_spawn_count[0] += 1
						
						# Load visual models
						
						def _on_bot_models_loaded(resourceRefs):
							try:
								ch = resourceRefs[td.chassis['models']['undamaged']]
								hu = resourceRefs[td.hull['models']['undamaged']]
								tu = resourceRefs[td.turret['models']['undamaged']]
								gu = resourceRefs[td.gun['models']['undamaged']]
							except Exception as e:
								import debug_utils
								debug_utils.LOG_DEBUG('Bot model unpack error:', str(e))
								return
							e_mock = _MockVeh()
							e_mock.id = e_id
							e_mock.position = target_pos
							# Face the player
							import math
							e_mock.yaw = math.atan2(start_pos.x - target_pos.x, start_pos.z - target_pos.z)
							if _forced_yaw_local is not None:
								e_mock.yaw = _forced_yaw_local
							e_mock.health = getattr(td, 'maxHealth', 1000)
							e_mock.maxHealth = e_mock.health
							e_mock.isAlive = True
							e_mock.isStarted = True
							e_mock._bot_team = bot_team
							LOG_DEBUG('SPAWN BOT: bot_team=%s bot_name=%s player_team=%s' % (bot_team, bot_name, getattr(player, '_offhangar_team', -99)))
							e_mock.publicInfo = {
								'vehicleType': td,
								'name': bot_name,
								'team': bot_team,
								'isAlive': True,
								'isAvatarReady': True,
								'isTeamKiller': False,
								'accountDBID': 0,
								'clanAbbrev': '',
								'clanDBID': 0,
								'prebattleID': 0,
								'isPrebattleCreator': False,
							'events': {}
							}
							ch.position = e_mock.position
							ch.yaw = e_mock.yaw
							
							_eid = BigWorld.createEntity('OfflineEntity', _offh_bspace(), 0, e_mock.position, (0, 0, e_mock.yaw), dict())
							e_mock.bw_entity = None
							def _assign_model_when_ready(eid, model_to_add, retries=10, _e_mock=e_mock):
								if not getattr(_e_mock, 'isAlive', True) or getattr(_e_mock, '_wreck_done', False):
									return  # bot died meanwhile: never re-add the intact model over the wreck
								ent = BigWorld.entity(eid)
								if ent:
									ent.model = model_to_add  # Outline needs it!
									try:
										ent.filter = BigWorld.AvatarFilter()
									except: pass
									_e_mock.bw_entity = ent
								elif retries > 0:
									BigWorld.callback(0.1, lambda: _assign_model_when_ready(eid, model_to_add, retries - 1, _e_mock))
								else:
									_add_model(model_to_add)
							# world-add moved BELOW mock registration: a failure in between
							# must not leave a ghost model in the world
							h_mat = Math.Matrix(); h_mat.setIdentity()
							t_mat = Math.Matrix(); t_mat.setIdentity()
							g_mat = Math.Matrix(); g_mat.setIdentity()
							ch.node('V').attach(hu)
							e_mock._t_node = hu.node('HP_turretJoint', t_mat)
							e_mock._t_node.attach(tu)
							e_mock._g_node = tu.node('HP_gunJoint', g_mat)
							e_mock._g_node.attach(gu)
							e_mock._gun_recoil = _setup_gun_recoil(gu, td)
							e_mock._swinging = _setup_swinging(ch, td)
							e_mock.model = ch
							e_mock.typeDescriptor = td
							e_mock._chassis_model = ch
							e_mock._hull_model = hu
							e_mock._turret_model = tu
							e_mock._gun_model = gu
							e_mock._t_mat = t_mat
							# Per-component VehicleStickers so shell-hole decals can land
							# on this bot (bots have no stickers otherwise). Empty emblem
							# slots - we only want the damage-sticker model.
							try:
								import VehicleStickers
								e_mock._sticker_map = {}
								_bot_sticker_setup = (
									('hull', hu, ch.node('V')),
									('turret', tu, e_mock._t_node),
									('gun', gu, e_mock._g_node),
								)
								for _cn, _cm, _cnode in _bot_sticker_setup:
									if _cm is not None and _cnode is not None:
										_st = VehicleStickers.VehicleStickers(td, [], _cn == 'hull', None)
										_st.attachStickers(_cm, _cnode, False)
										e_mock._sticker_map[_cn] = (_st, _cm, _cnode)
							except Exception as _se:
								LOG_DEBUG('Bot sticker setup error:', str(_se))
							# Scrolling-track animation for the bot (original fashion system);
							# attached slightly delayed so the model is in the world first
							def _attach_bot_fashion(_bch=ch, _btd=td, _bm=e_mock):
								# The ghost-fix delays the world-add (entity retries); a fashion
								# attached to a not-yet-inWorld model stays inert -> static tracks.
								# Wait for inWorld like the player path does.
								if not getattr(_bch, 'inWorld', False):
									_bm._fash_tries = (getattr(_bm, '_fash_tries', 0) or 0) + 1
									if _bm._fash_tries < 20 and getattr(_bm, 'isAlive', True):
										BigWorld.callback(0.5, lambda: _attach_bot_fashion(_bch, _btd, _bm))
									return
								try:
									_bf = BigWorld.WGVehicleFashion()
									try:
										_bf.maxMovement = _btd.physics['speedLimits'][0]
									except Exception:
										pass
									# Swinging node 'V' is mandatory for attaching the fashion
									try:
										_b_sw = _btd.hull['swinging']
										_bf.setPitchSwinging('V', *_b_sw['pitchParams'])
										_bf.setRollSwinging('V', *_b_sw['rollParams'])
										_bf.setShotSwinging('V', _b_sw['sensitivityToImpulse'])
									except Exception:
										pass
									_bt = _btd.chassis['tracks']
									try:
										_bf.setLods(_btd.chassis['traces']['lodDist'], _btd.chassis['wheels']['lodDist'], _bt['lodDist'], _btd.hull['swinging']['lodDist'])
									except Exception:
										pass
									_bf.setTracks(_bt['leftMaterial'], _bt['rightMaterial'], _bt['textureScale'])
									# Road wheels + scroll source, same as the player fashion
									try:
										_bwcfg = _btd.chassis['wheels']
										for _bg in _bwcfg['groups']:
											_bn = ['%s%d' % (_bg[1], _bi) for _bi in range(_bg[3], _bg[3] + _bg[2])]
											_bf.addWheelGroup(_bg[0], _bg[4], _bn)
										for _bwh in _bwcfg['wheels']:
											_bf.addWheel(_bwh[0], _bwh[2], _bwh[1])
									except Exception:
										pass
									try:
										_bf.movementInfo = Math.Vector4(0.0, 0.0, 0.0, 0.0)
									except Exception:
										pass
									_bch.wg_fashion = _bf
									_bm._fashion = _bf
								except Exception as _bfe:
									LOG_DEBUG('Bot track fashion failed:', str(_bfe))
							BigWorld.callback(1.5, _attach_bot_fashion)
							try:
								e_mock._collision_obstacle = BigWorld.PyModelObstacle(
									td.hull['models']['undamaged'],
									td.turret['models']['undamaged'],
									e_mock.matrix,
									True
								)
							except Exception as e:
								LOG_DEBUG('OfflineBattle PyModelObstacle Error:', e)
							class FakeEnemyAppearance(object):
								def __init__(self):
									from Event import Event
									self.onModelChanged = Event()
								def changeVisibility(self, *a, **kw): pass
								def showDamageFromShot(self, *a, **kw): pass
								def showDamageFromExplosion(self, *a, **kw): pass
							e_mock.appearance = FakeEnemyAppearance()
							mock_vehicles[e_id] = e_mock
							try:
								_assign_model_when_ready(_eid, ch)
							except Exception:
								_add_model(ch)
							import weakref
							e_mock.proxy = weakref.proxy(e_mock)
							
							from gui import WindowsManager
							player.arena.vehicles[e_id] = e_mock.publicInfo
							try:
								player.arena.onVehicleAdded(e_id)
							except: pass
							try:
								bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
								if bw and hasattr(bw, '_Battle__updatePlayers'):
									bw._Battle__updatePlayers()
							except: pass
							
							try:
								if hasattr(WindowsManager.g_windowsManager.battleWindow, 'vMarkersManager'):
									e_mock.marker = WindowsManager.g_windowsManager.battleWindow.vMarkersManager.createMarker(e_mock.proxy)
								
								minimap = WindowsManager.g_windowsManager.battleWindow.minimap
								if minimap:
									minimap.notifyVehicleStart(e_mock.id)
							except Exception as e:
								LOG_DEBUG('GUI Add error:', str(e))
							LOG_DEBUG('Enemy Clone Spawned at:', target_pos)
						
						BigWorld.loadResourceListBG((
							td.chassis['models']['undamaged'],
							td.hull['models']['undamaged'],
							td.turret['models']['undamaged'],
							td.gun['models']['undamaged'],
						), _on_bot_models_loaded)
						return True
					except Exception as e:
						import traceback
						LOG_DEBUG('Clone spawn error:', traceback.format_exc())
				return _orig_handleKeyEvent(event)
			g_offline_aih.handleKeyEvent = _mock_handleKeyEvent
			
			# --- 15v15 AUTO-SPAWN like the original game ---
			# In 0.8.2 ctf the teams spawn AT the teamBasePositions (the arena_defs
			# only carry teamSpawnPoints for the domination mode). The line-up is a
			# 5x3 grid behind the flag, 9 m spacing, facing the enemy base, with the
			# heavies up front and artillery at the back. bots_per_team in config.json.
			def _formation_slot(t_id, slot):
				# Returns (x, z, yaw) for a line-up slot of the given team.
				# Slot 0 = front row centre (the player's own slot in his team).
				import math
				_sp = globals().get('g_offline_spawns', {}) or {}
				_bs = globals().get('g_offline_bases', {}) or {}
				pts = list(_sp.get(t_id, []) or [])
				if not pts:
					pts = [(_b.x, _b.z) for _b in (_bs.get(t_id, []) or [])]
				if not pts:
					return (0.0, 0.0, 0.0)
				ax, az = pts[slot % len(pts)]
				# Face the enemy base (fallback: map centre)
				try:
					eb = _bs.get(2 if t_id == 1 else 1, [])
					yaw = math.atan2(eb[0].x - ax, eb[0].z - az) if eb else math.atan2(-ax, -az)
				except Exception:
					yaw = 0.0
				k = slot // len(pts)
				cols = (0, -1, 1, -2, 2)   # centre first, then fan out
				col = cols[k % 5]
				row = k // 5
				back = 8.0 + row * 9.0      # rows start behind the flag, never on it
				sx = ax - math.sin(yaw) * back + math.cos(yaw) * col * 9.0
				sz = az - math.cos(yaw) * back - math.sin(yaw) * col * 9.0
				return (sx, sz, yaw)
			# Shared via globals: _aih_tick uses it for the player's spawn correction
			globals()['g_offline_formation_slot'] = _formation_slot

			def _auto_spawn_teams():
				import BigWorld, Keys, Math, math
				try:
					_pl = BigWorld.player()
					if _pl is None or _battle_finished[0]:
						return
					from _constants import CONFIG_OPTIONS as _CFG
					_n_per_team = int(_CFG.get('bots_per_team', 15))
					if _n_per_team <= 0:
						return
					_spawns = dict(globals().get('g_offline_spawns', {}) or {})
					_bases = globals().get('g_offline_bases', {}) or {}
					_p_team = getattr(_pl, '_offhangar_team', 1) or 1
					
					class _FakeSpawnEvent(object):
						def __init__(self, key):
							self.key = key
						def isKeyDown(self):
							return True
					
					def _anchors(t_id):
						pts = list(_spawns.get(t_id, []) or [])
						if not pts:
							# Fall back to the team base flag if the map has no spawn points
							for _b in (_bases.get(t_id, []) or []):
								pts.append((_b.x, _b.z))
						return pts
					
					def _face_yaw(t_id, x, z):
						# Line the team up facing the enemy base (like the real line-up)
						try:
							_eb = _bases.get(2 if t_id == 1 else 1, [])
							if _eb:
								return math.atan2(_eb[0].x - x, _eb[0].z - z)
						except Exception:
							pass
						return math.atan2(-x, -z)
					
					_jobs = []
					for _t in (1, 2):
						_pts = _anchors(_t)
						if not _pts:
							LOG_DEBUG('AUTO-SPAWN: no spawn points for team', _t)
							continue
						# The player already occupies slot 0 (front row centre) of his team
						_count = _n_per_team - 1 if _t == _p_team else _n_per_team
						_slot0 = 1 if _t == _p_team else 0
						# Pick the bots' vehicles up front and sort heavy -> arty so the
						# front rows hold the heavies and artillery sits at the back
						_veh_names = []
						try:
							import random as _rnd
							from items import vehicles as _veh_items
							import nations as _nations
							_tier = loaded_models['td'].type.level
							_cand = []
							for _nat in _nations.AVAILABLE_NAMES:
								_nid = _nations.INDICES[_nat]
								for _v in _veh_items.g_list.getList(_nid).itervalues():
									if abs(_v['level'] - _tier) <= 2:
										_cand.append(_v)
							def _class_key(_v):
								try:
									_tg = _v['tags']
								except Exception:
									return 1
								if 'heavyTank' in _tg: return 0
								if 'mediumTank' in _tg: return 1
								if 'AT-SPG' in _tg: return 2
								if 'lightTank' in _tg: return 3
								if 'SPG' in _tg: return 4
								return 1
							if _cand:
								# Limit to a small STABLE per-tier pool reused across
								# battles so bot tank TEXTURES cache once instead of
								# loading ~30 fresh random tanks each battle (the leak
								# that climbed the baseline until map-load OOM).
								_pool = _offh_bot_pool(_cand, _tier)
								_picked = [_pool[_x % len(_pool)] for _x in range(_count)]
								_rnd.shuffle(_picked)
								_picked.sort(key=_class_key)
								_veh_names = [_p['name'] for _p in _picked]
						except Exception:
							import traceback
							LOG_DEBUG('AUTO-SPAWN vehicle pick failed:', traceback.format_exc())
						for _i in range(_count):
							_sx, _sz, _yw = _formation_slot(_t, _slot0 + _i)
							_vn = _veh_names[_i] if _i < len(_veh_names) else None
							_jobs.append((_t, _sx, _sz, _yw, _vn))
					
					# Interleave the teams so both sides build up evenly
					_t1 = [_j for _j in _jobs if _j[0] == 1]
					_t2 = [_j for _j in _jobs if _j[0] == 2]
					_jobs = []
					for _k in range(max(len(_t1), len(_t2))):
						if _k < len(_t1): _jobs.append(_t1[_k])
						if _k < len(_t2): _jobs.append(_t2[_k])
					
					def _spawn_next(_rest):
						if _battle_finished[0] or not _rest:
							return
						_t, _x, _z, _yw, _vn = _rest[0]
						try:
							_p2 = BigWorld.player()
							_gy = 300.0
							try:
								_gc = BigWorld.wg_collideSegment(_p2.spaceID, Math.Vector3(_x, 1000.0, _z), Math.Vector3(_x, -1000.0, _z), 128)
								if _gc is not None:
									_gy = _gc[0].y
							except Exception:
								pass
							_p2._forced_spawn_pos = (_x, _gy, _z)
							_p2._forced_spawn_team = _t
							_p2._forced_spawn_yaw = _yw
							_p2._forced_spawn_vehname = _vn
							try:
								_mock_handleKeyEvent(_FakeSpawnEvent(Keys.KEY_P))
							finally:
								_p2._forced_spawn_pos = None
								_p2._forced_spawn_team = None
								_p2._forced_spawn_yaw = None
								_p2._forced_spawn_vehname = None
						except Exception as _se:
							LOG_DEBUG('AUTO-SPAWN error:', str(_se))
						BigWorld.callback(0.3, lambda: _spawn_next(_rest[1:]))
					
					LOG_DEBUG('AUTO-SPAWN: placing %d bots (%d per team incl. player)' % (len(_jobs), _n_per_team))
					_spawn_next(_jobs)
				except Exception:
					import traceback
					LOG_DEBUG('AUTO-SPAWN failed:', traceback.format_exc())
			
			def _preload_bot_pool():
				# EXPERIMENTAL feature (config 'preload_bots'; may be unstable / change).
				# FPS: warm the bot pool's MODEL + BSP caches during the LOADING
				# screen so the later staggered auto-spawn is a cache hit instead
				# of decoding ~8 tank model-sets + BSP collision on the main thread
				# while the player is already driving (the FPS drop at bot spawns).
				# The pool is deterministic (g_offh_bot_pool[tier]) so we know
				# exactly which vehicles the bots will use. Safe: worst case a
				# redundant background load. Gated by config 'preload_bots'.
				try:
					from items import vehicles as _pv
					import nations as _pn
					_ptier = loaded_models['td'].type.level
					_pcand = []
					for _pnat in _pn.AVAILABLE_NAMES:
						_pnid = _pn.INDICES[_pnat]
						for _pvh in _pv.g_list.getList(_pnid).itervalues():
							if abs(_pvh['level'] - _ptier) <= 2:
								_pcand.append(_pvh)
					_ppool = _offh_bot_pool(_pcand, _ptier)
					if not _ppool:
						return
					_pnoop = lambda *a, **k: None
					_pwarm = 0
					for _pentry in _ppool:
						try:
							_ptd = _pv.VehicleDescr(typeName=_pentry['name'])
						except Exception:
							continue
						try:
							for _pht in _ptd.getHitTesters():
								_pht.loadBspModel()
						except Exception:
							pass
						try:
							BigWorld.loadResourceListBG((
								_ptd.chassis['models']['undamaged'],
								_ptd.hull['models']['undamaged'],
								_ptd.turret['models']['undamaged'],
								_ptd.gun['models']['undamaged'],
							), _pnoop)
							_pwarm += 1
						except Exception:
							pass
					LOG_DEBUG('AUTO-SPAWN preload: warmed %d/%d bot vehicles (tier %s)' % (_pwarm, len(_ppool), _ptier))
				except Exception:
					import traceback
					LOG_DEBUG('AUTO-SPAWN preload failed:', traceback.format_exc())
			try:
				from _constants import CONFIG_OPTIONS as _CFG_PLB
				if bool(_CFG_PLB.get('preload_bots', True)) and int(_CFG_PLB.get('bots_per_team', 15)) > 0:
					_preload_bot_pool()
			except Exception:
				pass
			try:
				from _constants import CONFIG_OPTIONS as _CFG_AS
				if int(_CFG_AS.get('bots_per_team', 15)) > 0:
					# Give the terrain chunks time to stream in before lining up the teams
					BigWorld.callback(float(_CFG_AS.get('auto_spawn_delay_seconds', 10.0)), _auto_spawn_teams)
			except Exception:
				import traceback
				LOG_DEBUG('AUTO-SPAWN schedule failed:', traceback.format_exc())
			# -------------------------------------------

			player.shoot = _mock_shoot
			
			# --- Central kill handling: keep players-panel/minimap icons in sync ---
			# Every kill path fires arena.onVehicleKilled(...). The bare event does not
			# flip arena.vehicles[id]['isAlive'], so panel icons stayed 'alive'. Wrap it
			# once so ALL kill paths (shots, fire, ramming) update the UI consistently.
			try:
				if hasattr(player, 'arena') and player.arena is not None and not getattr(player.arena, '_offh_kill_wrapped', False):
					class _KillEventWrapper(object):
						def __init__(self, orig):
							self._orig = orig
						def __iadd__(self, handler):
							try:
								self._orig += handler
							except Exception:
								pass
							return self
						def __isub__(self, handler):
							try:
								self._orig -= handler
							except Exception:
								pass
							return self
						def __getattr__(self, name):
							return getattr(self._orig, name)
						def __call__(self, victimID, killerID=-1, reason=0):
							import BigWorld
							_pl = BigWorld.player()
							_mv = globals().get('G_MOCK_VEHICLES', {}).get(victimID)
							try:
								if _pl is not None and victimID in getattr(_pl.arena, 'vehicles', {}):
									_pl.arena.vehicles[victimID]['isAlive'] = False
							except Exception:
								pass
							try:
								if _mv is not None:
									_mv.isAlive = False
									if (getattr(_mv, 'health', None) or 0) > 0:
										_mv.health = 0
									# Original behaviour (Vehicle.__onVehicleDeath): the marker is NOT
									# destroyed on death - it switches to the grey 'dead' state. Wrecks
									# are visible to everyone, so create the marker first if the victim
									# died unspotted. Central here for EVERY kill path.
									try:
										from gui import WindowsManager as _zwm
										_zbw = getattr(_zwm.g_windowsManager, 'battleWindow', None)
										_zvm = getattr(_zbw, 'vMarkersManager', None) if _zbw is not None else None
										if _zvm is not None:
											_zfresh = getattr(_mv, 'marker', None) in (None, -1)
											if _zfresh:
												try:
													_mv.marker = _zvm.createMarker(_mv.proxy)
												except Exception:
													_mv.marker = None
											if getattr(_mv, 'marker', None) not in (None, -1):
												try:
													_zvm.onVehicleHealthChanged(_mv.marker, 0, killerID, 0)
												except Exception:
													pass
												_zvm.updateMarkerState(_mv.marker, 'dead', not _zfresh)
									except Exception:
										pass
							except Exception:
								pass
							try:
								if self._orig is not None:
									self._orig(victimID, killerID, reason)
							except Exception:
								pass
							# Grey out the players-panel icon + drop the minimap marker
							try:
								from gui import WindowsManager
								_bw = getattr(WindowsManager.g_windowsManager, 'battleWindow', None)
								if _bw is not None:
									try:
										if hasattr(_bw, '_Battle__updatePlayers'):
											_bw._Battle__updatePlayers()
									except Exception:
										pass
									try:
										if getattr(_bw, 'minimap', None):
											_bw.minimap.notifyVehicleStop(victimID)
									except Exception:
										pass
									try:
										pass  # marker health + 'dead' state already handled centrally above
									except Exception:
										pass
							except Exception:
								pass
							# Fire deaths (reason 2) have no wreck-swap path of their own:
							# swap burnt-out bots to their destroyed models here
							try:
								if (reason == 2 or reason == 3 or killerID == -1) and _mv is not None and _pl is not None and victimID != getattr(_pl, 'playerVehicleID', -1) and not getattr(_mv, '_wreck_done', False) and getattr(_mv, '_chassis_model', None) is not None:
									_mv._wreck_done = True
									_dtd = getattr(_mv, 'typeDescriptor', None)
									if _dtd is not None:
										_d_ch = BigWorld.Model(_dtd.chassis['models']['destroyed'])
										_d_hu = BigWorld.Model(_dtd.hull['models']['destroyed'])
										_d_tu = BigWorld.Model(_dtd.turret['models']['destroyed'])
										_d_gu = BigWorld.Model(_dtd.gun['models']['destroyed'])
										_old_ch = _mv._chassis_model
										_old_pos = _old_ch.position
										_old_yaw = _old_ch.yaw
										def _fire_wreck_swap(_d_ch=_d_ch, _d_hu=_d_hu, _d_tu=_d_tu, _d_gu=_d_gu, _old_ch=_old_ch, _old_pos=_old_pos, _old_yaw=_old_yaw, _mv=_mv):
											import BigWorld, Math
											if not getattr(_d_ch, 'loaded', True) or not getattr(_d_hu, 'loaded', True) or not getattr(_d_tu, 'loaded', True) or not getattr(_d_gu, 'loaded', True):
												BigWorld.callback(0.1, _fire_wreck_swap)
												return
											try: _old_ch.visible = False
											except Exception: pass
											try: _old_ch.visibleAttachments = False
											except Exception: pass
											try:
												if getattr(_mv, 'bw_entity', None) is not None:
													_mv.bw_entity.model = None  # chassis is entity-owned: delModel alone fails
											except Exception: pass
											try: BigWorld.delModel(_old_ch)
											except Exception: pass
											# Wreck must rest on the ground (mid-air kill would leave a floating
											# wreck). _wpos: NEVER rebind _old_pos - in the player-kill path this
											# code sits in a nested function where _old_pos is only a closure var;
											# assigning it made it local -> UnboundLocalError -> vanishing wrecks.
											_wpos = _old_pos
											try:
												import BigWorld as _bwx, Math as _mx
												_gw = _bwx.wg_collideSegment(_offh_bspace(), _mx.Vector3(_wpos.x, _wpos.y + 2.0, _wpos.z), _mx.Vector3(_wpos.x, _wpos.y - 500.0, _wpos.z), 128)
												if _gw is not None and _wpos.y > _gw[0].y + 0.5:
													_wpos = _mx.Vector3(_wpos.x, _gw[0].y, _wpos.z)
											except Exception:
												pass
											_d_ch.position = _wpos
											_d_ch.yaw = _old_yaw
											try: _d_ch.node('V').attach(_d_hu)
											except Exception: pass
											try:
												_tm = Math.Matrix(); _tm.setIdentity()
												_mv._d_t_node = _d_hu.node('HP_turretJoint', _tm)
												_mv._d_t_node.attach(_d_tu)
											except Exception: pass
											try:
												_gm = Math.Matrix(); _gm.setIdentity()
												_mv._d_g_node = _d_tu.node('HP_gunJoint', _gm)
												_mv._d_g_node.attach(_d_gu)
											except Exception: pass
											try: _add_model(_d_ch)
											except Exception: pass
										BigWorld.callback(0.1, _fire_wreck_swap)
							except Exception:
								pass
					player.arena.onVehicleKilled = _KillEventWrapper(getattr(player.arena, 'onVehicleKilled', None))
					player.arena._offh_kill_wrapped = True
					LOG_DEBUG('OfflineBattle: kill-event wrapper installed')
			except Exception:
				import traceback
				LOG_DEBUG('OfflineBattle: kill wrapper failed:', traceback.format_exc())
			
			from Account import Account
			if not hasattr(Account, 'shoot'):
				Account.shoot = _mock_shoot
			if not hasattr(Account, 'autoAim'):
				Account.autoAim = lambda self, targetID: None
			if not hasattr(Account, 'isGuiVisible'):
				Account.isGuiVisible = True

			if hasattr(player, 'arena'):
				if player.arena.vehicles:
					player.playerVehicleID = player.arena.vehicles.keys()[0]
			
			Waiting.close()
			
			# ---- ZVUK: okamžitě zastavit garážové audio, spustit loading hudbu ----
			try:
				import MusicController as _MC
				
				
				if not hasattr(_MC, '_orig_play'):
					_MC._orig_play = _MC.MusicController.play
					def _mock_play(self, eventName):
						# NOTE: no traceback logging here - format_stack() built a
						# full stack dump string on EVERY music event, ungated.
						from debug_utils import LOG_DEBUG
						LOG_DEBUG('MusicController.play called with:', eventName)
						return _MC._orig_play(self, eventName)
					_MC.MusicController.play = _mock_play
				if not hasattr(_MC, '_orig_stopMusic'):
					_MC._orig_stopMusic = _MC.MusicController.stopMusic
					def _mock_stopMusic(self, *args, **kwargs):
						from debug_utils import LOG_DEBUG
						LOG_DEBUG('MusicController.stopMusic called!')
						return _MC._orig_stopMusic(self, *args, **kwargs)
				_mc = _MC.g_musicController
				try:
					import SoundGroups as _SG
					if getattr(_SG, 'g_instance', None) is not None:
						_SG.g_instance.setVolume('music', 1.0)
						_SG.g_instance.setVolume('ambient', 1.0)
				except Exception: pass
				
				# 1) Okamžitě zastavit staré FMOD sound eventy
				_snd_music = getattr(_mc, '_MusicController__sndEventMusic', None)
				if _snd_music is not None:
					try: _snd_music.stop()
					except Exception: pass
				_snd_ambient = getattr(_mc, '_MusicController__sndEventAmbient', None)
				if _snd_ambient is not None:
					try: _snd_ambient.stop()
					except Exception: pass
				
				# 2) Zastavit interní stav
				_mc.stopAmbient()
				_mc.stopMusic()
				
				# 3) Aplikovat patch přímo na instanci
				def _mock_mc_getArenaSoundEvent(self, eventId):
					from debug_utils import LOG_DEBUG
					import BigWorld
					player = BigWorld.player()
					if hasattr(player, 'arena') and hasattr(player.arena, 'arenaType'):
						sound_name = ''
						if eventId == _MC.MUSIC_EVENT_COMBAT:
							# Combat intro exactly ONCE per battle (original: ~1 min music, then
							# quiet). Any later trigger, whoever fires it, gets silence instead
							# of restarting the track from the beginning.
							if globals().get('g_offh_combat_music_done', False):
								return None
							globals()['g_offh_combat_music_done'] = True
							sound_name = getattr(player.arena.arenaType, 'music', '')
						elif eventId == _MC.MUSIC_EVENT_COMBAT_LOADING:
							sound_name = getattr(player.arena.arenaType, 'loadingMusic', '')
						elif eventId == _MC.AMBIENT_EVENT_COMBAT:
							sound_name = getattr(player.arena.arenaType, 'ambientSound', '')
						LOG_DEBUG('OfflineBattle.mock_getArenaSoundEvent DIRECT', eventId, sound_name)
						if sound_name:
							import FMOD
							return FMOD.getSound(sound_name)
					return _MC.MusicController._MusicController__getArenaSoundEvent(self, eventId)

				import types
				_mc._MusicController__getArenaSoundEvent = types.MethodType(_mock_mc_getArenaSoundEvent, _mc)
				
				# 3) Spustit loading hudbu pro bitvu
				globals()['g_offh_combat_music_done'] = False  # new battle, combat intro may play once
				_mc.play(_MC.MUSIC_EVENT_COMBAT_LOADING)
				LOG_DEBUG('OfflineBattle.sounds.battle_start', 'COMBAT_LOADING OK')
			except Exception as _se:
				LOG_DEBUG('OfflineBattle.sounds.battle_start error', _se)
			# ---- konec zvuk ----
			
			WindowsManager.g_windowsManager.startBattle()
			WindowsManager.g_windowsManager.showBattleLoading()
			
			if hasattr(player, 'arena'):
				if hasattr(player.arena, 'onVehicleAdded'):
					for vID in player.arena.vehicles.keys():
						player.arena.onVehicleAdded(vID)
				
				def _finish_battle_load():
					try:
						try:
							import SoundGroups as _SG
							if getattr(_SG, 'g_instance', None) is not None:
								_SG.g_instance.enableLobbySounds(False)
								_SG.g_instance.enableArenaSounds(True)
							import MusicController as _MC
							_MC.g_musicController.play(_MC.MUSIC_EVENT_COMBAT)
							from debug_utils import LOG_DEBUG
							LOG_DEBUG('OfflineBattle.sounds', 'MUSIC_EVENT_COMBAT triggered in finish load')
						except Exception as e: pass
						
						Waiting.close()
						WindowsManager.g_windowsManager.showBattle()
						BigWorld.worldDrawEnabled(True)
						
						import AvatarInputHandler.cameras
						AvatarInputHandler.cameras.SniperCamera._USE_SWINGING = False
						BigWorld.wg_isSniperModeSwingingEnabled = lambda *a, **kw: False
						
						if not hasattr(BigWorld, '_orig_serverTime'):
							BigWorld._orig_serverTime = BigWorld.serverTime
							BigWorld._offline_start_time = __import__('time').time()
							def _mock_serverTime():
								return __import__('time').time() - BigWorld._offline_start_time
							BigWorld.serverTime = _mock_serverTime
						
						def _do():
							try:
								from gui import WindowsManager
								from account_helpers.AccountSettings import AccountSettings
								_orig_getSettings = AccountSettings.getSettings
								# Unwrap first: re-wrapping every battle chained a new closure
								# over the previous one (leak + ever-longer call path).
								if getattr(_orig_getSettings, '_offh_wrapped', False):
									_orig_getSettings = _orig_getSettings._offh_orig
								def _mock_getSettings(name, *a, **kw):
									res = _orig_getSettings(name, *a, **kw)
									if name == 'sniper' or name == 'arcade':
										if res is None: res = {}
										if isinstance(res, dict):
											defaults = {
												'snpCentralTag': {'alpha': 100, 'type': 0},
												'snpNet': {'alpha': 100, 'type': 0},
												'snpReloader': {'alpha': 100, 'type': 0},
												'snpCondition': {'alpha': 100, 'type': 0},
												'snpCassette': {'alpha': 100, 'type': 0},
												'snpGunTag': {'alpha': 100, 'type': 0},
												'snpMixing': {'alpha': 100, 'type': 0},
												'centralTag': {'alpha': 100, 'type': 0},
												'net': {'alpha': 100, 'type': 0},
												'reloader': {'alpha': 100, 'type': 0},
												'condition': {'alpha': 100, 'type': 0},
												'cassette': {'alpha': 100, 'type': 0},
												'gunTag': {'alpha': 100, 'type': 0},
												'mixing': {'alpha': 100, 'type': 0}
											}
											for k, v in defaults.items():
												if k not in res:
													res[k] = v
									return res
								_mock_getSettings._offh_wrapped = True
								_mock_getSettings._offh_orig = _orig_getSettings
								AccountSettings.getSettings = staticmethod(_mock_getSettings)
								
								if hasattr(player.arena, 'onPeriodChange'):
									_battle_duration = 900

									# RESTORE PREBATTLE: original-style countdown - nobody moves
									# or shoots until it reaches 0 (see the period<3 guards)
									from _constants import CONFIG_OPTIONS as _CFG_PB
									_pb_len = float(_CFG_PB.get('prebattle_countdown_seconds', 30.0))
									player.arena.period = 2
									player.arena.periodLength = _pb_len
									player.arena.periodEndTime = BigWorld.serverTime() + _pb_len
									player.arena.onPeriodChange(2, player.arena.periodEndTime, _pb_len, {})
									try:
										import MusicController as _MC
										_MC.g_musicController.play(_MC.MUSIC_EVENT_NONE)
									except: pass
									
								if hasattr(player.arena, 'onNewVehicleListReceived'):
									player.arena.onNewVehicleListReceived()
								if hasattr(player.arena, 'onVehicleAdded'):
									for vID in player.arena.vehicles.keys():
										player.arena.onVehicleAdded(vID)
								if hasattr(player.arena, 'onVehicleStatisticsUpdate'):
									for vID in player.arena.vehicles.keys():
										player.arena.onVehicleStatisticsUpdate(vID)
								if hasattr(WindowsManager.g_windowsManager.battleWindow, '_Battle__populateData'):
									WindowsManager.g_windowsManager.battleWindow._Battle__populateData()
									
								if not getattr(player, '_crosshair_init_done', False):
									player._crosshair_init_done = True
									try:
										import AvatarInputHandler.aims
										try:
											AvatarInputHandler.aims.clearState()
											hs = AvatarInputHandler.aims._g_aimState.get('health')
											if hs is not None:
												hs['cur'] = getattr(player.vehicleTypeDescriptor, 'maxHealth', 400)
												hs['max'] = getattr(player.vehicleTypeDescriptor, 'maxHealth', 400)
										except Exception as e:
											LOG_DEBUG('OfflineBattle aims init error:', str(e))
											
										# Mock the startup to avoid crashing on missing Vehicle entity
										g_offline_aih._AvatarInputHandler__isStarted = True
										g_offline_aih._AvatarInputHandler__isGUIVisible = True
										g_offline_aih._AvatarInputHandler__isArenaStarted = True
										for control in g_offline_aih._AvatarInputHandler__ctrls.itervalues():
											try: control.create()
											except Exception as e: LOG_DEBUG('Control create error:', e)
											
											# Pre-warm the gunMarker state so dumpState() doesn't throw KeyError: 'startTime'
											try: control.setReloading(0.0, 0.0)
											except Exception as e: LOG_DEBUG('CRITICAL ERROR IN K KEY:', e); import traceback; LOG_DEBUG(traceback.format_exc())
											
										try:
											g_offline_aih._AvatarInputHandler__isSPG = 'SPG' in td.type.tags
										except Exception:
											g_offline_aih._AvatarInputHandler__isSPG = False

										g_offline_aih.onControlModeChanged('arcade')
										g_offline_aih.setGUIVisible(True)
										if hasattr(g_offline_aih, 'ctrl'):
											pass
										try:
											import AvatarInputHandler.aims as aims
											if getattr(aims, '_g_aimState', None) is not None:
												aims._g_aimState['reload'] = {'isReloading': False, 'duration': 0.0, 'startTime': None, 'correction': None}
										except Exception:
											pass
										g_offline_aih.ctrl.showGunMarker(True)
										g_offline_aih.ctrl.showGunMarker2(True)
										_force_camera_to_model()
										LOG_DEBUG('OfflineBattle AIH enable SUCCESS')
									except Exception as e:
										import traceback
										LOG_DEBUG('OfflineBattle AIH enable ERROR:', traceback.format_exc())
							except Exception:
								import traceback
								LOG_DEBUG('Do error:', traceback.format_exc())

						BigWorld.callback(0.1, _do)
						
					except Exception:
						LOG_CURRENT_EXCEPTION()
				from _constants import CONFIG_OPTIONS
				loading_time = float(CONFIG_OPTIONS.get('loading_screen_time_seconds', 5.0))
				BigWorld.callback(loading_time, _finish_battle_load)

		except Exception:
			LOG_CURRENT_EXCEPTION()
			WindowsManager.g_windowsManager.hideAll()
		LOG_DEBUG('OfflineBattle.camera started')
	except Exception:
		LOG_CURRENT_EXCEPTION()
	player._offline_allow_become_non_player = False
	LOG_DEBUG('OfflineBattle.spawnAvatar.fail', cmdName)

def _step_on_enqueued(player, vehInvID, cmdName):
	try:
		_enable_offline_battle_transition(player)
		ctx = build_offline_battle_context(player, vehInvID, cmdName)
		player._offhangar_battle_ctx = ctx
		player._offhangar_player_vehicle_id = ctx.get('playerVehicleID', vehInvID)
		player._offhangar_team = 1
		arena = getattr(player, '_offhangar_arena', None)
		if arena is not None:
			arena.vehicles = ctx.get('vehicles', {})
			arena.guiType = 0
			arena.bonusType = 0
			arena.extraData = {'mapName': ctx.get('mapName'), 'mapID': ctx.get('mapID')}
			arena.period = 1
			arena.periodLength = 600
			arena.periodEndTime = BigWorld.serverTime() + 600
			map_name = ctx.get('mapName', '') or ''
			map_id = ctx.get('mapID', 0) or 0
			gameplay = 'ctf'
			real_arena_type = _resolve_real_arena_type(map_id, map_name, gameplay)
			if real_arena_type is not None:
				arena.arenaType = real_arena_type
				arena.arenaTypeID = map_id
				try:
					import ArenaType
					if hasattr(ArenaType, 'g_cache') and isinstance(ArenaType.g_cache, dict):
						for k, v in ArenaType.g_cache.iteritems():
							if v is real_arena_type:
								arena.arenaTypeID = k
								break
				except Exception: pass
				LOG_DEBUG('OfflineBattle.arenaType.real', map_name, 'arenaTypeID', arena.arenaTypeID, 'geomName', getattr(real_arena_type, 'geometryName', ''), 'minimap', hasattr(real_arena_type, 'minimap'))
			elif getattr(arena, 'arenaType', None) is not None:
				# Fallback: keep stub, but ensure required attrs exist.
				arena.arenaTypeID = map_id
				arena.arenaType.geometryName = map_name
				arena.arenaType.gameplayName = gameplay
				if not hasattr(arena.arenaType, 'minimap'):
					arena.arenaType.minimap = None
				LOG_DEBUG('OfflineBattle.arenaType.stub', map_name)
		queueType = _queue_type_randoms()
		LOG_DEBUG('OfflineBattle.onEnqueued', cmdName, 'queueType', queueType, 'vehInvID', vehInvID)
		onEnqueued = getattr(player, 'onEnqueued', None)
		if callable(onEnqueued):
			onEnqueued(queueType)
		else:
			onEnqueuedRandom = getattr(player, 'onEnqueuedRandom', None)
			if callable(onEnqueuedRandom):
				onEnqueuedRandom()
		if hasattr(player, 'isInRandomQueue'):
			player.isInRandomQueue = True
	except Exception:
		LOG_CURRENT_EXCEPTION()


def _step_on_arena_created(player, cmdName):
	try:
		if player is None:
			return
		if getattr(player, '_offhangar_arena_created_once', False):
			LOG_DEBUG('OfflineBattle.onArenaCreated skip duplicate', cmdName)
			return
		player._offhangar_arena_created_once = True
		LOG_DEBUG('OfflineBattle.onArenaCreated', cmdName)
		onArenaCreated = getattr(player, 'onArenaCreated', None)
		if callable(onArenaCreated):
			onArenaCreated()
		BigWorld.callback(0.05, lambda: _try_spawn_battle_avatar_stub(BigWorld.player(), cmdName))
	except Exception:
		LOG_CURRENT_EXCEPTION()


def _schedule_arena_created_resilient(cmdName, player):
	def _fire():
		if not getattr(player, '_offhangar_arena_created_once', False):
			_step_on_arena_created(player, cmdName)

	from _constants import CONFIG_OPTIONS
	queue_time = float(CONFIG_OPTIONS.get('queue_wait_time_seconds', 4.0))

	import BigWorld
	BigWorld.callback(queue_time, _fire)
	BigWorld.callback(queue_time + 0.03, _fire)
	BigWorld.callback(queue_time + 0.10, _fire)


def schedule_random_battle_flow_after_enqueue(cmd, cmdName, args):
	"""
	Call after RES_SUCCESS was delivered for an enqueue-like command.
	args: tuple from doCmdInt3 (int1, int2, int3) or similar.
	"""
	if not OFFLINE_BATTLE_ENABLED:
		LOG_DEBUG('OfflineBattle.disabled schedule', cmdName, cmd, args)
		return
	player = BigWorld.player()
	if player is not None:
		now = time.time()
		if now - getattr(player, '_offhangar_sched_debounce', 0) < 1.0:
			LOG_DEBUG('OfflineBattle.schedule debounce', cmdName, cmd, args)
			return
		player._offhangar_sched_debounce = now

	int1 = args[0] if args else 0
	# Never treat server-stats traffic as battle (same numeric cmd id can alias in AccountCommands index).
	if cmdName and ('SERVER_STATS' in cmdName or 'REQ_SERVER_STATS' in cmdName):
		if int1 == 0 and (len(args) < 2 or args[1] == 0) and (len(args) < 3 or args[2] == 0):
			LOG_DEBUG('OfflineBattle.skip stats-shaped packet', cmdName, cmd, args)
			return

	def _run():
		player = BigWorld.player()
		if player is None or not getattr(player, 'isOffline', False):
			return
		player._offhangar_arena_created_once = False
		vehInvID = int1
		if vehInvID == 0 and cmdName and 'ENQUEUE' in cmdName:
			vehInvID = _resolve_vehicle_inv_id(player, 0)
		if not vehInvID:
			LOG_DEBUG('OfflineBattle.skip no vehInvID', cmdName, cmd, args)
			return
		_step_on_enqueued(player, vehInvID, cmdName)
		_schedule_arena_created_resilient(cmdName, player)

	# Run after the current frame so onCmdResponse callbacks finish first.
	BigWorld.callback(0.05, _run)


def start_offline_random_from_hangar(player, vehInvID):
	import debug_utils
	try:
		from gui.battle_control import constants as bc_constants
		debug_utils.LOG_DEBUG("VEHICLE_VIEW_STATE:", dir(bc_constants.VEHICLE_VIEW_STATE))
		for k in dir(bc_constants.VEHICLE_VIEW_STATE):
			if not k.startswith('_'): debug_utils.LOG_DEBUG("VIEW_STATE", k, getattr(bc_constants.VEHICLE_VIEW_STATE, k))
	except Exception as e: debug_utils.LOG_DEBUG("DUMP ERR1", e)
	try:
		import constants
		debug_utils.LOG_DEBUG("VEHICLE_DEVICE_STATES:", dir(constants.VEHICLE_DEVICE_STATES))
		for k in dir(constants.VEHICLE_DEVICE_STATES):
			if not k.startswith('_'): debug_utils.LOG_DEBUG("DEV_STATE", k, getattr(constants.VEHICLE_DEVICE_STATES, k))
	except Exception as e: debug_utils.LOG_DEBUG("DUMP ERR2", e)
	
	import traceback
	LOG_DEBUG('OfflineBattle.start_offline_random_from_hangar CALLED', player, getattr(player, 'isOffline', None))
	"""
	0.8.x hangar may spam other doCmd ids before/instead of CMD_ENQUEUE_RANDOM (700).
	When the client calls PlayerAccount.enqueueRandom, short-circuit here so we still
	fire the same BW-side chain as a real matchmaker ack.
	"""
	if not OFFLINE_BATTLE_ENABLED:
		LOG_DEBUG('OfflineBattle.disabled start', vehInvID)
		return
	if player is None:
		LOG_DEBUG('OfflineBattle.disabled start player is None')
		return
	now = time.time()
	if now - getattr(player, '_offline_boot_time', 0.0) < 10.0:
		LOG_DEBUG('OfflineBattle.hook IGNORED AUTO-START inside start_offline')
		return
	last = getattr(player, '_offhangar_battle_last_boot', 0.0)
	if now - last < _BATTLE_BOOT_DEBOUNCE_SEC:
		LOG_DEBUG('OfflineBattle.hook debounce skip', vehInvID)
		return
	player._offhangar_battle_last_boot = now
	cmdName = 'offline.enqueueRandom'

	def _run():
		import BigWorld
		p = BigWorld.player()
		if p is None:
			LOG_DEBUG('OfflineBattle.hook skip p is None')
			return
		p._offhangar_arena_created_once = False
		vid = vehInvID or _resolve_vehicle_inv_id(p, 0)
		if not vid:
			LOG_DEBUG('OfflineBattle.hook skip no vehInvID', vehInvID)
			return
		LOG_DEBUG('OfflineBattle.hook start', cmdName, 'vehInvID', vid)
		_step_on_enqueued(p, vid, cmdName)
		_schedule_arena_created_resilient(cmdName, p)

	import BigWorld
	BigWorld.callback(0.05, _run)

try:
	import gui.Scaleform.battledispatcherinterface as bdi
	if hasattr(bdi, 'BattleDispatcherInterface'):
		orig_updateFightButton = bdi.BattleDispatcherInterface.updateFightButton
		def _new_updateFightButton(self):
			orig_updateFightButton(self)
			
			fightTypes = getattr(self, '_offhangar_fightTypes_temp', None)
			if fightTypes is None:
				# In case we can't capture it easily, we just call self.call again!
				pass
		
		# Better approach: monkey-patch self.call in BattleDispatcherInterface
		orig_call = bdi.BattleDispatcherInterface.call
		def _new_call(self, methodName, args=None):
			from gui.mods.offhangar.logging import LOG_DEBUG
			LOG_DEBUG("FLASH CALL:", methodName, args)
			if methodName == 'common.setFightButton' and isinstance(args, list):
				args.append('Bootcamp')
				args.append('tutorial')
				args.append(False)
				args.append('')
			return orig_call(self, methodName, args)
		bdi.BattleDispatcherInterface.call = _new_call

		orig_onFightButtonClick = bdi.BattleDispatcherInterface.onFightButtonClick
		def _new_onFightButtonClick(self, callbackId, mapId=None, queueType=0, confirm=False):
			import BigWorld
			p = BigWorld.player()
			from gui.mods.offhangar.logging import LOG_DEBUG
			LOG_DEBUG("FIGHT BUTTON CLICKED", "mapId:", mapId, "type:", type(mapId), "queueType:", queueType, "type:", type(queueType))
			
			if queueType == 'tutorial':
				if hasattr(p, 'enqueueTutorial'):
					p.enqueueTutorial()
				return
			
			if queueType == 'demonstrator':
				if mapId is not None:
					setattr(p, '_offhangar_selected_mapId', mapId)
				if hasattr(self, 'respond'):
					try: self.respond(callbackId, True)
					except: pass
				start_offline_random_from_hangar(p, 0)
				return
			
			# If it's a regular random battle, ensure we clear any demonstrator map override!
			if hasattr(p, '_offhangar_selected_mapId'):
				delattr(p, '_offhangar_selected_mapId')
				
			return orig_onFightButtonClick(self, callbackId, mapId, queueType, confirm)
		bdi.BattleDispatcherInterface.onFightButtonClick = _new_onFightButtonClick
except Exception:
	import traceback
	LOG_DEBUG('Failed to hook UI')
	LOG_DEBUG(traceback.format_exc())
