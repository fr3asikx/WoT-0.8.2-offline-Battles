import functools
from gui.mods.offhangar.utils import *

doLog = functools.partial(doLog, 'OFFHANGAR')
LOG_NOTE = functools.partial(doLog, '[NOTE]')
LOG_ERROR = functools.partial(doLog, '[ERROR]')

# [DEBUG] lines are synchronous file I/O into python.log. config.json
# "debug_logging": false turns them off (errors stay); no recompile needed.
_DBG = [True]
try:
    import os as _os, json as _json, sys as _sys
    _cfg = _os.path.normpath(_os.path.join(_os.path.dirname(_sys._getframe().f_code.co_filename), 'config.json'))
    if not _os.path.exists(_cfg):
        _cfg = 'res_mods/0.8.2/scripts/client/gui/mods/offhangar/config.json'
    _fh = open(_cfg, 'r')
    try:
        _DBG[0] = bool(_json.load(_fh).get('debug_logging', True))
    finally:
        _fh.close()
except Exception:
    pass
_dbg_log = functools.partial(doLog, '[DEBUG]')
def LOG_DEBUG(*args, **kwargs):
    if _DBG[0]:
        _dbg_log(*args, **kwargs)