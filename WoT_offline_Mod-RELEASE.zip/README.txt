offhangar offline-battle mod - World of Tanks 0.8.2
===================================================

Install
-------
This zip starts at  scripts/ .
Extract it INTO:  <WoT 0.8.2 game root>/res_mods/0.8.2/
so the files land at:  res_mods/0.8.2/scripts/client/gui/mods/mod_offhangar.py
(the scripts/ folder from the zip merges into res_mods/0.8.2/).
Start the game - if the mod loaded you go straight to the offline hangar
instead of the normal login screen.

Config
------
res_mods/0.8.2/scripts/client/gui/mods/offhangar/config.json
  nickname        your in-game name
  bots_per_team   15  (15 vs 15)
  spotting_enabled / perfect_accuracy  gameplay toggles

Debug logging is OFF in this build (no overhead).

Note: 0.8.2 is a 32-bit client. Very long non-stop sessions across many
different maps can slowly grow memory - if it ever gets sluggish after a lot
of battles, restart the client.
