offline-battle mod - World of Tanks 0.8.2
===================================================

Play World of Tanks 0.8.2 offline: no login, no server. You go straight to the
hangar, pick a tank and fight bots on the real maps.


Install
-------
This zip starts at  scripts/  and  gui/ .
Extract it INTO:  <WoT 0.8.2 game root>/res_mods/0.8.2/
so the files land at:  res_mods/0.8.2/scripts/client/gui/mods/mod_offhangar.py

Start the game. If the mod loaded you go straight to the offline hangar
instead of the login screen.

To uninstall, delete  res_mods/0.8.2/scripts  and  res_mods/0.8.2/gui .
Your settings survive in  <game root>/offhangar_user/  - delete that folder too
if you want a clean slate.


Settings
--------
Your editable copy is created on first launch at

    <game root>/offhangar_user/config.json

It is OUTSIDE res_mods, so updating or deleting the mod never touches it.
Options that a mod update adds later fall back to their defaults until you add
them to your file; the shipped defaults live in config_defaults.json next to
the mod and are documented there.

The ones people change most:

  nickname                your in-game name
  bots_per_team           15  (15 vs 15)
  spotting_enabled        enemies must be spotted to be seen
  perfect_accuracy        shells always land in the centre of the circle
  prebattle_countdown_seconds / auto_spawn_delay_seconds


In battle
---------
  O / P / L   spawn a bot where you aim - your own tank as an enemy clone /
              a random enemy / a random ally
  K           leave the battle


Module and crew damage
----------------------
Shells damage modules and crew the way the era did: every device has its own HP
pool from the vehicle descriptor, its own hit chance from the game's material
table, and repairs itself back to roughly half over time. Damaged modules cost
performance, destroyed ones stop working. Fires start from the engine or a
holed fuel tank and burn out on their own. Repair kits, med kits and the fire
extinguisher work, and the damage panel and crew voice lines follow.

Interior modules and crew have no collision geometry in the 0.8.2 client, so
their hit boxes come from a per-vehicle profile set covering 251 vehicles.
Switch it off with  internal_layout_profiles: false  to fall back to a coarser
compartment model.

  module_test_mode: true    bot shells roll every module and crew crit but take
                            no hull HP off you, so you can watch the system work
                            without dying. Turn it off for normal play.


Notes
-----
Debug logging is OFF by default. Turn on  debug_logging  in your config.json if
you want the mod to write diagnostics into python.log.

0.8.2 is a 32-bit client. Long non-stop sessions across many different maps
slowly grow memory - if it gets sluggish after a lot of battles, restart the
client.

The X-ray overlay (internal_xray_overlay) draws module and crew boxes through
the armour. It is a debug view for offline battles and is OFF by default; the
module is not even loaded while it is off. Do not turn it on in a client you
log into a live server with.
